"""One program, a command per job. Each command runs as one fixed user; sudoers and the units say which."""
import os
import signal
import socket
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tftvps import boot, fetcher, gitstore, poller, rules, runctl  # noqa: E402

HOME = os.path.dirname(os.path.abspath(__file__))
STORE = "/var/lib/tftvps/store"
CRATES = "/var/lib/tftvps/crates"
URL = "git@github.com:hadi2trade1995-spec/scratch-trees-vps.git"
EXIT_REFUSED = 3
# Each command's own limit, set by the user who runs it. The poller, as another user, can only close the pipe. `run`
# holds its own, because it must clean up after itself.
OWN_LIMITS = {
    "inspect": poller.INSPECT_SECONDS,
    "fetch": poller.FETCH_SECONDS,
    "scan-text": poller.INSPECT_SECONDS,
    "boot-failed": boot.REPORT_SECONDS,
}
SSH = f"ssh -i {boot.KEY} -o IdentitiesOnly=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile={HOME}/known_hosts -o BatchMode=yes"


def _pins():
    with open(os.path.join(HOME, "pins.txt"), encoding="ascii") as held:
        return rules.read_pins(held.read())


def _profile():
    return runctl.load_profile(os.path.join(HOME, "profile.json"))


def _memory_gb():
    return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30


def _slots():
    return runctl.slots_for(os.cpu_count() or 1, _memory_gb())


def _read_store():
    return gitstore.Store(STORE, URL)


def cmd_inspect(commit):
    sys.stdout.buffer.write(gitstore.inspect(_read_store(), commit, _pins()))
    return 0


def cmd_fetch():
    print(fetcher.fetch_all(sys.stdin.buffer.read(rules.MAX_LOCK + 1), CRATES), "crates")
    return 0


def cmd_run(commit, slot):
    """Slot 0 only: one run at a time on every plan. A second slot is NOT BUILT (runctl.slots_for)."""
    if not rules.hash_is_good(commit) or slot != "0":
        raise rules.Refused("a bad run request")
    cpus = max(1, (os.cpu_count() or 1) // _slots())
    return runctl.run_tree(_read_store(), commit, "/var/lib/tftvps/slot0", CRATES, _profile(), _pins(), cpus)


def cmd_scan_text():
    argv = runctl.scan_argv(_profile(), None)
    return subprocess.run(argv, env=runctl.podman_env(), stdin=sys.stdin, capture_output=True, check=False).returncode


def cmd_planted_failure():
    """Exit 0 only if a true command passes and a false one goes red, so a broken podman cannot pass as red."""
    codes = []
    for program in ("/bin/true", "/bin/false"):
        argv = ["podman", "run", "--rm", "--network=none", *runctl.base_flags(_profile()), runctl.SEALED, program]
        codes.append(subprocess.run(argv, env=runctl.podman_env(), capture_output=True, check=False).returncode)
    return 0 if codes[0] == 0 and codes[1] != 0 else 1


def cmd_probe():
    """Exit 0 if this user reaches a public address on 443."""
    try:
        socket.create_connection(("1.1.1.1", 443), timeout=8).close()
    except OSError:
        return 1
    return 0


def cmd_key_test():
    """As `poller`. 0 the key reads and pushes the new repo and the real repo refuses it; 1 not yet; 3 it opens the real repo."""
    store = gitstore.Store(STORE, URL, ssh_command=SSH)
    return boot.key_verdict(store, boot.REAL_REPO, str(int(time.time())))


def _read(path, size=boot.MAX_REPORT):
    try:
        with open(path, "rb") as held:
            return held.read(size)
    except OSError:
        return b""


def _push_failure(store, raw):
    """The key files are read only so that no part of them can leave in the text."""
    key_text = b"\n".join(_read(path) for path in (boot.KEY, boot.KEY + ".pub")).decode("ascii", "replace")
    seal = _read(boot.SEAL, 4096).decode("ascii", "replace").strip() or "none"
    return boot.push_failure(store, raw, str(int(time.time())), seal, key_text)


def cmd_boot_failed():
    """As `poller`, started by boot alone: why a boot stopped after the key worked. Pushes once and exits; it never
    arms and never starts the poller."""
    _push_failure(gitstore.Store(STORE, URL, ssh_command=SSH), sys.stdin.buffer.read(boot.MAX_REPORT))
    return 0


def start_poller(store, machine, touch):
    """Until the host rows are home, any failure is pushed as a boot failure, and then the poller exits: Restart=no,
    so nothing loops on a broken start."""
    try:
        machine.arm()
        if os.path.exists(boot.ROWS):
            store.push_text(f"results/host-rows-{machine.stamp}", "result.txt", _read(boot.ROWS))
    except Exception as error:
        rows = _read(boot.ROWS).decode("utf-8", "replace") or "no host rows file\n"
        try:
            _push_failure(store, boot.failure_body("poller start", error, rows).encode("utf-8", "replace"))
        except Exception:  # The first failure is the one to exit with.
            pass
        raise
    machine.forever(touch)


def cmd_poller():
    """The lane file is read as bytes here and checked in `arm`, so a missing or bad one comes home as a boot failure."""
    store = gitstore.Store(STORE, URL, ssh_command=SSH)
    machine = poller.Poller(store, poller.Steps(), lane=_read(boot.LANE, 16) or None)
    start_poller(store, machine, lambda: os.utime(boot.ACTIVITY))
    return 0


def cmd_lane(value=""):
    """The owner's one line at arming, as root through sudo, while login is open. No sudo rule names it."""
    lane = boot.set_lane(value)
    print(f"Lane {lane} set. Now add the deploy key above, if you have not yet.")
    return 0


COMMANDS = {
    "inspect": cmd_inspect,
    "fetch": cmd_fetch,
    "run": cmd_run,
    "scan-text": cmd_scan_text,
    "planted-failure": cmd_planted_failure,
    "probe": cmd_probe,
    "key-test": cmd_key_test,
    "poller": cmd_poller,
    "boot-failed": cmd_boot_failed,
    "lane": cmd_lane,
    "boot": boot.boot,
    "idle-check": boot.idle_check,
    "check-programs": boot.check_programs,
    "seccomp": runctl.write_seccomp,
}


def main(argv):
    if len(argv) < 2 or argv[1] not in COMMANDS:
        print("unknown command", file=sys.stderr)
        return 2
    signal.alarm(OWN_LIMITS.get(argv[1], 0))
    try:
        return COMMANDS[argv[1]](*argv[2:])
    except rules.Refused as refusal:
        print(f"refused: {refusal}")
        return EXIT_REFUSED


if __name__ == "__main__":
    sys.exit(main(sys.argv))
