"""Export and containers, run as `runner`. The profile and images come from the snapshot, never the branch."""
import json
import os
import select
import subprocess
import sys
import time

from . import rules
from .gitstore import clean_env

SEALED = "localhost/tftvps-run:sealed"
SECRET_FOUND = 3
EXIT_TIME = 124
EXIT_CLOSED = 125
EXIT_KILLED = 137
RUNNER_ALWAYS = ("systemd", "(sd-pam)", "catatonit", "podman", "ps", "python3")


def slots_for(cpus, memory_gb):
    """One run at a time unless the machine plainly holds two. Nothing assumes more than 8 GB."""
    return 2 if cpus >= 4 and memory_gb >= 14 else 1


def base_flags(profile):
    """On every container. No network flag here: a pod's is on the pod, and a lone scan names its own."""
    return [
        "--pull=never",
        "--cap-drop=ALL",
        "--security-opt=no-new-privileges",
        "--read-only",
        "--http-proxy=false",
        "--log-driver=none",
        f"--pids-limit={profile['pids']}",
    ]


def _env_flags(env):
    return [f"--env={key}={value}" for key, value in sorted(env.items())]


def pod_argv(name):
    return ["podman", "pod", "create", f"--name={name}", "--network=none", "--infra=true"]


def database_argv(pod, image, profile, port):
    tmpfs = [f"--tmpfs={path}:rw,size={size},mode=1777" for path, size in profile["database_tmpfs"].items()]
    env = dict(profile["database_env"])
    argv = ["podman", "run", "-d", f"--pod={pod}", "--user=postgres", f"--memory={profile['database_memory']}"]
    argv += [*base_flags(profile), *tmpfs, *_env_flags(env), image]
    return argv + ["postgres", "-c", f"port={port}"]


def main_argv(pod, profile, slot_dir, crates, cpus):
    env = dict(profile["env"])
    tmpfs = [f"--tmpfs={path}:rw,size={size}" for path, size in profile["tmpfs"].items()]
    argv = ["podman", "run", "--rm", f"--pod={pod}", f"--memory={profile['memory']}", f"--cpus={cpus}"]
    argv += [*base_flags(profile), *tmpfs, *_env_flags(env)]
    argv += [f"--volume={slot_dir}:/work:rw", f"--volume={crates}:/crates:ro", "--workdir=/work/src"]
    return argv + [SEALED, "/opt/tftvps/in-container.sh"]


def scan_argv(profile, mount):
    argv = ["podman", "run", "--rm", "-i", "--network=none", *base_flags(profile), "--tmpfs=/tmp:rw,size=64m"]
    if mount:
        argv += [f"--volume={mount}:/scan:ro", SEALED, "/opt/gitleaks/gitleaks", "dir", "/scan"]
    else:
        argv += [SEALED, "/opt/gitleaks/gitleaks", "stdin"]
    return argv + ["--redact", "--no-banner", "--exit-code", str(SECRET_FOUND), "--config", "/opt/gitleaks/config.toml"]


def podman_env():
    uid = os.getuid()
    return clean_env(HOME=os.path.expanduser("~"), XDG_RUNTIME_DIR=f"/run/user/{uid}", DBUS_SESSION_BUS_ADDRESS=f"unix:path=/run/user/{uid}/bus")


def export_tree(store, commit, target):
    """Plain files from the object store, by hash, with no attributes applied. Refuses a link by mode first."""
    entries = store.listing(commit)
    rules.check_tree(entries)
    process = subprocess.Popen(store.argv("cat-file", "--batch"), stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=clean_env())
    try:
        for mode, _, value, size, path in entries:
            process.stdin.write(value.encode("ascii") + b"\n")
            process.stdin.flush()
            line = process.stdout.readline().split()
            if line[:3] != [value.encode("ascii"), b"blob", size.encode("ascii")]:
                raise rules.Refused("an object did not match its tree line")
            body = process.stdout.read(int(size))
            process.stdout.read(1)
            full = os.path.join(os.fsencode(target), path)
            os.makedirs(os.path.dirname(full), exist_ok=True)
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
            handle = os.open(full, flags, 0o755 if mode == "100755" else 0o644)
            with os.fdopen(handle, "wb") as held:
                held.write(body)
    finally:
        process.stdin.close()
        process.kill()
        process.wait()
    return len(entries)


def wipe(slot_dir):
    subprocess.run(["podman", "unshare", "find", slot_dir, "-mindepth", "1", "-delete"], env=podman_env(), check=False, capture_output=True)


def pipe_closed(fd):
    """True once the reader of this pipe has gone: how a limit in the poller reaches this user."""
    poller = select.poll()
    poller.register(fd, select.POLLOUT)
    return any(event & (select.POLLERR | select.POLLHUP | select.POLLNVAL) for _, event in poller.poll(0))


def watch(process, deadline, closed, now=time.monotonic, sleep=time.sleep):
    """Waits for the run. This user may kill it, so the limits that stop it live here. Gives None, or why it stopped."""
    while process.poll() is None:
        why = "time" if now() >= deadline else "closed" if closed() else None
        if why:
            process.kill()
            process.wait()
            return why
        sleep(1)
    return None


def _say(text):
    """To the poller, if it still reads: a limit there closes this pipe, and the cleanup must still run."""
    try:
        print(text, flush=True)
    except OSError:
        pass


def stray_processes(ps_output, slots):
    """`ps -u runner -o comm=`, less what runner always has. With two slots the other run's are not counted."""
    if slots > 1:
        return 0
    return sum(1 for name in ps_output.split() if name not in RUNNER_ALWAYS)


def leftovers(slot_dir, env, slots):
    """What a finished run left: containers, processes and files. Read by the acceptance rows."""
    containers = subprocess.run(["podman", "ps", "-aq"], env=env, capture_output=True, check=False).stdout.split()
    listed = subprocess.run(["ps", "-u", str(os.getuid()), "-o", "comm="], env=env, capture_output=True, check=False)
    found = subprocess.run(["podman", "unshare", "find", slot_dir, "-mindepth", "1"], env=env, capture_output=True, check=False)
    return len(containers), stray_processes(listed.stdout.decode("ascii", "replace"), slots), len(found.stdout.splitlines())


def run_tree(store, commit, slot_dir, crates, profile, images, cpus, closed=None, slots=1):
    """Scan, then the same steps as `checks`, in one pod with its own pair of clusters. Output goes to stdout."""
    pod = f"tftvps-{commit[:16]}"
    env = podman_env()
    closed = closed or (lambda: pipe_closed(sys.stdout.fileno()))
    deadline = time.monotonic() + profile["seconds"]

    def left():
        return max(1, deadline - time.monotonic())

    wipe(slot_dir)
    source = os.path.join(slot_dir, "src")
    os.makedirs(source)
    try:
        export_tree(store, commit, source)
        scan = subprocess.run(scan_argv(profile, source), env=env, stdin=subprocess.DEVNULL, capture_output=True, check=False, timeout=left())
        if scan.returncode != 0:
            _say("the secret scan stopped this run; no value is reported" if scan.returncode == SECRET_FOUND else "the scan itself failed")
            return 1
        subprocess.run(pod_argv(pod), env=env, check=True, capture_output=True, timeout=left())
        for image, port in ((images["IMAGE_TIMESCALE"], 5432), (images["IMAGE_PLAIN"], 5433)):
            subprocess.run(database_argv(pod, f"docker.io/{image}", profile, port), env=env, check=True, capture_output=True, timeout=left())
        sys.stdout.flush()
        process = subprocess.Popen(main_argv(pod, profile, slot_dir, crates, cpus), env=env, stdin=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        stopped = watch(process, deadline, closed)
        if stopped == "time":
            _say("the run passed its time limit")
            return EXIT_TIME
        if stopped == "closed":
            return EXIT_CLOSED
        if process.returncode == EXIT_KILLED:
            _say("the run's container was killed: the memory limit, most likely")
        return process.returncode
    except subprocess.TimeoutExpired:
        _say("the run passed its time limit")
        return EXIT_TIME
    finally:
        subprocess.run(["podman", "pod", "rm", "-f", pod], env=env, check=False, capture_output=True)
        wipe(slot_dir)
        containers, processes, files = leftovers(slot_dir, env, slots)
        _say(f"=== After the run: {containers} containers, {processes} processes, {files} files")


def load_profile(path):
    with open(path, encoding="ascii") as held:
        return json.load(held)
