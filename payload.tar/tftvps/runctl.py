"""Export and containers, run as `runner`. The profile and images come from the snapshot, never the branch."""
import collections
import json
import os
import pwd
import re
import select
import subprocess
import sys
import time

from . import rules
from .gitstore import clean_env

SEALED = "localhost/tftvps-run:sealed"
SECRET_FOUND = 3
EXIT_TIME = rules.EXIT_TIME
EXIT_CLOSED = rules.EXIT_CLOSED
EXIT_RED = rules.EXIT_RED
EXIT_MEMORY = rules.EXIT_MEMORY
# The tree's own code when its container is killed for memory; runctl never gives it out (own_code).
EXIT_KILLED = 137
EXIT_STRAY = rules.EXIT_STRAY
# Every code run_tree gives after a clean check. Anything else from it is mapped to EXIT_RED.
RUN_CODES = (0, EXIT_RED, EXIT_MEMORY, EXIT_TIME, EXIT_CLOSED)
# Written by root at arming, before the poller starts; runner reads it and cannot change it.
BASELINE = "/run/tftvps/baseline.json"
STOPPED = "a process was left, so this server takes no more trees: delete it and arm a new one"


def own_code(tree_code):
    """The tree picks its own exit code, any value, so runctl never passes it on: 0 stays 0, a container killed for
    memory becomes EXIT_MEMORY, and anything else becomes EXIT_RED. Then a 128+N from sudo means runctl itself died."""
    if tree_code == 0:
        return 0
    return EXIT_MEMORY if tree_code == EXIT_KILLED else EXIT_RED


def slots_for(cpus, memory_gb):
    """One run at a time on every plan, whatever its size. Two at once is NOT BUILT: it needs a record of each slot's
    commit that the poller writes and runner cannot, and a reviewed change that brings that record."""
    del cpus, memory_gb
    return 1


def base_flags(profile):
    """On every container. No network flag here: a pod's is on the pod, and a lone scan names its own."""
    return [
        "--pull=never",
        "--cap-drop=ALL",
        "--security-opt=no-new-privileges",
        "--read-only",
        "--http-proxy=false",
        "--log-driver=none",
        f"--pids-limit={profile['pids']}",
    ]


def _env_flags(env):
    return [f"--env={key}={value}" for key, value in sorted(env.items())]


def pod_argv(name):
    return ["podman", "pod", "create", f"--name={name}", "--network=none", "--infra=true"]


def database_argv(pod, image, profile, port):
    tmpfs = [f"--tmpfs={path}:rw,size={size},mode=1777" for path, size in profile["database_tmpfs"].items()]
    env = dict(profile["database_env"])
    argv = ["podman", "run", "-d", f"--pod={pod}", "--user=postgres", f"--memory={profile['database_memory']}"]
    argv += [*base_flags(profile), *tmpfs, *_env_flags(env), image]
    return argv + ["postgres", "-c", f"port={port}"]


def main_argv(pod, profile, slot_dir, crates, cpus):
    """As the image's plain user, as hosted CI runs tests: several refuse root. Its temp files go on the slot's volume
    (TMPDIR), not the /tmp tmpfs, which counts against the run's memory."""
    env = dict(profile["env"])
    tmpfs = [f"--tmpfs={path}:rw,size={size}" for path, size in profile["tmpfs"].items()]
    argv = ["podman", "run", "--rm", f"--pod={pod}", f"--user={profile['user']}", f"--memory={profile['memory']}", f"--cpus={cpus}"]
    argv += [*base_flags(profile), *tmpfs, *_env_flags(env)]
    argv += [f"--volume={slot_dir}:/work:rw", f"--volume={crates}:/crates:ro", "--workdir=/work/src"]
    return argv + [SEALED, "/opt/tftvps/in-container.sh"]


def scan_argv(profile, mount):
    argv = ["podman", "run", "--rm", "-i", "--network=none", *base_flags(profile), "--tmpfs=/tmp:rw,size=64m"]
    if mount:
        argv += [f"--volume={mount}:/scan:ro", SEALED, "/opt/gitleaks/gitleaks", "dir", "/scan"]
    else:
        argv += [SEALED, "/opt/gitleaks/gitleaks", "stdin"]
    return argv + ["--redact", "--no-banner", "--exit-code", str(SECRET_FOUND), "--config", "/opt/gitleaks/config.toml"]


def podman_env():
    uid = os.getuid()
    return clean_env(HOME=os.path.expanduser("~"), XDG_RUNTIME_DIR=f"/run/user/{uid}", DBUS_SESSION_BUS_ADDRESS=f"unix:path=/run/user/{uid}/bus")


def export_tree(store, commit, target):
    """Plain files from the object store, by hash, with no attributes applied. Refuses a link by mode first."""
    entries = store.listing(commit)
    rules.check_tree(entries)
    process = subprocess.Popen(store.argv("cat-file", "--batch"), stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=clean_env())
    try:
        for mode, _, value, size, path in entries:
            process.stdin.write(value.encode("ascii") + b"\n")
            process.stdin.flush()
            line = process.stdout.readline().split()
            if line[:3] != [value.encode("ascii"), b"blob", size.encode("ascii")]:
                raise rules.Refused("an object did not match its tree line")
            body = process.stdout.read(int(size))
            process.stdout.read(1)
            full = os.path.join(os.fsencode(target), path)
            os.makedirs(os.path.dirname(full), exist_ok=True)
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
            handle = os.open(full, flags, 0o755 if mode == "100755" else 0o644)
            with os.fdopen(handle, "wb") as held:
                held.write(body)
    finally:
        process.stdin.close()
        process.kill()
        process.wait()
    return len(entries)


def wipe(slot_dir):
    subprocess.run(["podman", "unshare", "find", slot_dir, "-mindepth", "1", "-delete"], env=podman_env(), check=False, capture_output=True)


# Ids inside runner's user namespace: 0 is runner itself, and the run's user maps into runner's subordinate range,
# which the stray check already counts as runner's (runner_ids).
RUNNER_INSIDE = "0:0"


def hand_over(slot_dir, ids):
    """The slot, wholly, to `ids` inside runner's namespace: to the run's user before the run, so it can write there,
    and back to runner after, so the next export can. Raises if it fails: a run must not start in a slot it cannot
    write, and a cleanup that cannot hand back counts as failed."""
    subprocess.run(["podman", "unshare", "chown", "-R", "--no-dereference", ids, slot_dir], env=podman_env(), check=True, capture_output=True)


def pipe_closed(fd):
    """True once the reader of this pipe has gone: how a limit in the poller reaches this user."""
    poller = select.poll()
    poller.register(fd, select.POLLOUT)
    return any(event & (select.POLLERR | select.POLLHUP | select.POLLNVAL) for _, event in poller.poll(0))


def watch(process, deadline, closed, now=time.monotonic, sleep=time.sleep):
    """Waits for the run. This user may kill it, so the limits that stop it live here. Gives None, or why it stopped."""
    while process.poll() is None:
        why = "time" if now() >= deadline else "closed" if closed() else None
        if why:
            process.kill()
            process.wait()
            return why
        sleep(1)
    return None


def _say(text):
    """To the poller, if it still reads: a limit there closes this pipe, and the cleanup must still run. The failed
    line stays in stdout's buffer, and Python's exit would fail to flush it and give 120 instead of runctl's code, so
    fd 1 then points at /dev/null: the held bytes and every later line go nowhere. Nothing watches fd 1 after a write
    has failed: `watch` has already returned by then."""
    try:
        print(text, flush=True)
    except OSError:
        os.dup2(os.open(os.devnull, os.O_WRONLY), 1)


class Row(collections.namedtuple("Row", "start ppid uid comm cgroup")):
    """One process as /proc gives it: a start time in clock ticks after boot, a name and a cgroup. No command line or
    environment is ever read: those could carry a secret."""


NOT_SHOWN = re.compile(r"[^A-Za-z0-9 ._:()+@/-]")
NAMED_AT_MOST = 10
UNREAD = -1


def _read(path):
    with open(path, "rb") as held:
        return held.read(65536).decode("ascii", "replace")


def process_table(proc="/proc"):
    """Every process this user can see. One that ends while it is read is left out; one that cannot be parsed stays,
    with an owner of UNREAD, so the check counts it rather than skip it."""
    table = {}
    for entry in os.listdir(proc):
        if not entry.isdigit():
            continue
        base = os.path.join(proc, entry)
        try:
            stat, status, cgroup = _read(f"{base}/stat"), _read(f"{base}/status"), _read(f"{base}/cgroup")
        except OSError:
            continue
        try:
            fields = stat[stat.rindex(")") + 2 :].split()
            comm = stat[stat.index("(") + 1 : stat.rindex(")")]
            uid = int(next(line for line in status.splitlines() if line.startswith("Uid:")).split()[2])
            path = next((line[3:] for line in cgroup.splitlines() if line.startswith("0::")), "")
            table[int(entry)] = Row(int(fields[19]), int(fields[1]), uid, comm, path)
        except (ValueError, IndexError, StopIteration):
            table[int(entry)] = Row(UNREAD, 0, UNREAD, "?", "")
    return table


def boot_time(proc="/proc"):
    """Seconds since the epoch at boot, from /proc/stat, or None."""
    try:
        return int(next(line for line in _read(f"{proc}/stat").splitlines() if line.startswith("btime ")).split()[1])
    except (OSError, ValueError, IndexError, StopIteration):
        return None


def runner_ids(uid, subuid_text):
    """This uid and its subordinate range: a container's own users are runner's too."""
    ids = {uid}
    try:
        name = pwd.getpwuid(uid).pw_name
    except KeyError:
        return ids
    for line in subuid_text.splitlines():
        parts = line.strip().split(":")
        if len(parts) == 3 and parts[0] in (name, str(uid)) and parts[1].isdigit() and parts[2].isdigit():
            ids.update(range(int(parts[1]), int(parts[1]) + int(parts[2])))
    return ids


def manager_cgroup(runner):
    """Runner's own systemd --user, as the kernel shows it. Every cgroup runner may make is under this."""
    return f"/user.slice/user-{runner}.slice/user@{runner}.service"


def record_bus(table, runner, manager, shown):
    """At arming, as root, after runner's bus started. `manager` is user@<uid>.service's main pid from the system
    manager; `shown` is runner's manager's `MainPID=` and `ControlGroup=` for dbus.service. The bus must be runner's,
    a child of that systemd --user (itself runner's, a child of pid 1), in exactly its dbus cgroup. Its name is never
    what makes it trusted: its pid and start are. Raises ValueError, naming what is wrong."""
    fields = dict(line.split("=", 1) for line in shown.splitlines() if "=" in line)
    pid, cgroup, service = int(fields["MainPID"]), fields["ControlGroup"], manager_cgroup(runner)
    boss, row = table.get(manager), table.get(pid)
    if boss is None or (boss.uid, boss.ppid, boss.cgroup) != (runner, 1, f"{service}/init.scope"):
        raise ValueError("runner's systemd --user is not runner's child of pid 1 in its own cgroup")
    if pid <= 1 or row is None or (row.uid, row.ppid, row.cgroup) != (runner, manager, cgroup) or row.start < boss.start:
        raise ValueError("the bus is not runner's child of its systemd --user in the cgroup it reports")
    if not (cgroup.startswith(f"{service}/") and cgroup.endswith("/dbus.service")):
        raise ValueError("the bus is not in a dbus.service cgroup of runner's manager")
    return {"pid": pid, "start": row.start, "parent": manager, "parent_start": boss.start, "cgroup": cgroup}


def bus_problems(table, bus, runner):
    """The bus as arming recorded it, at every run. A bus that died and came back has a new pid, so it counts."""
    row, boss = table.get(bus["pid"]), table.get(bus["parent"])
    if row is None or (row.start, row.uid, row.ppid, row.cgroup) != (bus["start"], runner, bus["parent"], bus["cgroup"]):
        return ["the user bus is not the one arming recorded"]
    if boss is None or (boss.start, boss.uid) != (bus["parent_start"], runner):
        return ["runner's systemd --user is not the one arming recorded"]
    return []


def baseline(table, ours, bus):
    """What arming writes: every process of `ours` by pid and start, and the bus."""
    return {"processes": sorted([pid, row.start] for pid, row in table.items() if row.uid in ours), "bus": bus}


def read_baseline(path=None):
    """The arming record, as (pid, start) pairs and the bus. Anything malformed raises: the caller counts that."""
    with open(path or BASELINE, encoding="ascii") as held:
        data = json.load(held)
    known = {(int(pid), int(start)) for pid, start in data["processes"]}
    bus = {key: int(data["bus"][key]) for key in ("pid", "start", "parent", "parent_start")}
    bus["cgroup"] = str(data["bus"]["cgroup"])
    if (bus["pid"], bus["start"]) not in known or (bus["parent"], bus["parent_start"]) not in known:
        raise ValueError("the bus is not in the arming record")
    return known, bus


# NOT BUILT: leaving out a second slot's run. Podman's state is runner's, so a stray could pass for the other run.
# Two slots come back only with a record of each slot's commit that the poller writes and runner cannot, in a
# reviewed change. Until then nothing of runner's that arming did not record is ever left out.


def stray_processes(after, known, ours, own):
    """Every process of `ours` in `after` that is not this run and not in the arming record `known`, by pid and
    start. Nothing else is left out."""
    strays = []
    for pid, row in sorted(after.items()):
        if pid == own or (row.uid not in ours and row.uid != UNREAD) or (pid, row.start) in known:
            continue
        strays.append(pid)
    return strays


def describe(table, pids, booted, hertz):
    """pid, name and start time; nothing else."""
    said = []
    for pid in pids:
        row = table[pid]
        name = NOT_SHOWN.sub("?", row.comm)[:15] or "?"
        if row.uid == UNREAD:
            said.append(f"pid {pid} unreadable")
        elif booted is None:
            said.append(f"pid {pid} {name} started {row.start // hertz} s after boot")
        else:
            started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(booted + row.start // hertz))
            said.append(f"pid {pid} {name} started {started}")
    return said


def after_line(containers, strays, files):
    """The line the acceptance rows read. With nothing left it is exactly what agent-helper.sh looks for."""
    line = f"=== After the run: {containers} containers, {len(strays)} processes, {files} files"
    if not strays:
        return line
    named = ", ".join(strays[:NAMED_AT_MOST])
    more = f", and {len(strays) - NAMED_AT_MOST} more" if len(strays) > NAMED_AT_MOST else ""
    return f"{line}: {named}{more}"


def subuids():
    """Empty if unreadable: a smaller set at arming only makes more processes count later."""
    try:
        return _read("/etc/subuid")
    except OSError:
        return ""


def leftovers(slot_dir, env, read=None):
    """What a finished run left: every container, every process not in the arming record, and files in its slot.
    One run at a time, so all of them count."""
    listed = subprocess.run(["podman", "ps", "-a", "--no-trunc", "--format", "{{.ID}} {{.PodName}}"], env=env, capture_output=True, check=False)
    found = subprocess.run(["podman", "unshare", "find", slot_dir, "-mindepth", "1"], env=env, capture_output=True, check=False)
    containers = [line for line in listed.stdout.decode("ascii", "replace").splitlines() if line.strip()]
    after = (read or process_table)()
    runner, own = os.getuid(), os.getpid()
    try:
        known, bus = read_baseline()
    except (OSError, ValueError, KeyError, TypeError):
        strays = ["the arming record could not be read"]
    else:
        pids = stray_processes(after, known, runner_ids(runner, subuids()), own)
        strays = describe(after, pids, boot_time(), os.sysconf("SC_CLK_TCK")) + bus_problems(after, bus, runner)
    if listed.returncode != 0:
        strays.append("podman ps itself failed")
    return len(containers), strays, len(found.stdout.splitlines())


def run_tree(store, commit, slot_dir, crates, profile, images, cpus, closed=None):
    """Scan, then the same steps as `checks`, in one pod with its own pair of clusters. Output goes to stdout. Any
    stray, or a cleanup or check that fails, gives EXIT_STRAY whatever the run gave, and the poller stops on it.
    After a clean check it gives only RUN_CODES: a step that raised is EXIT_RED, never Python's exit 1."""
    pod = f"tftvps-{commit[:16]}"
    env = podman_env()
    failed = None
    try:
        code = _steps(store, commit, slot_dir, crates, profile, images, cpus, closed, pod, env)
    except Exception as error:  # The cleanup and the check still run, and a stray outranks the error.
        failed, code = error, 1
    try:
        subprocess.run(["podman", "pod", "rm", "-f", pod], env=env, check=False, capture_output=True)
        wipe(slot_dir)
        hand_over(slot_dir, RUNNER_INSIDE)
    except Exception as error:  # A cleanup that cannot run leaves the server unknown: it counts as a stray.
        containers, strays, files = 0, [f"the cleanup itself failed: {type(error).__name__}"], 0
    else:
        try:
            containers, strays, files = leftovers(slot_dir, env)
        except Exception as error:  # A check that cannot tell counts as a stray.
            containers, strays, files = 0, [f"the check itself failed: {type(error).__name__}"], 0
    _say(after_line(containers, strays, files))
    if strays:
        _say(STOPPED)
        return EXIT_STRAY
    if failed is not None:
        _say(f"a run step failed: {type(failed).__name__}")
        return EXIT_RED
    return code if code in RUN_CODES else EXIT_RED


def _steps(store, commit, slot_dir, crates, profile, images, cpus, closed, pod, env):
    closed = closed or (lambda: pipe_closed(sys.stdout.fileno()))
    deadline = time.monotonic() + profile["seconds"]

    def left():
        return max(1, deadline - time.monotonic())

    wipe(slot_dir)
    hand_over(slot_dir, RUNNER_INSIDE)
    source = os.path.join(slot_dir, "src")
    os.makedirs(source)
    try:
        export_tree(store, commit, source)
        scan = subprocess.run(scan_argv(profile, source), env=env, stdin=subprocess.DEVNULL, capture_output=True, check=False, timeout=left())
        if scan.returncode != 0:
            _say("the secret scan stopped this run; no value is reported" if scan.returncode == SECRET_FOUND else "the scan itself failed")
            return EXIT_RED
        hand_over(slot_dir, profile["user"])
        subprocess.run(pod_argv(pod), env=env, check=True, capture_output=True, timeout=left())
        for image, port in ((images["IMAGE_TIMESCALE"], 5432), (images["IMAGE_PLAIN"], 5433)):
            subprocess.run(database_argv(pod, f"docker.io/{image}", profile, port), env=env, check=True, capture_output=True, timeout=left())
        sys.stdout.flush()
        process = subprocess.Popen(main_argv(pod, profile, slot_dir, crates, cpus), env=env, stdin=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        stopped = watch(process, deadline, closed)
        if stopped == "time":
            _say("the run passed its time limit")
            return EXIT_TIME
        if stopped == "closed":
            return EXIT_CLOSED
        if process.returncode != 0:
            _say(f"the tree exited {process.returncode}")
        if process.returncode == EXIT_KILLED:
            _say("the run's container was killed: the memory limit, most likely")
        return own_code(process.returncode)
    except subprocess.TimeoutExpired:
        _say("the run passed its time limit")
        return EXIT_TIME


def load_profile(path):
    with open(path, encoding="ascii") as held:
        return json.load(held)
