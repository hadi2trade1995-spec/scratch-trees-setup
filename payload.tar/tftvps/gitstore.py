"""The bare store. Argument arrays only, hooks off, one protocol, objects checked on arrival."""
import subprocess

from . import rules

TIMEOUT = 600
IDENTITY = ("-c", "user.name=vps", "-c", "user.email=vps@example.invalid")
ACCESS_OPEN, ACCESS_REFUSED, ACCESS_UNKNOWN = "open", "refused", "unknown"
# GitHub's words for a key with no access, private repo or unknown key alike. Anything else, a network failure
# above all, says nothing about the key.
REFUSED_WORDS = (b"Repository not found", b"Permission denied (publickey)")


def access_of(returncode, stderr):
    if returncode == 0:
        return ACCESS_OPEN
    return ACCESS_REFUSED if any(word in stderr for word in REFUSED_WORDS) else ACCESS_UNKNOWN


SAID_CAP = 300


def refusal_words(args, returncode, stderr):
    """`git <command> failed (exit N): <git's words>`. The command is the first word past the -c pairs (IDENTITY
    comes first for commit-tree). Git's words are printable ASCII only, each run of anything else one space, and at
    most SAID_CAP characters. A poller result carries them only through compose and the secret scan."""
    at = 0
    while at + 1 < len(args) and args[at] == "-c":
        at += 2
    command = args[at] if at < len(args) else "(none)"
    said = "".join(ch if " " <= ch <= "~" else " " for ch in stderr.decode("ascii", "replace"))
    said = " ".join(said.split())[:SAID_CAP]
    return f"git {command} failed (exit {returncode})" + (f": {said}" if said else "")


def clean_env(**extra):
    env = {
        "PATH": "/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin",
        "LC_ALL": "C",
        "HOME": "/nonexistent",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": "/dev/null",
        "GIT_TERMINAL_PROMPT": "0",
    }
    env.update(extra)
    return env


class Store:
    def __init__(self, path, url, ssh_command=None, protocol="ssh"):
        self.path, self.url, self.ssh_command, self.protocol = str(path), url, ssh_command, protocol

    def argv(self, *args):
        config = (
            "core.hooksPath=/dev/null",
            "core.attributesFile=/dev/null",
            "protocol.allow=never",
            f"protocol.{self.protocol}.allow=always",
            "transfer.fsckObjects=true",
            "submodule.recurse=false",
            f"safe.directory={self.path}",
        )
        pairs = [part for item in config for part in ("-c", item)]
        return ["git", *pairs, "--git-dir", self.path, *args]

    def run(self, *args, data=None, check=True):
        env = clean_env()
        if self.ssh_command:
            env["GIT_SSH_COMMAND"] = self.ssh_command
        # No input: stdin is closed, so git never reads the caller's.
        feed = {"stdin": subprocess.DEVNULL} if data is None else {"input": data}
        done = subprocess.run(self.argv(*args), **feed, capture_output=True, env=env, timeout=TIMEOUT)
        if check and done.returncode != 0:
            raise rules.Refused(refusal_words(args, done.returncode, done.stderr))
        return done

    def init(self):
        subprocess.run(["git", "init", "-q", "--bare", self.path], check=True, env=clean_env(), capture_output=True)

    def list_refs(self, lane=None):
        """With a lane, git lists `vps/l<lane>-*` alone (lanes security M1), so results and other lanes never crowd
        this lane's trees out of the listing's cap. Its own old refs still can: the caller says so when they do."""
        if lane is None:
            return rules.parse_ls_remote(self.run("ls-remote", "--heads", self.url).stdout)
        lane = rules.lane_of(lane)
        return rules.parse_ls_remote(self.run("ls-remote", "--heads", self.url, f"refs/heads/vps/l{lane}-*").stdout, lane)

    def access(self, url):
        done = self.run("ls-remote", "--heads", url, check=False)
        return access_of(done.returncode, done.stderr)

    def fetch(self, ref, value):
        """One validated ref, depth 1, no tags. Afterwards it must be the very hash that was listed."""
        if not rules.ref_is_good(ref) or not rules.hash_is_good(value):
            raise rules.Refused("a bad ref or hash reached fetch")
        target = f"refs/tft/{value}"
        spec = f"+refs/heads/{ref}:{target}"
        self.run("fetch", "--depth=1", "--no-tags", "--no-recurse-submodules", "--no-write-fetch-head", self.url, spec)
        got = self.run("rev-parse", "--verify", f"{target}^{{commit}}").stdout.decode("ascii", "replace").strip()
        if got != value:
            self.run("update-ref", "-d", target, check=False)
            raise rules.Refused("the fetched commit is not the listed one")

    def tree_of(self, commit):
        tree = self.run("rev-parse", "--verify", f"{commit}^{{tree}}").stdout.decode("ascii", "replace").strip()
        if not rules.hash_is_good(tree):
            raise rules.Refused("the tree hash could not be read")
        return tree

    def listing(self, commit):
        return rules.parse_ls_tree(self.run("ls-tree", "-r", "-l", "-z", "--full-tree", commit).stdout)

    def commit_body(self, commit):
        return self.run("cat-file", "commit", commit).stdout

    def blob(self, commit, path):
        return self.run("cat-file", "blob", f"{commit}:{path}").stdout

    def push_text(self, name, filename, text):
        """Writes one file as a parentless commit on a new ref. Nothing here ever reads a result back."""
        blob = self.run("hash-object", "-w", "--stdin", data=text).stdout.decode().strip()
        tree = self.run("mktree", data=f"100644 blob {blob}\t{filename}\n".encode()).stdout.decode().strip()
        commit = self.run(*IDENTITY, "commit-tree", tree, "-m", "vps result").stdout.decode().strip()
        self.run("push", "--no-tags", "--no-verify", self.url, f"{commit}:refs/heads/{name}")
        return commit


def inspect(store, commit, pins):
    """Run as `runner`, which has no key. Refuses, or gives back the lock's bytes without parsing them."""
    if not rules.hash_is_good(commit):
        raise rules.Refused("a bad commit hash")
    rules.check_commit(store.commit_body(commit))
    rules.check_tree(store.listing(commit))
    ci = store.blob(commit, rules.CI_FILE)
    if len(ci) > rules.MAX_CI:
        raise rules.Refused(rules.NOT_MATCHED)
    rules.check_ci(ci.decode("utf-8", "replace"), pins)
    return store.blob(commit, rules.LOCK_FILE)
