"""The poller holds the key and runs nothing from a branch. It handles refs by hash and other users' pipes."""
import queue
import subprocess
import threading
import time

from . import results, rules

SUDO = ("sudo", "-n", "-u")
PROGRAM = ("/usr/bin/python3", "-I", "/opt/tftvps/vps.py")
INSPECT_SECONDS = 120
FETCH_SECONDS = 900
RUN_SECONDS = 3600
LOCK_CAP = rules.MAX_LOCK
EXIT_REFUSED = 3


def as_user(user, *args):
    return [*SUDO, user, *PROGRAM, *args]


class Steps:
    """Each other user's work, by a fixed sudo rule and pipes. Only rights downward exist."""

    def _pipe(self, argv, cap, seconds, data=None, stderr=subprocess.STDOUT):
        """Past a limit the pipe closes and this waits. It cannot kill across users, and the slot stays busy until
        the writer has gone, so no later tree starts beside a live run. `vps.py` holds each command's own limit."""
        process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
        if data is not None:
            threading.Thread(target=self._feed, args=(process, data), daemon=True).start()
        else:
            process.stdin.close()
        out, why = results.read_capped(process, cap, time.monotonic() + seconds)
        process.stdout.close()
        code = process.wait()
        return code, out, why

    @staticmethod
    def _feed(process, data):
        try:
            process.stdin.write(data)
            process.stdin.close()
        except OSError:
            pass

    def inspect(self, commit):
        # Its stdout is the lock's bytes, so nothing else may land in that pipe: a word from sudo would refuse every tree.
        return self._pipe(as_user("runner", "inspect", commit), LOCK_CAP + 4096, INSPECT_SECONDS, stderr=subprocess.DEVNULL)

    def fetch(self, lock):
        return self._pipe(as_user("fetcher", "fetch"), 4096, FETCH_SECONDS, data=lock)

    def run(self, commit, slot):
        return self._pipe(as_user("runner", "run", commit, str(slot)), results.MAX_OUTPUT, RUN_SECONDS)

    def scan(self, text):
        return self._pipe(as_user("runner", "scan-text"), 4096, INSPECT_SECONDS, data=text)


class Poller:
    def __init__(self, store, steps, slots=1, say=print):
        self.store, self.steps, self.say = store, steps, say
        self.seen = set()
        self.waiting = {}
        self.lock = threading.Lock()
        self.jobs = queue.Queue()
        self.slots = slots
        self.busy = 0
        self.stamp = str(int(time.time()))

    def arm(self):
        """Refs that exist now are old: only what appears later runs, in the order first seen."""
        listed, _ = self.store.list_refs()
        self.seen.update(listed)

    def look(self):
        listed, ignored = self.store.list_refs()
        if ignored:
            self.say(f"ignored {ignored} refs with names or hashes that are not allowed")
        for ref, value in rules.new_refs(listed, self.seen):
            self.seen.add((ref, value))
            task = rules.task_of(ref)
            with self.lock:
                self.waiting.pop(task, None)
                self.waiting[task] = (ref, value)

    def next_job(self):
        with self.lock:
            if not self.waiting:
                return None
            task = next(iter(self.waiting))
            return self.waiting.pop(task)

    def active(self):
        with self.lock:
            return bool(self.waiting) or self.busy > 0

    def process(self, ref, value, slot):
        """The whole path for one ref. Any refusal becomes a result, red, naming the rule."""
        tree = value
        status, body = "red", b""
        try:
            self.store.fetch(ref, value)
            tree = self.store.tree_of(value)
            code, out, why = self.steps.inspect(value)
            if code != 0 or why != "ended":
                body = out[:4096]
            else:
                code, out, why = self.steps.fetch(out)
                if code != 0 or why != "ended":
                    body = out
                else:
                    code, body, why = self.steps.run(value, slot)
                    if why != "ended":
                        body += f"\nstopped: {why}\n".encode()
                    elif code == 0:
                        status = "green"
        except (rules.Refused, subprocess.SubprocessError, OSError) as error:
            body = str(error).encode() if isinstance(error, rules.Refused) else b"a step failed on the server"
        self.report(tree, status, body)

    def report(self, tree, status, body):
        text = results.compose(tree, status, body)
        code, _, why = self.steps.scan(text)
        if code != 0 or why != "ended":
            text = results.compose(tree, "red", b"the secret scan stopped this result; no value is reported")
        self.store.push_text(f"results/{tree}-{self.stamp}", "result.txt", text)

    def _worker(self, slot):
        while True:
            ref, value = self.jobs.get()
            try:
                self.process(ref, value, slot)
            except Exception as error:  # A failed result must not stop the poller.
                self.say(f"could not finish {value}: {type(error).__name__}")
            finally:
                with self.lock:
                    self.busy -= 1

    def dispatch(self):
        """Hands waiting refs to free slots."""
        while True:
            with self.lock:
                if self.busy >= self.slots:
                    return
            job = self.next_job()
            if job is None:
                return
            with self.lock:
                self.busy += 1
            self.jobs.put(job)

    def forever(self, touch, sleep_seconds=60):
        for slot in range(self.slots):
            threading.Thread(target=self._worker, args=(slot,), daemon=True).start()
        while True:
            try:
                self.look()
            except (rules.Refused, subprocess.SubprocessError, OSError):
                self.say("could not list refs")
            self.dispatch()
            if self.active():
                touch()
            time.sleep(sleep_seconds)
