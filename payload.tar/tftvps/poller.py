"""The poller holds the key and runs nothing from a branch. It handles refs by hash and other users' pipes."""
import queue
import subprocess
import threading
import time

from . import results, rules

SUDO = ("sudo", "-n", "-u")
PROGRAM = ("/usr/bin/python3", "-I", "/opt/tftvps/vps.py")
INSPECT_SECONDS = 120
FETCH_SECONDS = 900
RUN_SECONDS = 5400  # 90 min (owner Q29 = C, 2026-11-06): the full suite no longer fits 60 min on this plan; + GRACE stays under IDLE
LOCK_CAP = rules.MAX_LOCK
EXIT_REFUSED = 3
# Past a step's limit the pipe closes; its writer then has this long to clean up and go. A writer that lives on (one
# stopped by a signal, say) ends the server, so the slot and the idle timer are not held for good.
GRACE_SECONDS = 900
HUNG = "the step outlived its limit"
STOPPED = "a run left a process, or its check did not finish, so this server takes no more trees: delete it and arm a new one"
# The listing passed its cap (lanes security M1): this lane's trees past it are never read. Said once per server in a
# pushed result, under this name, and at every look in the journal. Trees inside the cap still run.
LISTING_CUT = "listing-cut"


def cut_words(cut, lane):
    return (f"the listing of vps/l{lane}-* refs passed its cap: {cut} refs were not read, so a tree pushed now may "
            f"never run here. Delete old vps/l{lane}-* refs from the scratch repo, then push the tree again\n")


def as_user(user, *args):
    return [*SUDO, user, *PROGRAM, *args]


# The only codes that let the server go on: runctl's own, given after a clean check (runctl.RUN_CODES), and a
# refused request, which never started a run.
GOES_ON = frozenset({0, rules.EXIT_RED, rules.EXIT_MEMORY, rules.EXIT_TIME, rules.EXIT_CLOSED, EXIT_REFUSED})


def ends_server(code, why):
    """An allow-list: only GOES_ON lets the server go on. Everything else stops it: EXIT_STRAY, Python's 1, sudo's
    128+N or a negative code for a runctl that died by a signal, no code at all, and a step that outlived its limit."""
    return why == HUNG or code not in GOES_ON


class Steps:
    """Each other user's work, by a fixed sudo rule and pipes. Only rights downward exist."""

    def _pipe(self, argv, cap, seconds, data=None, stderr=subprocess.STDOUT):
        """Past a limit the pipe closes and this waits. It cannot kill across users, and the slot stays busy until
        the writer has gone, so no later tree starts beside a live run. `vps.py` holds each command's own limit. A
        writer still alive after GRACE_SECONDS gives no code and HUNG, and the poller stops on that."""
        process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
        if data is not None:
            threading.Thread(target=self._feed, args=(process, data), daemon=True).start()
        else:
            process.stdin.close()
        out, why = results.read_capped(process, cap, time.monotonic() + seconds)
        process.stdout.close()
        try:
            code = process.wait(timeout=GRACE_SECONDS)
        except subprocess.TimeoutExpired:
            return None, out, HUNG
        return code, out, why

    @staticmethod
    def _feed(process, data):
        try:
            process.stdin.write(data)
            process.stdin.close()
        except OSError:
            pass

    def inspect(self, commit):
        # Its stdout is the lock's bytes, so nothing else may land in that pipe: a word from sudo would refuse every tree.
        return self._pipe(as_user("runner", "inspect", commit), LOCK_CAP + 4096, INSPECT_SECONDS, stderr=subprocess.DEVNULL)

    def fetch(self, lock):
        return self._pipe(as_user("fetcher", "fetch"), 4096, FETCH_SECONDS, data=lock)

    def run(self, commit, slot):
        return self._pipe(as_user("runner", "run", commit, str(slot)), results.MAX_OUTPUT, RUN_SECONDS)

    def scan(self, text):
        return self._pipe(as_user("runner", "scan-text"), 4096, INSPECT_SECONDS, data=text)


class Poller:
    """One slot, whatever the machine: a second is NOT BUILT (runctl.slots_for)."""

    def __init__(self, store, steps, say=print, lane=None):
        """`lane` is what root wrote at arming, unread until `arm`: with none, or a bad one, nothing is listed."""
        self.store, self.steps, self.say = store, steps, say
        self.given_lane, self.lane = lane, None
        self.seen = set()
        self.waiting = {}
        self.lock = threading.Lock()
        self.jobs = queue.Queue()
        self.busy = 0
        self.stopped = False
        self.cut_told, self.cut_waiting = False, 0
        self.stamp = str(int(time.time()))

    def arm(self):
        """No lane, no arming. Refs that exist now are old: only what appears later runs, in the order first seen."""
        self.lane = rules.lane_of(self.given_lane)
        listed, _, _ = self.store.list_refs(self.lane)
        self.seen.update(listed)

    def look(self):
        if self.lane is None:
            raise rules.Refused(rules.NO_LANE)
        listed, ignored, cut = self.store.list_refs(self.lane)
        if ignored:
            self.say(f"ignored {ignored} refs with names or hashes that are not allowed")
        for ref, value in rules.new_refs(listed, self.seen):
            self.seen.add((ref, value))
            task = rules.task_of(ref)
            with self.lock:
                self.waiting.pop(task, None)
                self.waiting[task] = (ref, value)
        # The pushed word goes through the one slot like any result: its scan is a container of runner's, which must
        # never overlap a run's own after-the-run count. Waits until a push of it has worked.
        if cut:
            self.say(cut_words(cut, self.lane).strip())
            with self.lock:
                if not self.cut_told:
                    self.cut_waiting = cut

    def next_job(self):
        with self.lock:
            if not self.waiting:
                return None
            task = next(iter(self.waiting))
            return self.waiting.pop(task)

    def active(self):
        """Once stopped, waiting refs are not work: the idle timer may then stop the server."""
        with self.lock:
            return (bool(self.waiting) and not self.stopped) or self.busy > 0

    def stop(self):
        with self.lock:
            self.stopped = True

    def process(self, ref, value, slot):
        """The whole path for one ref. Any refusal becomes a result, red, naming the rule. Anything but a run's own
        exit code from a finished check stops this poller taking trees for good: arming is once per server."""
        tree = value
        status, body = "red", b""
        try:
            self.store.fetch(ref, value)
            tree = self.store.tree_of(value)
            if self.stopped:
                raise rules.Refused(STOPPED)
            code, out, why = self.steps.inspect(value)
            if code != 0 or why != "ended":
                body = out[:4096]
                if why == HUNG:
                    self.stop()
                    body += f"\n{STOPPED}\n".encode()
            else:
                code, out, why = self.steps.fetch(out)
                if code != 0 or why != "ended":
                    body = out
                    if why == HUNG:
                        self.stop()
                        body += f"\n{STOPPED}\n".encode()
                else:
                    try:
                        code, body, why = self.steps.run(value, slot)
                    except Exception:  # Whether runctl ran its check is then unknown.
                        code, body, why = None, b"the run step failed on the server", "the step failed"
                    if why != "ended":
                        body += f"\nstopped: {why}\n".encode()
                    if ends_server(code, why):
                        self.stop()
                        body += f"\n{STOPPED}\n".encode()
                    elif why == "ended" and code == 0:
                        status = "green"
        except (rules.Refused, subprocess.SubprocessError, OSError) as error:
            body = str(error).encode() if isinstance(error, rules.Refused) else b"a step failed on the server"
        self.report(tree, status, body)

    def report(self, tree, status, body):
        text = results.compose(tree, status, body, self.lane)
        code, _, why = self.steps.scan(text)
        if why == HUNG:
            self.stop()
        if code != 0 or why != "ended":
            text = results.compose(tree, "red", b"the secret scan stopped this result; no value is reported", self.lane)
        self.store.push_text(f"results/{tree}-{self.stamp}", "result.txt", text)

    def _worker(self, slot):
        while True:
            ref, value = self.jobs.get()
            try:
                if ref == LISTING_CUT:  # Never a ref: every ref name starts vps/.
                    self.tell_cut(value)
                else:
                    self.process(ref, value, slot)
            except Exception as error:  # A failed result must not stop the poller.
                self.say(f"could not finish {value}: {type(error).__name__}")
            finally:
                with self.lock:
                    self.busy -= 1

    def tell_cut(self, cut):
        """Once per server, once its push has worked; a failed one is tried again at the next look."""
        self.report(LISTING_CUT, "red", cut_words(cut, self.lane).encode())
        with self.lock:
            self.cut_told = True

    def dispatch(self):
        """Hands the listing's cut, then a waiting ref, to the one slot, if it is free."""
        with self.lock:
            if self.stopped or self.busy:
                return
            if self.cut_waiting:
                self.busy += 1
                job, self.cut_waiting = (LISTING_CUT, self.cut_waiting), 0
                self.jobs.put(job)
                return
        job = self.next_job()
        if job is None:
            return
        with self.lock:
            self.busy += 1
        self.jobs.put(job)

    def forever(self, touch, sleep_seconds=60):
        threading.Thread(target=self._worker, args=(0,), daemon=True).start()
        while True:
            try:
                self.look()
            except (rules.Refused, subprocess.SubprocessError, OSError):
                self.say("could not list refs")
            self.dispatch()
            if self.active():
                touch()
            time.sleep(sleep_seconds)
