"""What a pushed tree may be. Pure checks on data: nothing here runs, opens or fetches anything."""
import re
import tomllib

REF = re.compile(r"vps/[a-z0-9][a-z0-9-]{0,40}")
# A server takes only its own lane's trees: `vps/l<lane>-<task>-<8 hex>`, inside REF as well.
LANE_REF = re.compile(r"vps/l([1-9])-[a-z0-9][a-z0-9-]*-[0-9a-f]{8}")
LANES = "123456789"
NO_LANE = "no lane, or a lane that is not one digit 1 to 9: this server does not arm"
HASH = re.compile(r"[0-9a-f]{40}")
MAX_REFS = 500
MAX_NEW_PER_LOOK = 20
MAX_FILES = 20_000
MAX_BLOB = 32 * 1024 * 1024
MAX_TOTAL = 512 * 1024 * 1024
MAX_PATH = 400
MAX_DEPTH = 24
MAX_LOCK = 1024 * 1024
MAX_CI = 256 * 1024
MAX_CRATES = 2000
CRATES_IO = "registry+https://github.com/rust-lang/crates.io-index"
OWN_CRATE = "tft-exchange"
# The one other crate built from the tree (#155's engine, owner Q7). No other name may be sourceless.
MEMBER_CRATE = "engine-core"
KEPT_DOC = "docs/RUNBOOK.md"
CI_FILE = ".github/workflows/ci.yml"
LOCK_FILE = "Cargo.lock"
NOT_MATCHED = "this snapshot does not match"
# A run's exit when it left a process or the check could not tell: the poller then takes no more trees. Not 120:
# that is Python's own exit when it cannot flush stdout, and the two must be told apart.
EXIT_STRAY = 123
# runctl's own codes for a run whose check finished clean. The tree never picks runctl's exit: its own code is
# mapped to one of these, all below 128, so 128+N only ever means runctl itself died (runctl.own_code).
EXIT_RED = 121
EXIT_MEMORY = 122
EXIT_TIME = 124
EXIT_CLOSED = 125

_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}")
_VERSION = re.compile(r"[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]{1,40})?(\+[0-9A-Za-z.-]{1,40})?")
_SHA256 = re.compile(r"[0-9a-f]{64}")
_LOCK_KEYS = {"name", "version", "source", "checksum", "dependencies"}


class Refused(Exception):
    """This tree does not run. The text names the rule and holds nothing from the branch."""


def ref_is_good(name):
    return REF.fullmatch(name) is not None


def hash_is_good(value):
    return HASH.fullmatch(value) is not None


def lane_of(raw):
    """The lane root wrote at arming, as one digit 1 to 9, an optional newline after it. Anything else refuses."""
    if isinstance(raw, bytes):
        raw = raw.decode("ascii", "replace")
    if not isinstance(raw, str):
        raise Refused(NO_LANE)
    text = raw[:-1] if raw.endswith("\n") else raw
    if len(text) != 1 or text not in LANES:
        raise Refused(NO_LANE)
    return text


def in_lane(name, lane):
    match = LANE_REF.fullmatch(name)
    return match is not None and ref_is_good(name) and match.group(1) == lane


def parse_ls_remote(output, lane=None):
    """Each good (ref name, hash) from `git ls-remote` bytes, how many lines were ignored, and how many refs were cut:
    past the first MAX_REFS * 2 lines, or good past MAX_REFS. A cut ref is never read, so its caller must say so
    (lanes security M1): a cut is never silent. With a lane, a good name of another lane, or with no lane, is ignored
    and counted too."""
    good, ignored = [], 0
    lines = [line for line in output.split(b"\n") if line]
    cut = max(0, len(lines) - MAX_REFS * 2)
    for line in lines[: MAX_REFS * 2]:
        try:
            value, _, ref = line.decode("ascii").partition("\t")
        except UnicodeDecodeError:
            ignored += 1
            continue
        name = ref.removeprefix("refs/heads/")
        if name.startswith("results/"):
            continue
        if ref.startswith("refs/heads/") and ref_is_good(name) and hash_is_good(value) and (lane is None or in_lane(name, lane)):
            good.append((name, value))
        else:
            ignored += 1
    return good[:MAX_REFS], ignored, cut + max(0, len(good) - MAX_REFS)


def new_refs(listed, seen):
    """Refs not seen before, in listing order, capped per look. `seen` holds (name, hash) pairs."""
    return [pair for pair in listed if pair not in seen][:MAX_NEW_PER_LOOK]


def task_of(ref):
    """`vps/<task>-<8 hex>` gives <task>; any other good name is its own task."""
    match = re.fullmatch(r"vps/(.+)-[0-9a-f]{8}", ref)
    return match.group(1) if match else ref.removeprefix("vps/")


def parse_ls_tree(output):
    """(mode, kind, hash, size, path bytes) from `git ls-tree -r -l -z`."""
    entries = []
    for record in output.split(b"\0"):
        if not record:
            continue
        head, tab, path = record.partition(b"\t")
        fields = head.split()
        if not tab or len(fields) != 4:
            raise Refused("a tree line could not be read")
        mode, kind, value, size = (field.decode("ascii", "replace") for field in fields)
        entries.append((mode, kind, value, size, path))
    return entries


def _path_problem(path):
    try:
        text = path.decode("utf-8")
    except UnicodeDecodeError:
        return "a path is not UTF-8"
    if len(path) > MAX_PATH or text.count("/") > MAX_DEPTH:
        return "a path is too long or too deep"
    if any(ord(c) < 32 or ord(c) == 127 for c in text) or "\\" in text:
        return "a path holds a control character or a backslash"
    parts = text.split("/")
    folded = [part.casefold() for part in parts]
    if any(part in ("", ".", "..", ".git") for part in folded):
        return "a path has an unsafe part"
    for part in folded:
        if part.startswith(".cargo"):
            return "a .cargo path: the server supplies cargo's config"
        if part.startswith("rust-toolchain"):
            return "a rust-toolchain file: the server supplies the compiler"
        if part in (".gitleaksignore", ".gitmodules"):
            return "a file that changes the scan or adds submodules"
    if folded[0] == ".claude" or folded == ["readme.md"]:
        return "a left-out path"
    if folded[0] == "docs" and text != KEPT_DOC:
        return "a left-out path"
    return None


def check_tree(entries):
    """Refuses before any network. Links and submodules go by mode, so no later step meets one."""
    if len(entries) > MAX_FILES:
        raise Refused("the tree has too many files")
    total = 0
    found = set()
    for mode, kind, _, size, path in entries:
        if kind != "blob" or mode not in ("100644", "100755"):
            raise Refused("a link, submodule or unknown mode: only plain files run here")
        if not size.isascii() or not size.isdigit() or int(size) > MAX_BLOB:
            raise Refused("a file is too large")
        total += int(size)
        if total > MAX_TOTAL:
            raise Refused("the tree is too large")
        problem = _path_problem(path)
        if problem:
            raise Refused(problem)
        found.add(path)
    for needed in (LOCK_FILE, CI_FILE):
        if needed.encode() not in found:
            raise Refused(f"{needed} is missing or not a plain file")


def check_commit(raw):
    """A pushed commit has no parent: no history crosses."""
    head = raw.split(b"\n\n", 1)[0]
    if any(line.startswith(b"parent ") for line in head.split(b"\n")):
        raise Refused("the commit has a parent: only a parentless tree is taken")


def check_ci(text, pins):
    """The branch's versions are compared and never used. Any difference goes red."""
    images = set(re.findall(r"^\s*image:\s*(\S+)\s*$", text, re.M))
    versions = set(re.findall(r"^\s*RUST_VERSION:\s*(\S+)\s*$", text, re.M))
    if images != {pins["IMAGE_TIMESCALE"], pins["IMAGE_PLAIN"]} or versions != {pins["RUST_VERSION"]}:
        raise Refused(NOT_MATCHED)


def read_lock(raw):
    """(name, version, sha256) of every crate to download. Reads it all, or refuses it all."""
    if len(raw) > MAX_LOCK:
        raise Refused("the lock is too large")
    try:
        lock = tomllib.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, tomllib.TOMLDecodeError):
        raise Refused("the lock could not be read") from None
    packages = lock.get("package")
    if set(lock) != {"version", "package"} or lock["version"] not in (3, 4):
        raise Refused("the lock has an unknown shape")
    if not isinstance(packages, list) or len(packages) > MAX_CRATES:
        raise Refused("the lock has an unknown shape")
    crates = set()
    own = member = 0
    for package in packages:
        if not isinstance(package, dict) or not set(package) <= _LOCK_KEYS:
            raise Refused("a lock entry has an unknown key")
        name, version = package.get("name"), package.get("version")
        if not isinstance(name, str) or not _NAME.fullmatch(name):
            raise Refused("a crate name is not allowed")
        if not isinstance(version, str) or not _VERSION.fullmatch(version):
            raise Refused("a crate version is not allowed")
        if "source" not in package:
            if name not in (OWN_CRATE, MEMBER_CRATE) or "checksum" in package:
                raise Refused("a lock entry has no crates.io source")
            if name == OWN_CRATE:
                own += 1
            else:
                member += 1
            continue
        checksum = package.get("checksum")
        if package["source"] != CRATES_IO or not isinstance(checksum, str) or not _SHA256.fullmatch(checksum):
            raise Refused("a lock entry is not a crates.io crate with a checksum")
        crates.add((name, version, checksum))
    if own != 1 or member > 1:
        raise Refused("the lock must hold exactly one sourceless entry for this crate, and at most one for engine-core")
    return sorted(crates)


def read_pins(text):
    """pins.txt as a dict. Plain KEY=value lines; nothing is evaluated."""
    pins = {}
    for line in text.splitlines():
        if line and not line.startswith("#"):
            key, _, value = line.partition("=")
            pins[key] = value
    return pins
