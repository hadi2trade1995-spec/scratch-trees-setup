"""Every boot of a clone, in order. Any failure means the poller is not armed, and the login message says so."""
import ipaddress
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.request

from . import rules
from .gitstore import ACCESS_OPEN, ACCESS_REFUSED, clean_env

PROGRAM = ("/usr/bin/python3", "-I", "/opt/tftvps/vps.py")
KEY_OPENS_REAL = 3
BOOT_CHAINS = ("boot_only", "boot_in", "boot_metadata")
HOST_ROWS = (
    ("ss", "-lntup"),
    ("ss", "-xl"),
    ("id", "poller"),
    ("id", "fetcher"),
    ("id", "runner"),
    ("stat", "-c", "%a %U %n", "/home/poller", "/home/fetcher", "/home/runner", "/run/tftvps/poller"),
    ("nft", "list", "ruleset"),
    ("cat", "/opt/tftvps/manifest"),
)
MAX_AGE_DAYS = 30
IDLE_SECONDS = 2 * 3600
HARD_LIMIT_HOURS = 14
MAX_RANGES = 300
WIDEST_V4, WIDEST_V6 = 12, 28
META_URL = "https://api.github.com/meta"
ROOT = "/var/lib/tftvps"
RUN = "/run/tftvps"
ARMED_ONCE = f"{ROOT}/armed-once"
REBOOTED = f"{ROOT}/rebooted-for-kernel"
SEAL = "/opt/tftvps/sealed"
MESSAGE = f"{RUN}/message.txt"
ACTIVITY = f"{RUN}/activity"
ROWS = f"{RUN}/host-rows.txt"
KEY = f"{RUN}/poller/id_ed25519"
REAL_REPO = "git@github.com:hadi2trade1995-spec/tft-exchange.git"
PATCH_ENV = {"DEBIAN_FRONTEND": "noninteractive", "NEEDRESTART_MODE": "l"}
# Phased updates would otherwise read as "not upgraded", differently on each clone, and refuse a good server.
PHASED = ("-o", "APT::Get::Always-Include-Phased-Updates=true")
UPGRADE = ("apt-get", "-y", "-o", "Dpkg::Options::=--force-confold", *PHASED, "full-upgrade")
SIMULATE = ("apt-get", "-s", *PHASED, "full-upgrade")
KEY_WAIT_SECONDS = 20
# nft, runuser and usermod live in sbin, and gitstore's PATH is for git. Only boot gets this one.
SYSTEM_PATH = "/usr/sbin:/usr/bin:/sbin:/bin"
# Every program this file starts. A test holds this list to the code, and the build checks that each one resolves.
PROGRAMS = (
    "apt-get", "cat", "chown", "cloud-init", "getent", "gpasswd", "id", "nft", "passwd", "pgrep", "pkill", "runuser",
    "ss", "ssh-keygen", "stat", "sudo", "systemctl", "usermod",
)
UBUNTU_GROUPS = ("sudo", "adm", "lxd")
QUIET_TRIES = 30


class NotArmed(Exception):
    """The text goes on the login message."""


def run(*argv, env=None, check=True, data=None):
    done = subprocess.run(argv, capture_output=True, input=data, env=clean_env(PATH=SYSTEM_PATH, **(env or {})), check=False)
    if check and done.returncode != 0:
        raise NotArmed(f"{argv[0]} {argv[1] if len(argv) > 1 else ''} failed")
    return done


def as_user(user, *argv):
    return run("runuser", "-u", user, "--", *argv, check=False)


def age_problem(sealed_at, now, armed_before):
    """The first check at any boot. A second life on the same disk has no half-state: delete it."""
    if armed_before:
        return "this server was armed before and has lost its key: delete it and create another"
    if sealed_at is None:
        return "no seal on this disk: it was not built by the setup"
    days = (now - sealed_at) / 86400
    if days < -1 or days > MAX_AGE_DAYS:
        return f"the snapshot is past {MAX_AGE_DAYS} days old: build a new one"
    return None


def login_problems(shadow_root, authorized_files):
    """After cloud-init ended: root locked, and no key file a login could use."""
    found = []
    if not re.fullmatch(r"[!*].*", shadow_root):
        found.append("root is not locked")
    found += [f"{path} exists" for path in authorized_files]
    return found


def newest_kernel_differs(running, installed):
    """Is a newer kernel on disk than the one running? Versions compare numerically, part by part."""
    def version(name):
        return [int(part) for part in re.split(r"[.-]", name) if part.isdigit()]

    return bool(installed) and max(installed, key=version) != running


def nothing_left_to_upgrade(simulated):
    """`apt-get -s full-upgrade` output: nothing held back, nothing to install."""
    match = re.search(r"^(\d+) upgraded, (\d+) newly installed, \d+ to remove and (\d+) not upgraded", simulated, re.M)
    return bool(match) and match.groups() == ("0", "0", "0")


def parse_ranges(raw):
    """GitHub's git ranges as (v4, v6). Refuses the lot if any entry is wrong, wide or private."""
    data = json.loads(raw)
    ranges = data.get("git") if isinstance(data, dict) else None
    if not isinstance(ranges, list) or not 0 < len(ranges) <= MAX_RANGES:
        raise NotArmed("GitHub's list of ranges could not be used")
    v4, v6 = [], []
    for entry in ranges:
        try:
            net = ipaddress.ip_network(entry, strict=True)
        except (TypeError, ValueError):
            raise NotArmed("GitHub's list held something that is not a range") from None
        widest = WIDEST_V4 if net.version == 4 else WIDEST_V6
        if net.prefixlen < widest or not net.is_global:
            raise NotArmed("GitHub's list held a range too wide or not public")
        (v4 if net.version == 4 else v6).append(str(net))
    return v4, v6


def ranges_script(v4, v6):
    lines = []
    if v4:
        lines.append("add element inet tftvps github4 { " + ", ".join(v4) + " }")
    if v6:
        lines.append("add element inet tftvps github6 { " + ", ".join(v6) + " }")
    return "\n".join(lines) + "\n"


def listener_problems(ss_output):
    """`ss -lntuH`. Nothing may listen but the DHCP client's port."""
    bad = []
    for line in ss_output.splitlines():
        fields = line.split()
        if len(fields) >= 5 and not (fields[0] == "udp" and fields[4].endswith(":68")):
            bad.append(fields[4])
    return bad


def order(steps):
    """Runs named steps in order. The first failure stops the rest, so nothing after it happens."""
    for _, step in steps:
        step()


def key_verdict(store, real_repo, stamp):
    """The real repo first, because a deploy key sits on one repo: a key added there by mistake is refused on the
    new one, and would otherwise wait for ever with no word. Only a plain refusal counts: a network failure there
    proves nothing, so it never arms. Then the new repo, a test push, and the real repo again."""
    first = store.access(real_repo)
    if first == ACCESS_OPEN:
        return KEY_OPENS_REAL
    if first != ACCESS_REFUSED or store.access(store.url) != ACCESS_OPEN:
        return 1
    try:
        store.push_text(f"results/key-test-{stamp}", "result.txt", b"VPS RESULT, NOT PROOF, key test\n")
    except rules.Refused:
        return 1
    after = store.access(real_repo)
    if after == ACCESS_OPEN:
        return KEY_OPENS_REAL
    return 0 if after == ACCESS_REFUSED else 1


def hosts_lines(github_address, hostname):
    """`poller` has no DNS, and sudo asks for this machine's own name: a miss would print into its pipes."""
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]{0,252}", hostname):
        raise NotArmed("this machine's name could not be used")
    return f"{github_address} github.com\n127.0.1.1 {hostname}\n"


def ubuntu_problems(shadow_hash, shell, groups, processes, sudo_list):
    """After login closes, `ubuntu` must have no way back. Each of these blocks arming."""
    found = []
    if not re.fullmatch(r"[!*].*", shadow_hash):
        found.append("ubuntu's password is not locked")
    if shell != "/usr/sbin/nologin":
        found.append("ubuntu still has a shell")
    held = sorted(set(groups.split()) & set(UBUNTU_GROUPS))
    if held:
        found.append(f"ubuntu is still in {' '.join(held)}")
    if processes.strip():
        found.append("ubuntu still has processes")
    if "is not allowed to run sudo" not in sudo_list:
        found.append("ubuntu can still use sudo")
    return found


class Boot:
    def self_check(self):
        run("cloud-init", "status", "--wait", check=False)
        for path in ("/root/.ssh/authorized_keys", "/home/ubuntu/.ssh/authorized_keys"):
            if os.path.exists(path):
                os.remove(path)
        run("passwd", "-l", "root")
        with open("/etc/shadow", encoding="ascii") as held:
            root = next(line.split(":")[1] for line in held if line.startswith("root:"))
        leftover = [p for p in ("/root/.ssh/authorized_keys", "/home/ubuntu/.ssh/authorized_keys") if os.path.exists(p)]
        problems = login_problems(root, leftover)
        sealed = float(open(SEAL, encoding="ascii").read().split()[0]) if os.path.exists(SEAL) else None
        problem = age_problem(sealed, time.time(), os.path.exists(ARMED_ONCE))
        if problem or problems:
            raise NotArmed(problem or "; ".join(problems))

    def patch(self):
        """A kernel fix usually comes as a new package, so full-upgrade, then check what it did."""
        run("apt-get", "update", env=PATCH_ENV)
        run(*UPGRADE, env=PATCH_ENV)
        simulated = run(*SIMULATE, env=PATCH_ENV).stdout.decode("utf-8", "replace")
        if not nothing_left_to_upgrade(simulated):
            raise NotArmed("packages are still waiting after the upgrade")
        installed = [name.removeprefix("vmlinuz-") for name in os.listdir("/boot") if name.startswith("vmlinuz-")]
        if newest_kernel_differs(os.uname().release, installed):
            if os.path.exists(REBOOTED):
                raise NotArmed("the newest kernel is not running after a reboot")
            open(REBOOTED, "w", encoding="ascii").close()
            run("systemctl", "reboot")
            raise NotArmed("rebooting into the new kernel")

    def network(self):
        """GitHub's ranges and a hosts line for `poller`, whose DNS is closed."""
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(META_URL, timeout=30) as response:
            v4, v6 = parse_ranges(response.read(4 * 1024 * 1024))
        run("nft", "-f", "-", data=ranges_script(v4, v6).encode())
        answer = run("getent", "ahostsv4", "github.com").stdout.decode().split()
        nets = [ipaddress.ip_network(net) for net in v4]
        good = [a for a in answer[:1] if any(ipaddress.ip_address(a) in net for net in nets)]
        if not good:
            raise NotArmed("github.com did not resolve inside GitHub's ranges")
        with open("/etc/hosts", "a", encoding="ascii") as held:
            held.write(hosts_lines(good[0], socket.gethostname()))

    def self_test(self):
        """Before any key: `runner` is refused, `fetcher` is not, so the refusal means something."""
        if as_user("runner", *PROGRAM, "probe").returncode == 0:
            raise NotArmed("runner reached the network")
        if as_user("fetcher", *PROGRAM, "probe").returncode != 0:
            raise NotArmed("fetcher could not reach the network, so the check means nothing")
        if as_user("runner", *PROGRAM, "planted-failure").returncode != 0:
            raise NotArmed("a container did not pass a true command and fail a false one")

    def make_key(self):
        os.makedirs(os.path.dirname(KEY), mode=0o700, exist_ok=True)
        run("chown", "poller:poller", os.path.dirname(KEY))
        if as_user("poller", "ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "scratch-trees-vps", "-f", KEY).returncode != 0:
            raise NotArmed("the key could not be made")

    def show_key(self):
        with open(KEY + ".pub", encoding="ascii") as held:
            public = held.read().strip()
        fingerprint = run("ssh-keygen", "-lf", KEY + ".pub").stdout.decode().split()[1]
        seal = open(SEAL, encoding="ascii").read().strip()
        say(f"Add this deploy key to scratch-trees-vps, with write access:\n\n{public}\n\nFingerprint to compare: {fingerprint}\nSeal: {seal}\n")

    def key_works(self):
        """Waits for the owner to add the key. A key that opens the real repo stops everything."""
        while True:
            code = as_user("poller", *PROGRAM, "key-test").returncode
            if code == 0:
                return
            if code == KEY_OPENS_REAL:
                raise NotArmed("THIS KEY OPENS tft-exchange. Delete the key on GitHub now, and delete this server")
            time.sleep(KEY_WAIT_SECONDS)

    def host_rows(self):
        """Self-report, for security to read: catches mistakes, not a malicious build. Carried out by the poller."""
        rows = []
        for argv in HOST_ROWS:
            done = run(*argv, check=False)
            rows.append(f"$ {' '.join(argv)}\n{done.stdout.decode('utf-8', 'replace')}{done.stderr.decode('utf-8', 'replace')}")
        with open(SEAL, encoding="ascii") as held:
            rows.insert(0, f"VPS RESULT, NOT PROOF, host rows, seal {held.read().strip()}\n")
        with open(ROWS, "w", encoding="utf-8") as held:
            held.write("\n".join(rows))
        run("chown", "poller:poller", ROWS)

    def close_ubuntu(self):
        """The commands may fail one by one. What counts is the check after them, which blocks arming."""
        entry = run("getent", "passwd", "ubuntu").stdout.decode("ascii", "replace").strip().split(":")
        # Its whole slice: a root process started through sudo in that session is not `ubuntu`'s by user.
        run("systemctl", "kill", "--signal=KILL", f"user-{entry[2]}.slice", check=False)
        run("usermod", "-L", "-s", "/usr/sbin/nologin", "ubuntu", check=False)
        for group in UBUNTU_GROUPS:
            run("gpasswd", "-d", "ubuntu", group, check=False)
        for name in ("90-cloud-init-users", "ubuntu"):
            path = f"/etc/sudoers.d/{name}"
            if os.path.exists(path):
                os.remove(path)
        for _ in range(QUIET_TRIES):
            run("pkill", "-KILL", "-u", "ubuntu", check=False)
            if not run("pgrep", "-u", "ubuntu", check=False).stdout.strip():
                break
            time.sleep(1)
        with open("/etc/shadow", encoding="ascii") as held:
            shadow = next(line.split(":")[1] for line in held if line.startswith("ubuntu:"))
        shell = run("getent", "passwd", "ubuntu").stdout.decode("ascii", "replace").strip().split(":")[-1]
        groups = run("id", "-nG", "ubuntu").stdout.decode("ascii", "replace")
        processes = run("pgrep", "-u", "ubuntu", check=False).stdout.decode("ascii", "replace")
        sudo_list = run("sudo", "-l", "-U", "ubuntu", check=False).stdout.decode("ascii", "replace")
        problems = ubuntu_problems(shadow, shell, groups, processes, sudo_list)
        if problems:
            raise NotArmed("login did not close: " + "; ".join(problems))

    def close_login(self):
        """Blocks arming: no sshd left, no login user, no network for root or apt, nothing listening."""
        run("systemctl", "disable", "--now", "ssh.socket", "ssh.service", check=False)
        run("systemctl", "mask", "ssh.socket", "ssh.service", check=False)
        run("pkill", "-KILL", "-x", "sshd", check=False)
        self.close_ubuntu()
        run("apt-get", "-y", "purge", "openssh-server", env=PATCH_ENV, check=False)
        for chain in BOOT_CHAINS:
            run("nft", "flush", "chain", "inet", "tftvps", chain)
        output = run("ss", "-lntuH").stdout.decode("ascii", "replace")
        bad = listener_problems(output)
        if bad or os.path.exists("/usr/sbin/sshd"):
            raise NotArmed(f"login did not close: {bad or 'sshd is still installed'}")

    def arm(self):
        open(ARMED_ONCE, "w", encoding="ascii").close()
        # The poller is After this unit, so a start that waited would wait on this very step, for ever.
        run("systemctl", "start", "--no-block", "tftvps-poller.service")
        say("Armed. Login is closed. Deleting the server is what stops the bill.\n")


def say(text):
    """Login message and console. A failed console is not a reason to stop."""
    os.makedirs(RUN, exist_ok=True)
    with open(MESSAGE, "w", encoding="ascii") as held:
        held.write(text)
    try:
        with open("/dev/console", "w", encoding="ascii") as held:
            held.write(text)
    except OSError:
        pass


def boot():
    machine = Boot()
    os.makedirs(RUN, exist_ok=True)
    os.chmod(RUN, 0o755)
    open(ACTIVITY, "a", encoding="ascii").close()
    run("chown", "poller:poller", ACTIVITY)
    steps = [
        ("self check", machine.self_check),
        ("patch", machine.patch),
        ("network", machine.network),
        ("self test", machine.self_test),
        ("make key", machine.make_key),
        ("show key", machine.show_key),
        ("key works", machine.key_works),
        ("close login", machine.close_login),
        ("host rows", machine.host_rows),
        ("arm", machine.arm),
    ]
    try:
        order(steps)
    except (NotArmed, OSError, ValueError, subprocess.SubprocessError) as error:
        say(f"NOT ARMED: {error}\nDelete this server. Agents' work waits.\n")
        return 1
    return 0


def missing_programs(find=shutil.which):
    return [name for name in PROGRAMS if find(name, path=SYSTEM_PATH) is None]


def check_programs():
    """Run by the build: a program boot needs and cannot find fails there, not on a clone."""
    missing = missing_programs()
    if missing:
        print("boot cannot find: " + " ".join(missing), file=sys.stderr)
        return 1
    return 0


def idle_stop_due(now, boot_time, activity_time):
    return now - max(boot_time, activity_time) > IDLE_SECONDS


def idle_check():
    """Root's timer. A stuck poller stops touching the file, which reads as idle. That is the right way to fail."""
    with open("/proc/uptime", encoding="ascii") as held:
        booted = time.time() - float(held.read().split()[0])
    touched = os.stat(ACTIVITY).st_mtime if os.path.exists(ACTIVITY) else 0
    if idle_stop_due(time.time(), booted, touched):
        run("systemctl", "poweroff")
    return 0
