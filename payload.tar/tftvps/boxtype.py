"""The box's type, read once by root while the boot window is open, and stamped into every result header (BT-L3-TOOL).

The branch never writes it and never reads it from an environment variable. The authority is root's file:
`<source> <type> <allowed|not-allowed>`, written whole and renamed in. A speed figure counts only from a result whose
header says `speed-box: ALLOWED`; no line, or any other word, is VOID-SPEED. The list of allowed types is
`speed_types` in profile.json, sealed with the image, and it is the owner's (it holds `ec2 m8id.4xlarge`, his word 2026-11-22)."""
import collections
import http.client
import os
import re
import urllib.request

from . import rules

DMI_VENDOR = "/sys/class/dmi/id/sys_vendor"
DMI_PRODUCT = "/sys/class/dmi/id/product_name"
IMDS = "http://169.254.169.254/latest"
WORD = re.compile(r"[A-Za-z0-9._ -]{1,64}")
TOKEN = re.compile(r"[A-Za-z0-9+/=_-]{1,64}")
MAX_ANSWER = 64
MAX_FILE = 200
TIMEOUT = 2
SOURCES = ("ec2", "dmi", "unknown")
NO_BOX = "no box type file, or one that is not `<source> <type> <allowed|not-allowed>`: this server does not arm"
Box = collections.namedtuple("Box", "source type allowed")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None  # urllib then raises the 3xx as an error: no redirect is followed


def _opener():
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect)


def _ask(request, opener):
    """At most 64 bytes of ASCII, or an error. The caller turns every error into `unknown`."""
    with opener.open(request, timeout=TIMEOUT) as response:
        raw = response.read(MAX_ANSWER + 1)
    if len(raw) > MAX_ANSWER:
        raise ValueError("answer too long")
    return raw.decode("ascii")


def imds_type(opener=None):
    """IMDSv2 only: a PUT for a token, then a GET with it. No curl, no proxy, no redirect, 2 s each, 64 bytes each.
    None on any error, any IMDSv1-style answer, or any answer outside the allowed characters."""
    opener = opener or _opener()
    try:
        put = urllib.request.Request(f"{IMDS}/api/token", method="PUT", headers={"X-aws-ec2-metadata-token-ttl-seconds": "60"})
        token = _ask(put, opener)
        if not TOKEN.fullmatch(token):
            return None
        get = urllib.request.Request(f"{IMDS}/meta-data/instance-type", headers={"X-aws-ec2-metadata-token": token})
        kind = _ask(get, opener)
    except (OSError, ValueError, http.client.HTTPException):
        return None
    return kind if WORD.fullmatch(kind) else None


def read_dmi(path):
    """One DMI line, or None (missing, too long, odd characters)."""
    try:
        with open(path, "rb") as held:
            raw = held.read(MAX_ANSWER + 1)
        text = raw.decode("ascii").strip()
    except (OSError, ValueError):
        return None
    return text if WORD.fullmatch(text) else None


def decide(vendor, product, imds, allowed):
    """(source, type, allowed?). DMI first, with no network: IMDS is asked only when DMI says Amazon, and `ec2` is
    written only when IMDSv2 then answered. Anything else on a non-Amazon box is `dmi <vendor>_<product>`, which is
    on the list only if the owner put it there. `allowed` is the profile's list of `<source> <type>` words."""
    if vendor is None:
        source, kind = "unknown", "unknown"
    elif vendor.lower().startswith("amazon"):
        asked = imds()
        source, kind = ("ec2", asked) if asked else ("unknown", "unknown")
    else:
        joined = f"{vendor}_{product}".replace(" ", "_") if product else ""
        source, kind = ("dmi", joined) if WORD.fullmatch(joined) else ("unknown", "unknown")
    listed = isinstance(allowed, list) and f"{source} {kind}" in allowed
    return source, kind, source != "unknown" and listed


def speed_types(profile):
    """The profile's list, or an empty one when it is missing or not a list of strings (closed, not open)."""
    found = profile.get("speed_types") if isinstance(profile, dict) else None
    ok = isinstance(found, list) and all(isinstance(item, str) for item in found)
    return found if ok else []


def line_of(source, kind, allowed):
    return f"{source} {kind} {'allowed' if allowed else 'not-allowed'}\n"


def write_box(path, source, kind, allowed, armed_once):
    """Root, once, before arming. Written whole, then renamed in, so no reader sees half a file. After arming it is
    refused: the box's word never changes under the poller."""
    if os.path.exists(armed_once):
        raise rules.Refused("this server is armed: its box type is fixed")
    partial = path + ".new"
    try:
        os.remove(partial)
    except FileNotFoundError:
        pass
    handle = os.open(partial, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    with os.fdopen(handle, "w", encoding="ascii") as held:
        held.write(line_of(source, kind, allowed))
    os.replace(partial, path)


def parse(raw):
    """Root's file as a Box, or Refused. Strict: three or more words, a known source, a known verdict, and an
    `allowed` only for a source that is not `unknown`."""
    if isinstance(raw, bytes):
        raw = raw[:MAX_FILE + 1].decode("ascii", "replace")
    if not isinstance(raw, str) or len(raw) > MAX_FILE or not raw.endswith("\n") or raw.count("\n") != 1:
        raise rules.Refused(NO_BOX)
    words = raw[:-1].split(" ")
    if len(words) < 3 or words[0] not in SOURCES or words[-1] not in ("allowed", "not-allowed"):
        raise rules.Refused(NO_BOX)
    kind, allowed = " ".join(words[1:-1]), words[-1] == "allowed"
    if not WORD.fullmatch(kind) or (words[0] == "unknown" and (kind != "unknown" or allowed)):
        raise rules.Refused(NO_BOX)
    return Box(words[0], kind, allowed)


def header_lines(box):
    """The two fixed result lines, after `lane:`. Positive rule: only `speed-box: ALLOWED` lets a speed figure count."""
    verdict = "ALLOWED" if box.allowed else "NOT ALLOWED (VOID-SPEED)"
    return f"box: {box.source} {box.type}\nspeed-box: {verdict}\n"
