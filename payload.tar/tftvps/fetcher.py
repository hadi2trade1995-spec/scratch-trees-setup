"""Crates as plain files. No cargo with the network on. The whole lock is read before the first download."""
import hashlib
import os
import urllib.error
import urllib.request

from . import rules

MAX_CRATE = 64 * 1024 * 1024
BASE = "https://static.crates.io/crates"


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        raise urllib.error.URLError("a redirect was refused")


def opener():
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect()).open


def url_for(name, version):
    return f"{BASE}/{name}/{name}-{version}.crate"


def _matches(path, sha256):
    try:
        with open(path, "rb") as held:
            return hashlib.sha256(held.read()).hexdigest() == sha256
    except FileNotFoundError:
        return False


def fetch_all(raw_lock, folder, open_url=None):
    """Refused before any network if any lock entry is wrong. A bad checksum stores nothing."""
    crates = rules.read_lock(raw_lock)
    open_url = open_url or opener()
    for name, version, sha256 in crates:
        final = os.path.join(folder, f"{name}-{version}.crate")
        if _matches(final, sha256):
            continue
        with open_url(url_for(name, version), timeout=60) as response:
            body = response.read(MAX_CRATE + 1)
        if len(body) > MAX_CRATE:
            raise rules.Refused("a crate is too large")
        if hashlib.sha256(body).hexdigest() != sha256:
            raise rules.Refused("a crate does not match the lock's checksum")
        partial = final + ".partial"
        with open(partial, "wb") as held:
            held.write(body)
        os.chmod(partial, 0o644)
        os.replace(partial, final)
    return len(crates)
