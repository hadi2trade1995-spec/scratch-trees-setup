"""Branch-written text coming back. Bytes over a pipe, capped by the reader, stripped, under a fixed header."""
import os
import selectors
import time
import unicodedata

MAX_OUTPUT = 8 * 1024 * 1024
MAX_LINE = 2000
MAX_RESULT = 2 * 1024 * 1024


def header(tree):
    return f"VPS RESULT, NOT PROOF, tree {tree}\n"


def read_capped(process, cap, deadline, now=time.monotonic):
    """Reads stdout until end, the cap or the deadline. Gives (bytes, why). It never kills: the writer runs as
    another user, so the kernel would refuse. The caller closes the pipe and waits for the writer to go."""
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ)
    os.set_blocking(process.stdout.fileno(), False)
    held, size, why = [], 0, "ended"
    while True:
        left = deadline - now()
        if left <= 0:
            why = "time limit"
            break
        if not selector.select(timeout=min(left, 5)):
            continue
        chunk = process.stdout.read(65536)
        if chunk == b"":
            break
        if chunk is None:
            continue
        held.append(chunk)
        size += len(chunk)
        if size > cap:
            why = "output limit"
            break
    selector.close()
    return b"".join(held)[:cap], why


def clean(raw, max_line=MAX_LINE, max_total=MAX_RESULT):
    """No control or format characters (so no escapes, no bidi), lines and total capped."""
    text = raw.decode("utf-8", "replace").replace("\r\n", "\n").replace("\r", "\n")
    kept = "".join(c for c in text if c in "\n\t" or unicodedata.category(c) not in ("Cc", "Cf", "Co", "Cs", "Cn"))
    lines = [line[:max_line] + (" [line cut]" if len(line) > max_line else "") for line in kept.split("\n")]
    body = "\n".join(lines)
    if len(body) > max_total:
        body = body[:max_total] + "\n[output cut]\n"
    return body


def compose(tree, status, raw, lane=None):
    """The first lines are fixed and come before anything from the branch. The lane is the server's, never the tree's."""
    lane_line = f"lane: {lane}\n" if lane is not None else ""
    return (header(tree) + f"status: {status}\n{lane_line}\n" + clean(raw)).encode("utf-8", "replace")
