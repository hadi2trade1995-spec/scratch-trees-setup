#!/bin/bash
# Fixed steps inside the run container: the same as CI's `checks`. Comes from the snapshot, never the branch.
set -u
fail=0
# A run that meets the memory limit names it by the kernel's own count for this container, not by a guess.
# shellcheck disable=SC2329 # invoked by the trap below, at every exit
memory_word() {
  local key value kills=unreadable
  # A sampler still running (a step cut short) ends with the script: no process outlives it.
  [ -z "${sampler:-}" ] || kill "$sampler" 2>/dev/null
  while read -r key value; do
    [ "$key" = oom_kill ] && kills=$value
  done 2>/dev/null </sys/fs/cgroup/memory.events
  echo "=== Memory limit: oom_kill $kills"
  # The cgroup's own high-water mark against its limit, read only (plan item 8c), so headroom is a number, not a guess.
  echo "=== Memory peak: $(cat /sys/fs/cgroup/memory.peak 2>/dev/null || echo unreadable) of $(cat /sys/fs/cgroup/memory.max 2>/dev/null || echo unreadable) bytes"
}
trap memory_word EXIT

# OOM plan v2 (2.2): what a step holds while it runs. memory.peak sits at the limit after the first build, and a line
# after a step sees only what is left, so a sampler reads memory.stat once a second during the step and keeps the
# sample with the most memory that cannot be dropped at once: anon + shmem (tmpfs) + dirty + writeback. Every field is
# digits or `unreadable`, read again at print time, so nothing a run writes reaches the line as text. The numbers are
# for people: no gate reads them. The kernel's kill count stays on the exit line alone.
sampler="" some_before=unreadable full_before=unreadable
SAMPLE_FIELDS="anon shmem file file_dirty file_writeback"
memory_sampler() {
  local out=$1 key value name anon shmem file file_dirty file_writeback held best=-1 samples=0 sleeper=""
  local kept="unreadable unreadable unreadable unreadable unreadable unreadable"
  trap '[ -z "$sleeper" ] || kill "$sleeper" 2>/dev/null; exit 0' TERM
  # Ends by itself if the script is gone, as well as by sample_stop's kill.
  while kill -0 "$$" 2>/dev/null; do
    anon=unreadable shmem=unreadable file=unreadable file_dirty=unreadable file_writeback=unreadable
    while read -r key value; do
      case $key in
        anon | shmem | file | file_dirty | file_writeback) printf -v "$key" '%s' "$value" ;;
      esac
    done 2>/dev/null </sys/fs/cgroup/memory.stat
    for name in $SAMPLE_FIELDS; do
      [[ ${!name} =~ ^[0-9]+$ ]] || printf -v "$name" unreadable
    done
    samples=$((samples + 1))
    if [[ $anon$shmem$file_dirty$file_writeback =~ ^[0-9]+$ ]]; then
      held=$((anon + shmem + file_dirty + file_writeback))
      if [ "$held" -gt "$best" ]; then
        best=$held
        kept="$anon $shmem $file $file_dirty $file_writeback $held"
      fi
    fi
    printf '%s %s\n' "$kept" "$samples" 2>/dev/null >"$out"
    sleep 1 &
    sleeper=$!
    wait "$sleeper" 2>/dev/null
    sleeper=""
  done
}
# memory_count <file> <key>: the key's value if it is digits, else `unreadable`.
memory_count() {
  local key value found=unreadable
  while read -r key value; do
    [ "$key" = "$2" ] && found=$value
  done 2>/dev/null <"/sys/fs/cgroup/$1"
  [[ $found =~ ^[0-9]+$ ]] || found=unreadable
  echo "$found"
}
# memory_stall <some|full>: the cgroup's total memory stall time in microseconds (PSI, memory.pressure's total=), if
# digits, else `unreadable`. Stall time, not a count: how long the step's tasks waited on memory (ballast row 2).
memory_stall() {
  local kind rest word found=unreadable words=()
  while read -r kind rest; do
    if [ "$kind" = "$1" ]; then
      read -r -a words <<<"$rest"
      for word in ${words[@]+"${words[@]}"}; do
        case $word in total=*) found=${word#total=} ;; esac
      done
    fi
  done 2>/dev/null </sys/fs/cgroup/memory.pressure
  [[ $found =~ ^[0-9]+$ ]] || found=unreadable
  echo "$found"
}
sample_start() {
  limit_before=$(memory_count memory.events max)
  some_before=$(memory_stall some)
  full_before=$(memory_stall full)
  rm -f "$TMPDIR/memory-sample"
  memory_sampler "$TMPDIR/memory-sample" &
  sampler=$!
}
sample_stop() {
  local name=$1 limit_after reached=unreadable most=unreadable field i=0 got=() some_after full_after
  local some=unreadable full=unreadable
  local values=(unreadable unreadable unreadable unreadable unreadable unreadable 0)
  if [ -n "$sampler" ]; then
    kill "$sampler" 2>/dev/null
    wait "$sampler" 2>/dev/null
  fi
  sampler=""
  limit_after=$(memory_count memory.events max)
  if [[ $limit_before =~ ^[0-9]+$ && $limit_after =~ ^[0-9]+$ ]]; then reached=$((limit_after - limit_before)); fi
  some_after=$(memory_stall some)
  full_after=$(memory_stall full)
  if [[ $some_before =~ ^[0-9]+$ && $some_after =~ ^[0-9]+$ ]]; then some=$((some_after - some_before)); fi
  if [[ $full_before =~ ^[0-9]+$ && $full_after =~ ^[0-9]+$ ]]; then full=$((full_after - full_before)); fi
  { read -r most; } 2>/dev/null </sys/fs/cgroup/memory.max
  [[ $most =~ ^[0-9]+$ ]] || most=unreadable
  { read -r -a got; } 2>/dev/null <"$TMPDIR/memory-sample" || got=()
  for field in ${got[@]+"${got[@]}"}; do
    [ "$i" -lt 7 ] || break
    if [[ $field =~ ^[0-9]+$ ]]; then values[i]=$field; elif [ "$i" -lt 6 ]; then values[i]=unreadable; else values[i]=0; fi
    i=$((i + 1))
  done
  rm -f "$TMPDIR/memory-sample"
  echo "=== Memory during $name: anon ${values[0]} shmem ${values[1]} file ${values[2]} file_dirty ${values[3]} file_writeback ${values[4]} (held ${values[5]} of max $most bytes), limit reached $reached times in the step, ${values[6]} samples, stalled some $some full $full us"
}
step() {
  local name=$1 code=0
  echo "=== $name"
  shift
  sample_start
  "$@" 2>&1 || code=$?
  sample_stop "$name"
  [ "$code" = 0 ] || { echo "=== FAILED, exit $code"; fail=1; }
}

for port in 5432 5433; do
  for _ in $(seq 60); do
    pg_isready -q -h localhost -p "$port" -U test && break
    sleep 2
  done
done
[ "$(psql "$DATABASE_URL" -tAc 'show server_version_num' | cut -c1-2)" = 16 ] || { echo "=== PostgreSQL 16 did not answer"; exit 1; }

# A tree may name its tests, one per line. Only names pass, and they reach only this container's cargo.
only=()
if [ -f /work/src/.vps-only ]; then
  # `|| [ -n ]`: a last line with no newline is still read, and so still checked (security's Q110 L3).
  while IFS= read -r name || [ -n "$name" ]; do
    [[ $name =~ ^[a-z0-9_]{1,200}$ ]] || { echo "=== .vps-only holds a line that is not a test name"; exit 1; }
    only+=("$name")
  done </work/src/.vps-only
fi

# Q110: a tree may also name, in .vps-release, which of its named tests build and run in release (a benchmark's honest
# speed). Only beside .vps-only names, only names .vps-only holds, and never empty: anything else is a lane error, before
# any build, never ignored. Every other named test stays debug, where debug_assert! and the debug-only checks run.
release=()
if [ -e /work/src/.vps-release ]; then
  [ "${#only[@]}" -gt 0 ] || { echo "=== .vps-release without names in .vps-only: refused"; exit 1; }
  # `|| [ -n ]`: a last line with no newline is still read, and so still checked (security's Q110 L3).
  while IFS= read -r name || [ -n "$name" ]; do
    [[ $name =~ ^[a-z0-9_]{1,200}$ ]] || { echo "=== .vps-release holds a line that is not a test name"; exit 1; }
    named=""
    for one in "${only[@]}"; do [ "$one" = "$name" ] && named=1; done
    [ -n "$named" ] || { echo "=== .vps-release names $name, which .vps-only does not"; exit 1; }
    release+=("$name")
  done </work/src/.vps-release
  [ "${#release[@]}" -gt 0 ] || { echo "=== .vps-release names no test: refused"; exit 1; }
fi

# Crates from the fetcher's folder, checked against the lock before they got there, as a directory source.
# TMPDIR is on the slot's volume: the deploy tests copy release binaries into it, more than the /tmp tmpfs holds.
mkdir -p /work/vendor "$CARGO_HOME" "$TMPDIR"
shopt -s nullglob
for crate in /crates/*.crate; do
  tar -xzf "$crate" --no-same-owner -C /work/vendor || exit 1
  name=$(basename "$crate" .crate)
  printf '{"files":{},"package":"%s"}' "$(sha256sum "$crate" | cut -d' ' -f1)" >"/work/vendor/$name/.cargo-checksum.json"
done
cat >"$CARGO_HOME/config.toml" <<'CONFIG'
[source.crates-io]
replace-with = "tftvps"
[source.tftvps]
directory = "/work/vendor"
[net]
offline = true
CONFIG

# Plan item 8a: a named run builds only the targets whose files hold its names' functions, not all of the workspace's.
# Sets `targets` to cargo's flags. A test file at the top of a tests/ folder is its own target (--test), a src/bin file
# a binary (--bin), any other src/ file the library and binaries. A name in no such file builds the whole workspace,
# and the run says so. This cannot turn a red green: each name must still show as run and passed.
targets_for() {
  local name file rel stem found flag seen=" "
  local wanted=()
  targets=()
  for name; do
    found=""
    while IFS= read -r file; do
      rel=${file#/work/src/}
      stem=${rel##*/}
      # A file name is the tree's: one that is not plain letters, digits, _ and - builds the whole workspace.
      [[ ${stem%.rs} =~ ^[A-Za-z0-9_-]{1,100}$ ]] || { found=""; break; }
      case $rel in
        tests/*/* | */tests/*/*) ;;
        tests/*.rs | */tests/*.rs) wanted+=("--test ${stem%.rs}"); found=1 ;;
        src/bin/*.rs | */src/bin/*.rs) wanted+=("--bin ${stem%.rs}"); found=1 ;;
        src/* | */src/*) wanted+=(--lib --bins); found=1 ;;
      esac
    done < <(grep -rlE --include='*.rs' --exclude-dir=target --exclude-dir=.git "fn $name([^A-Za-z0-9_]|$)" /work/src/ 2>/dev/null)
    if [ -z "$found" ]; then
      echo "=== $name is in no test file found by name: this run builds the whole workspace"
      return 0
    fi
  done
  # Each flag once: cargo refuses --lib or --bins given twice. A stem is a file name's, so it holds no space.
  for flag in "${wanted[@]}"; do
    case $seen in *" $flag "*) continue ;; esac
    seen="$seen$flag "
    # shellcheck disable=SC2206
    targets+=($flag)
  done
}

# named <debug|release> <output file> <name>...: security R12-L7, a name runs exactly. cargo lists the built tests,
# each name keeps the full paths whose last part is that name (two paths, two tests: both run), and only those run,
# with --exact, so a longer name that holds it does not. A name in no listed test runs nothing and is red, and with no
# path at all nothing runs, never the whole suite. Then each name must show as run and passed, as before.
named() {
  local mode=$1 out=$2 name path found word="" status
  local profile=() paths=()
  shift 2
  if [ "$mode" = release ]; then profile=(--release) word=" in release"; fi
  targets_for "$@"
  echo "=== Builds$word: ${targets[*]:-the whole workspace}"
  sample_start
  cargo test ${profile[@]+"${profile[@]}"} --locked --workspace ${targets[@]+"${targets[@]}"} -- --list 2>&1 | tee "$out.list"
  status=${PIPESTATUS[0]}
  sample_stop "the named build$word"
  if [ "$status" != 0 ]; then
    echo "=== the build or the listing failed$word"
    fail=1
    return 0
  fi
  for name; do
    found=""
    while IFS= read -r path; do
      paths+=("$path")
      found=1
    done < <(grep -E ': test$' "$out.list" | sed 's/: test$//' | awk -v want="$name" '{ last = $0; sub(/.*::/, "", last) } last == want' | sort -u)
    [ -n "$found" ] || echo "=== $name is in no test the build listed$word"
  done
  if [ "${#paths[@]}" = 0 ]; then
    echo "=== no named test was listed$word: nothing runs, and the run is red"
    fail=1
  else
    echo "=== Runs exactly$word: ${paths[*]}"
    sample_start
    cargo test ${profile[@]+"${profile[@]}"} --locked --workspace ${targets[@]+"${targets[@]}"} --no-fail-fast -- --include-ignored --exact "${paths[@]}" 2>&1 | tee "$out"
    status=${PIPESTATUS[0]}
    sample_stop "the named run$word"
    [ "$status" = 0 ] || fail=1
  fi
  touch "$out"
  echo "=== Tests that ran$word: $(grep -E '^test .* \.\.\. (ok|FAILED|ignored)$' "$out" | sed 's/^test //; s/ \.\.\. [A-Za-z]*$//' | tr '\n' ' ')"
  for name; do
    grep -Eq "^test (.*::)?$name \.\.\. ok$" "$out" || { echo "=== $name did not run and pass$word"; fail=1; }
  done
}

if [ "${#only[@]}" -gt 0 ]; then
  debug=()
  for name in "${only[@]}"; do
    chosen=""
    for one in ${release[@]+"${release[@]}"}; do [ "$one" = "$name" ] && chosen=1; done
    [ -n "$chosen" ] || debug+=("$name")
  done
  echo "=== NAMED TESTS ONLY, not the whole suite, no formatting or lints: ${only[*]}"
  if [ "${#debug[@]}" -gt 0 ]; then
    echo "=== In debug: ${debug[*]}"
    named debug /tmp/named.txt "${debug[@]}"
  fi
  if [ "${#release[@]}" -gt 0 ]; then
    # Release keeps overflow-checks on (Cargo.toml's [profile.release], the guard's floor); debug_assert! is off here.
    echo "=== In release, named in .vps-release: ${release[*]}"
    echo "=== release: debug_assert! and debug-only checks off; a release pass proves speed + its own asserts"
    named release /tmp/named-release.txt "${release[@]}"
  fi
  exit "$fail"
fi

step Formatting cargo fmt --check
step Lints cargo clippy --locked --workspace --all-targets -- -D warnings
step "List every test" cargo test --locked --workspace -- --list
step Tests cargo test --locked --workspace --no-fail-fast -- --include-ignored
exit "$fail"
