#!/bin/bash
# Fixed steps inside the run container: the same as CI's `checks`. Comes from the snapshot, never the branch.
set -u
fail=0
step() {
  echo "=== $1"
  shift
  "$@" 2>&1 || { echo "=== FAILED, exit $?"; fail=1; }
}

for port in 5432 5433; do
  for _ in $(seq 60); do
    pg_isready -q -h localhost -p "$port" -U test && break
    sleep 2
  done
done
[ "$(psql "$DATABASE_URL" -tAc 'show server_version_num' | cut -c1-2)" = 16 ] || { echo "=== PostgreSQL 16 did not answer"; exit 1; }

# A tree may name its tests, one per line. Only names pass, and they reach only this container's cargo.
only=()
if [ -f /work/src/.vps-only ]; then
  while IFS= read -r name; do
    [[ $name =~ ^[a-z0-9_]{1,200}$ ]] || { echo "=== .vps-only holds a line that is not a test name"; exit 1; }
    only+=("$name")
  done </work/src/.vps-only
fi

# Crates from the fetcher's folder, checked against the lock before they got there, as a directory source.
mkdir -p /work/vendor "$CARGO_HOME"
shopt -s nullglob
for crate in /crates/*.crate; do
  tar -xzf "$crate" --no-same-owner -C /work/vendor || exit 1
  name=$(basename "$crate" .crate)
  printf '{"files":{},"package":"%s"}' "$(sha256sum "$crate" | cut -d' ' -f1)" >"/work/vendor/$name/.cargo-checksum.json"
done
cat >"$CARGO_HOME/config.toml" <<'CONFIG'
[source.crates-io]
replace-with = "tftvps"
[source.tftvps]
directory = "/work/vendor"
[net]
offline = true
CONFIG

# A filter that matches nothing passes in cargo, so each name must show as run and passed.
if [ "${#only[@]}" -gt 0 ]; then
  echo "=== NAMED TESTS ONLY, not the whole suite, no formatting or lints: ${only[*]}"
  cargo test --locked --workspace --no-fail-fast -- --include-ignored "${only[@]}" 2>&1 | tee /tmp/named.txt
  [ "${PIPESTATUS[0]}" = 0 ] || fail=1
  for name in "${only[@]}"; do
    grep -Eq "^test (.*::)?$name \.\.\. ok$" /tmp/named.txt || { echo "=== $name did not run and pass"; fail=1; }
  done
  exit "$fail"
fi

step Formatting cargo fmt --check
step Lints cargo clippy --locked --workspace --all-targets -- -D warnings
step "List every test" cargo test --locked --workspace -- --list
step Tests cargo test --locked --workspace --no-fail-fast -- --include-ignored
exit "$fail"
