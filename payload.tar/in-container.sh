#!/bin/bash
# Fixed steps inside the run container: the same as CI's `checks`. Comes from the snapshot, never the branch.
set -u
fail=0
# A run that meets the memory limit names it by the kernel's own count for this container, not by a guess.
memory_word() {
  local key value kills=unreadable
  while read -r key value; do
    [ "$key" = oom_kill ] && kills=$value
  done 2>/dev/null </sys/fs/cgroup/memory.events
  echo "=== Memory limit: oom_kill $kills"
}
trap memory_word EXIT
step() {
  echo "=== $1"
  shift
  "$@" 2>&1 || { echo "=== FAILED, exit $?"; fail=1; }
}

for port in 5432 5433; do
  for _ in $(seq 60); do
    pg_isready -q -h localhost -p "$port" -U test && break
    sleep 2
  done
done
[ "$(psql "$DATABASE_URL" -tAc 'show server_version_num' | cut -c1-2)" = 16 ] || { echo "=== PostgreSQL 16 did not answer"; exit 1; }

# A tree may name its tests, one per line. Only names pass, and they reach only this container's cargo.
only=()
if [ -f /work/src/.vps-only ]; then
  # `|| [ -n ]`: a last line with no newline is still read, and so still checked (security's Q110 L3).
  while IFS= read -r name || [ -n "$name" ]; do
    [[ $name =~ ^[a-z0-9_]{1,200}$ ]] || { echo "=== .vps-only holds a line that is not a test name"; exit 1; }
    only+=("$name")
  done </work/src/.vps-only
fi

# Q110: a tree may also name, in .vps-release, which of its named tests build and run in release (a benchmark's honest
# speed). Only beside .vps-only names, only names .vps-only holds, and never empty: anything else is a lane error, before
# any build, never ignored. Every other named test stays debug, where debug_assert! and the debug-only checks run.
release=()
if [ -e /work/src/.vps-release ]; then
  [ "${#only[@]}" -gt 0 ] || { echo "=== .vps-release without names in .vps-only: refused"; exit 1; }
  # `|| [ -n ]`: a last line with no newline is still read, and so still checked (security's Q110 L3).
  while IFS= read -r name || [ -n "$name" ]; do
    [[ $name =~ ^[a-z0-9_]{1,200}$ ]] || { echo "=== .vps-release holds a line that is not a test name"; exit 1; }
    named=""
    for one in "${only[@]}"; do [ "$one" = "$name" ] && named=1; done
    [ -n "$named" ] || { echo "=== .vps-release names $name, which .vps-only does not"; exit 1; }
    release+=("$name")
  done </work/src/.vps-release
  [ "${#release[@]}" -gt 0 ] || { echo "=== .vps-release names no test: refused"; exit 1; }
fi

# Crates from the fetcher's folder, checked against the lock before they got there, as a directory source.
# TMPDIR is on the slot's volume: the deploy tests copy release binaries into it, more than the /tmp tmpfs holds.
mkdir -p /work/vendor "$CARGO_HOME" "$TMPDIR"
shopt -s nullglob
for crate in /crates/*.crate; do
  tar -xzf "$crate" --no-same-owner -C /work/vendor || exit 1
  name=$(basename "$crate" .crate)
  printf '{"files":{},"package":"%s"}' "$(sha256sum "$crate" | cut -d' ' -f1)" >"/work/vendor/$name/.cargo-checksum.json"
done
cat >"$CARGO_HOME/config.toml" <<'CONFIG'
[source.crates-io]
replace-with = "tftvps"
[source.tftvps]
directory = "/work/vendor"
[net]
offline = true
CONFIG

# A filter that matches nothing passes in cargo, so each name must show as run and passed.
if [ "${#only[@]}" -gt 0 ]; then
  debug=()
  for name in "${only[@]}"; do
    chosen=""
    for one in ${release[@]+"${release[@]}"}; do [ "$one" = "$name" ] && chosen=1; done
    [ -n "$chosen" ] || debug+=("$name")
  done
  echo "=== NAMED TESTS ONLY, not the whole suite, no formatting or lints: ${only[*]}"
  if [ "${#debug[@]}" -gt 0 ]; then
    echo "=== In debug: ${debug[*]}"
    cargo test --locked --workspace --no-fail-fast -- --include-ignored "${debug[@]}" 2>&1 | tee /tmp/named.txt
    [ "${PIPESTATUS[0]}" = 0 ] || fail=1
    for name in "${debug[@]}"; do
      grep -Eq "^test (.*::)?$name \.\.\. ok$" /tmp/named.txt || { echo "=== $name did not run and pass"; fail=1; }
    done
  fi
  if [ "${#release[@]}" -gt 0 ]; then
    # Release keeps overflow-checks on (Cargo.toml's [profile.release], the guard's floor); debug_assert! is off here.
    echo "=== In release, named in .vps-release: ${release[*]}"
    echo "=== release: debug_assert! and debug-only checks off; a release pass proves speed + its own asserts"
    cargo test --release --locked --workspace --no-fail-fast -- --include-ignored "${release[@]}" 2>&1 | tee /tmp/named-release.txt
    [ "${PIPESTATUS[0]}" = 0 ] || fail=1
    for name in "${release[@]}"; do
      grep -Eq "^test (.*::)?$name \.\.\. ok$" /tmp/named-release.txt || { echo "=== $name did not run and pass in release"; fail=1; }
    done
  fi
  exit "$fail"
fi

step Formatting cargo fmt --check
step Lints cargo clippy --locked --workspace --all-targets -- -D warnings
step "List every test" cargo test --locked --workspace -- --list
step Tests cargo test --locked --workspace --no-fail-fast -- --include-ignored
exit "$fail"
