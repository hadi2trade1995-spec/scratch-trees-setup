# Shown on each login before arming: the deploy key and its fingerprint, or why this server will not arm.
[ -r /run/tftvps/message.txt ] && cat /run/tftvps/message.txt
