#!/bin/bash
# Builds the sealed image on a stock Ubuntu 24.04 server, then powers off. Takes no branch input: its only
# inputs are this folder, Ubuntu's archive and the pinned downloads. No key exists here and none is made.
set -euo pipefail
export LC_ALL=C DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=l
readonly HOME_DIR=/opt/tftvps DATA=/var/lib/tftvps
say() { echo "tftvps setup: $*" | tee /dev/console; }
trap 'say "FAILED at line $LINENO: do not take a snapshot, delete this server"' ERR

# shellcheck source=/dev/null
source "$HOME_DIR/pins.txt"
arch=$(dpkg --print-architecture)
case $arch in
  amd64) rust_triple=x86_64-unknown-linux-gnu; leaks_arch=x64; rust_sha=$RUST_SHA256_amd64; leaks_sha=$GITLEAKS_SHA256_amd64 ;;
  arm64) rust_triple=aarch64-unknown-linux-gnu; leaks_arch=arm64; rust_sha=$RUST_SHA256_arm64; leaks_sha=$GITLEAKS_SHA256_arm64 ;;
  *) say "no pins for $arch"; exit 1 ;;
esac

say "packages"
apt-get update
apt-get -y -o Dpkg::Options::=--force-confold -o APT::Get::Always-Include-Phased-Updates=true full-upgrade
apt-get -y install --no-install-recommends podman uidmap crun catatonit nftables git python3 debootstrap sudo \
  openssh-client openssh-server curl xz-utils iproute2 ca-certificates systemd-timesyncd libnss-myhostname
# What other users could reach locally, and what has a history of local privilege bugs. One at a time, because
# apt drops a whole list over one unknown name, and then checked, so a package that stayed stops the build.
strip=(snapd packagekit polkitd policykit-1 unattended-upgrades needrestart ec2-instance-connect
  systemd-resolved apport motd-news-config landscape-common multipath-tools)
for package in "${strip[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    apt-get -y purge "$package"
  fi
done
apt-get -y autoremove --purge
for package in "${strip[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    say "$package is still installed"
    exit 1
  fi
done
rm -f /etc/resolv.conf
printf 'nameserver 1.1.1.1\nnameserver 9.9.9.9\n' >/etc/resolv.conf
# With systemd-resolved gone nothing answers this machine's own name, so sudo asked DNS for it, as the user who
# typed sudo, and the wall dropped it. myhostname answers whatever name a clone is given, at every boot, from the
# kernel, with no network and no file to write. DNS stays open to no more users.
sed -i 's/^hosts:.*/hosts: files myhostname dns/' /etc/nsswitch.conf
grep -qx 'hosts: files myhostname dns' /etc/nsswitch.conf
getent -s myhostname hosts "$(cat /proc/sys/kernel/hostname)" >/dev/null

say "users"
for user in poller fetcher runner; do
  id "$user" >/dev/null 2>&1 || useradd --create-home --home-dir "/home/$user" --shell /usr/sbin/nologin "$user"
  chmod 700 "/home/$user"
done
grep -q '^runner:' /etc/subuid || usermod --add-subuids 200000-265535 --add-subgids 200000-265535 runner
loginctl enable-linger runner
mkdir -p /etc/systemd/system/user@.service.d
printf '[Service]\nDelegate=cpu cpuset io memory pids\n' >/etc/systemd/system/user@.service.d/delegate.conf
# Ubuntu 24.04 limits user namespaces by profile, and the limit stays on for everything else. A profile of Ubuntu's
# own for this path is enough; a second one for the same path could conflict. Without one, ours must load.
if [ ! -e /etc/apparmor.d/podman ]; then
  install -m 644 "$HOME_DIR/apparmor-podman" /etc/apparmor.d/tftvps-podman
  apparmor_parser -r /etc/apparmor.d/tftvps-podman
fi

say "data folders"
mkdir -p "$DATA/crates"
git init -q --bare "$DATA/store"
chown -R poller:poller "$DATA/store"
chmod -R u=rwX,g=rX,o=rX "$DATA/store"
chown fetcher:fetcher "$DATA/crates"
chmod 755 "$DATA/crates"
# One fixed-size volume per possible run, sparse here and formatted now. Only a machine with room uses slot1.
for slot in 0 1; do
  truncate -s 60G "$DATA/slot$slot.img"
  mkfs.ext4 -q -F -m 0 "$DATA/slot$slot.img"
  mkdir -p "$DATA/slot$slot"
  grep -q "slot$slot.img" /etc/fstab || echo "$DATA/slot$slot.img $DATA/slot$slot ext4 loop,nosuid,nodev 0 0" >>/etc/fstab
  mount "$DATA/slot$slot"
  chown runner:runner "$DATA/slot$slot"
  umount "$DATA/slot$slot"
done

say "pinned downloads"
work=$(mktemp -d)
rust_file=rust-$RUST_VERSION-$rust_triple.tar.xz
curl -fsSL --retry 3 -o "$work/$rust_file" "https://static.rust-lang.org/dist/$rust_file"
echo "$rust_sha  $work/$rust_file" | sha256sum --strict --check --quiet
leaks_file=gitleaks_${GITLEAKS_VERSION}_linux_$leaks_arch.tar.gz
curl -fsSL --retry 3 -o "$work/$leaks_file" "https://github.com/gitleaks/gitleaks/releases/download/v$GITLEAKS_VERSION/$leaks_file"
echo "$leaks_sha  $work/$leaks_file" | sha256sum --strict --check --quiet

say "run image, from Ubuntu's archive"
root=$work/rootfs
# gnupg and sudo: tests/setup_staging.rs needs gpg and visudo, and fails without them when GITHUB_ACTIONS is set.
# No-new-privileges keeps sudo's setuid bit from doing anything in a run.
debootstrap --variant=minbase --include=bash,coreutils,util-linux,git,python3,build-essential,pkg-config,postgresql-client,ca-certificates,openssl,tar,gzip,procps,iproute2,curl,gnupg,sudo,hostname \
  noble "$root" http://archive.ubuntu.com/ubuntu
mkdir -p "$root/opt/rust" "$root/opt/gitleaks" "$root/opt/tftvps" "$root/work" "$root/crates" "$root/scan"
tar -xJf "$work/$rust_file" -C "$work"
"$work/${rust_file%.tar.xz}/install.sh" --prefix="$root/opt/rust" --destdir="" --disable-ldconfig --without=rust-docs >/dev/null
tar -xzf "$work/$leaks_file" -C "$root/opt/gitleaks" gitleaks
install -m 644 "$HOME_DIR/gitleaks.toml" "$root/opt/gitleaks/config.toml"
install -m 755 "$HOME_DIR/in-container.sh" "$root/opt/tftvps/in-container.sh"
tar -C "$root" -c . >"$work/rootfs.tar"
chown runner "$work" "$work/rootfs.tar"
chmod 755 "$work"
as_runner() { sudo -n -H -u runner env XDG_RUNTIME_DIR="/run/user/$(id -u runner)" "$@"; }
systemctl start "user@$(id -u runner).service"
as_runner podman import -q "$work/rootfs.tar" localhost/tftvps-run:sealed
as_runner podman pull -q "docker.io/$IMAGE_TIMESCALE"
as_runner podman pull -q "docker.io/$IMAGE_PLAIN"
rm -rf "$work"

say "system files"
install -m 644 "$HOME_DIR/nftables.conf" /etc/nftables.conf
install -m 644 "$HOME_DIR"/units/* /etc/systemd/system/
install -m 440 "$HOME_DIR/sudoers" /etc/sudoers.d/tftvps
visudo -cqf /etc/sudoers.d/tftvps
install -m 644 "$HOME_DIR/sshd-before-arming.conf" /etc/ssh/sshd_config.d/00-tftvps.conf
install -m 755 "$HOME_DIR/login-message.sh" /etc/profile.d/tftvps.sh
chown -R root:root "$HOME_DIR"
chmod -R go-w "$HOME_DIR"
# A program boot needs and cannot find stops the build here, not a clone later.
/usr/bin/python3 -I "$HOME_DIR/vps.py" check-programs
systemctl enable nftables.service tftvps-boot.service tftvps-idle.timer tftvps-limit.timer
systemctl disable apt-daily.timer apt-daily-upgrade.timer 2>/dev/null || true
# A boot unit in an ordering cycle is dropped with no word in its own log, and a clone then never arms. Refuse to
# seal unless cloud-init.target pulls it in and systemd's own check of a boot finds no cycle. Only that check's
# words count: its exit code also covers Ubuntu's units, which are not ours to fix here.
systemctl daemon-reload
systemctl show -p Wants --value cloud-init.target | tr ' ' '\n' | grep -qx tftvps-boot.service
systemctl show -p WantedBy --value cloud-init.target | tr ' ' '\n' | grep -qx multi-user.target
verify_log=$(mktemp)
systemd-analyze --man=no --generators=yes verify default.target tftvps-boot.service >"$verify_log" 2>&1 ||
  say "systemd-analyze verify exited non-zero; only a cycle in its words stops the build"
if grep -iE 'ordering cycle|to break ordering' "$verify_log"; then
  say "an ordering cycle at boot: the boot unit would not start"
  exit 1
fi
rm -f "$verify_log"

say "seal"
manifest=$HOME_DIR/manifest
{
  echo "sealed $(date -u +%FT%TZ) arch $arch"
  as_runner podman images --digests --format '{{.Repository}} {{.Digest}}' | sort
  echo "key files: $(find / -xdev \( -name 'id_*' -o -name '*.pem' \) -not -path '/usr/*' -not -path '/etc/ssl/*' -not -path '/home/runner/.local/*' 2>/dev/null | wc -l)"
  echo "timers: $(systemctl list-unit-files --state=enabled --type=timer --no-legend | awk '{print $1}' | tr '\n' ' ')"
  echo "listening: $(ss -lntuH | wc -l)"
  echo "packages that stayed:"
  dpkg-query -W -f='${Package} ${Version}\n'
} >"$manifest"
cat "$manifest" >/dev/console || true
date +%s >"$HOME_DIR/sealed"
sha256sum "$HOME_DIR/manifest" | cut -d' ' -f1 >>"$HOME_DIR/sealed"
tr '\n' ' ' <"$HOME_DIR/sealed" >"$HOME_DIR/sealed.line" && mv "$HOME_DIR/sealed.line" "$HOME_DIR/sealed"
passwd -l root
rm -f /root/.ssh/authorized_keys /home/ubuntu/.ssh/authorized_keys /etc/ssh/ssh_host_*
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id /root/.bash_history /home/ubuntu/.bash_history
cloud-init clean --logs --seed
apt-get clean
say "SEALED. It powers off in 2 minutes. Take the snapshot only from this build- server."
sleep 120
systemctl poweroff
