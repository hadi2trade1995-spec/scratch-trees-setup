#!/bin/bash
# Builds the sealed image on a stock Ubuntu 24.04 server, then powers off. Takes no branch input: its only
# inputs are this folder, Ubuntu's archive and the pinned downloads. No key exists here and none is made.
set -Eeuo pipefail
export LC_ALL=C DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=l
readonly HOME_DIR=/opt/tftvps DATA=/var/lib/tftvps
say() { echo "tftvps setup: $*" | tee /dev/console; }

# One log and one way to fail. The launch script already sends this script's output to the log; appending here
# names the path in this file and keeps every writer at the log's end. A step's own output lands in the same log.
readonly LOG=/var/log/tftvps-setup.log RUN_DIR=/run/tftvps
exec >>"$LOG" 2>&1
# Each long step runs under `timeout`, so a hung step fails the build instead of hanging it. No step times are
# written down for round 5, whose whole build took about 30 minutes, so these are generous fixed limits: apt and
# mmdebstrap 30 min, a download, an import or a pull 20 min, one purge 10 min, autoremove 15 min. A step that
# ignores the stop signal is killed 2 minutes later. A time limit exits 124 (137 once killed).
at="" done_step="" failed_status=0 failed_line=0 step_began=0 step_limit=0
# Gives back the step's own code, in an `if` too. Notes when it began and its limit, the word after --kill-after=,
# so a failure can tell its time limit from any other end.
step() {
  local name=$1 word after="" code
  shift
  at=$name
  step_began=$(date +%s)
  step_limit=999999
  for word in "$@"; do
    if [ -n "$after" ]; then
      if [[ $word =~ ^([0-9]+)m$ ]]; then step_limit=$((BASH_REMATCH[1] * 60)); fi
      if [[ $word =~ ^([0-9]+)s$ ]]; then step_limit=${BASH_REMATCH[1]}; fi
      break
    fi
    case $word in --kill-after=*) after=1 ;; esac
  done
  echo "start $name $(date -u +%FT%TZ)"
  "$@" || {
    code=$?
    echo "failed $name $code after $(($(date +%s) - step_began))"
    return "$code"
  }
  echo "end $name $(($(date +%s) - step_began))"
  at="" done_step=$name
}
# Any failure, a time limit included, ends here: no seal and no power-off. The server stays up for the log to be
# read, so the message says to delete it, since a server that is up costs money.
on_exit() {
  local status=$? why text
  if [ "$status" -eq 0 ]; then
    return 0
  fi
  set +e
  why="exit $status"
  if [ "$failed_line" -ne 0 ]; then
    why="exit $failed_status at line $failed_line"
  fi
  # Only a step that ran its whole limit ended by it (security L2): 137 can also be the kernel's out-of-memory kill, and
  # a line outside a step has no limit at all.
  if [ -n "$at" ] && { [ "$failed_status" -eq 124 ] || [ "$failed_status" -eq 137 ]; } &&
    [ $(($(date +%s) - step_began)) -ge "$step_limit" ]; then
    why="its time limit ran out"
  fi
  text="BUILD FAILED at ${at:-a line after ${done_step:-the start}}: read $LOG, then delete this server; do not snapshot
($why)
--- the last 40 lines of $LOG ---
$(tail -n 40 "$LOG")"
  mkdir -p "$RUN_DIR"
  printf '%s\n' "$text" >"$RUN_DIR/message.txt"
  # A build that stopped early has not yet installed the login message that prints it.
  [ -e /etc/profile.d/tftvps.sh ] || install -m 755 "$HOME_DIR/login-message.sh" /etc/profile.d/tftvps.sh
  printf '%s\n' "$text" >/dev/console
  printf '%s\n' "$text"
  exit "$status"
}
trap 'failed_status=$? failed_line=$LINENO' ERR
trap on_exit EXIT

# shellcheck source=/dev/null
source "$HOME_DIR/pins.txt"
arch=$(dpkg --print-architecture)
# shellcheck disable=SC2154 # RUST_SHA256_amd64/arm64 are set at pins.txt:7-8, GITLEAKS_SHA256_amd64/arm64 at :10-11, sourced above
case $arch in
  amd64) rust_triple=x86_64-unknown-linux-gnu; leaks_arch=x64; rust_sha=$RUST_SHA256_amd64; leaks_sha=$GITLEAKS_SHA256_amd64 ;;
  arm64) rust_triple=aarch64-unknown-linux-gnu; leaks_arch=arm64; rust_sha=$RUST_SHA256_arm64; leaks_sha=$GITLEAKS_SHA256_arm64 ;;
  *) say "no pins for $arch"; exit 1 ;;
esac

# The run image and the mirror list are amd64 only: archive.ubuntu.com and the EC2 mirrors carry no arm64, which is
# on ports.ubuntu.com. Refused by name before any mirror work (lead, 11-12); the arm64 pins stay for a later port.
at=arch
if [ "$arch" != amd64 ]; then
  say "arm64 needs ports.ubuntu.com; amd64 only"
  exit 1
fi
at=""

say "apt floor"
# --- the apt floor: the vps tests run this block on its own
# USN-8996-1 (CVE-2026-109518, 2026-11-04): apt below 2.8.4ubuntu0.1 can be made to install an unverified package when
# it follows a redirect and retries a download, as our mirrors' drops make it do. So the stock apt fetches nothing:
# the fixed .debs come over https from pins.txt, each is checked by sha256 before dpkg installs it, and the floor is
# checked after. No apt call and no other fetch of this script comes before this block, and any failure here stops
# the build here: it never falls back to an apt fetch. The stock image's own apt timers are stopped first, and a
# server whose apt already ran this boot is refused. apt-utils needs apt at its exact version, so it comes too when
# installed; every library the three need is older than noble's own release versions.
at="apt-floor"
for unit in apt-daily.timer apt-daily-upgrade.timer apt-daily.service apt-daily-upgrade.service; do
  if systemctl cat "$unit" >/dev/null 2>&1; then systemctl stop "$unit"; fi
done
for unit in apt-daily.service apt-daily-upgrade.service; do
  started=$(systemctl show -p ExecMainStartTimestampMonotonic --value "$unit")
  if [ -n "$started" ] && [ "$started" != 0 ]; then
    say "$unit ran this boot with the stock apt, before the floor: delete this server"
    exit 1
  fi
done
floor_ok() {
  local package version
  for package in apt libapt-pkg6.0t64; do
    version=$(dpkg-query -W -f='${Version}' "$package" 2>/dev/null) || return 1
    dpkg --compare-versions "$version" ge "$APT_MIN_VERSION" || return 1
  done
}
if floor_ok; then
  say "apt floor: apt $(dpkg-query -W -f='${Version}' apt) is at or above $APT_MIN_VERSION, nothing to install"
else
  floor_dir=$(mktemp -d)
  floor_debs=()
  for pin in APT LIBAPT APT_UTILS; do
    if [ "$pin" = APT_UTILS ] && ! dpkg -s apt-utils >/dev/null 2>&1; then continue; fi
    url_name=${pin}_DEB_URL sha_name=${pin}_DEB_SHA256
    floor_file=$floor_dir/${!url_name##*/}
    step apt-floor-download timeout --kill-after=2m 10m curl -fsS --proto =https --tlsv1.2 --retry 3 -o "$floor_file" "${!url_name}"
    at="apt-floor"
    echo "${!sha_name}  $floor_file" | sha256sum --strict --check --quiet
    floor_debs+=("$floor_file")
  done
  step apt-floor-install timeout --kill-after=2m 10m dpkg -i "${floor_debs[@]}"
  rm -rf "$floor_dir"
  at="apt-floor"
  if ! floor_ok; then
    say "apt is still below $APT_MIN_VERSION after the pinned install"
    exit 1
  fi
  say "apt floor: apt $(dpkg-query -W -f='${Version}' apt), from the pinned .debs"
fi
at=""
# --- end of the apt floor

say "mirrors"
# --- the mirror: the vps tests run this block on its own
# 11-12, proven by the owner in Frankfurt as in Ireland: an EC2 Ubuntu mirror drops about one connection per ~80 MB.
# With apt's retries off one file in ~76 failed every run; with retries the same run was clean. So apt retries each
# file, set here rather than left to apt's default, for the host's apt and for mmdebstrap alike (one file, both
# paths). 5 tries: a build fetches ~300 MB, so ~3-4 drops each on its own file, and one retry fixed every drop seen;
# apt's own back-off waits at most ~31 s per file. The timeouts count seconds with no data, not a whole download, so
# a slow mirror that still sends is never cut, and one that stalls costs at most ~3.5 min per file.
readonly ACQUIRE=/etc/apt/apt.conf.d/80tftvps-acquire
readonly ACQUIRE_LINES='Acquire::Retries "5";
Acquire::http::Timeout "30";
Acquire::https::Timeout "30";'
# The second layer, outage failover only: apt's mirror method takes a file that still fails from the next mirror,
# lowest priority first (with no priority apt picks the order at random). Every entry is checked the same way:
# the Release file's signature against Ubuntu's keyring, and each package against that file's hashes.
readonly ARCHIVE=http://archive.ubuntu.com/ubuntu/ MIRRORS=/etc/apt/tftvps-mirrors.list
readonly SECOND=http://eu-central-1.ec2.archive.ubuntu.com/ubuntu/ SECOND_ELSE=http://eu-west-1.ec2.archive.ubuntu.com/ubuntu/
# Named, not left to apt's default (security L1): the build stops on a missing or empty keyring before any fetch.
readonly KEYRING=/usr/share/keyrings/ubuntu-archive-keyring.gpg
# The host's sources as the image shipped them, kept once (lead L1): a second run on the same host reads its mirror
# from these, not from the files the first run rewrote.
readonly ORIG=/etc/apt/tftvps-orig
# The mirror the host's own apt uses for noble main: the first URIs of a deb822 stanza whose Suites hold noble and
# whose Components hold main, else the first `deb <uri> noble ... main` line. Only http(s)://<host>/ubuntu[/] counts,
# the host letters, digits, dots and hyphens; anything else is no mirror. It comes from this host's own config, so it
# holds on any provider. Prints the URI, or nothing.
host_mirror() {
  local found=""
  if [ -r "$1" ]; then
    found=$(awk '
      function flush() {
        if (!done && uri != "" && enabled != "no" && types ~ /(^| )deb( |$)/ && suites ~ /(^| )noble( |$)/ && parts ~ /(^| )main( |$)/) { print uri; done = 1 }
        types = ""; suites = ""; parts = ""; uri = ""; enabled = ""
      }
      /^[ \t]*$/ { flush(); next }
      /^#/ { next }
      tolower($1) == "types:" { $1 = ""; types = $0 }
      tolower($1) == "uris:" { uri = $2 }
      tolower($1) == "suites:" { $1 = ""; suites = $0 }
      tolower($1) == "components:" { $1 = ""; parts = $0 }
      tolower($1) == "enabled:" { enabled = tolower($2) }
      END { flush() }
    ' "$1")
  fi
  if [ -z "$found" ] && [ -r "$2" ]; then
    found=$(awk '
      $1 == "deb" {
        at = 2
        if ($at ~ /^\[/) { while (at <= NF && $at !~ /\]$/) at++; at++ }
        if ($(at + 1) == "noble") { for (part = at + 2; part <= NF; part++) if ($part == "main") { print $at; exit } }
      }
    ' "$2")
  fi
  if [[ $found =~ ^https?://[A-Za-z0-9.-]+/ubuntu/?$ ]]; then printf '%s\n' "$found"; fi
}
# The list, one mirror a line, a tab, then its priority: the host's own mirror if it has one, Ubuntu's archive, then
# a second region (eu-west-1 when the host's own is eu-central-1). Each URI once, with one trailing slash.
mirror_list() {
  local second=$SECOND seen=" " uri n=1
  if [ "${1%/}/" = "$SECOND" ]; then second=$SECOND_ELSE; fi
  for uri in ${1:+"${1%/}/"} "$ARCHIVE" "$second"; do
    case $seen in *" $uri "*) continue ;; esac
    seen="$seen$uri "
    printf '%s\tpriority:%d\n' "$uri" "$n"
    n=$((n + 1))
  done
}
# The host's own sources: the list for noble and its updates, security's own host as before, both signature-checked.
host_sources() {
  printf 'Types: deb\nURIs: mirror+file:%s\nSuites: noble noble-updates noble-backports\nComponents: main restricted universe multiverse\nSigned-By: %s\n\n' "$MIRRORS" "$KEYRING"
  printf 'Types: deb\nURIs: http://security.ubuntu.com/ubuntu/\nSuites: noble-security\nComponents: main restricted universe multiverse\nSigned-By: %s\n' "$KEYRING"
}
# The run image's sources: whole deb lines, never a bare URI, from which mmdebstrap would add pockets of its own. main
# only, as before, now with its updates and security fixes (security R12-M1, owner O5): noble and noble-updates through
# the mirror list, noble-security from security's own host, as the host's sources have it. All three signature-checked.
readonly -a IMAGE_SOURCES=(
  "deb [signed-by=$KEYRING] mirror+file:$MIRRORS noble main"
  "deb [signed-by=$KEYRING] mirror+file:$MIRRORS noble-updates main"
  "deb [signed-by=$KEYRING] http://security.ubuntu.com/ubuntu/ noble-security main"
)
# --- end of the mirror
# --- the mirror files: the vps tests run this block on its own
at=keyring
if [ ! -s "$KEYRING" ]; then
  say "no Ubuntu archive keyring at $KEYRING: apt could not check the Release signature"
  exit 1
fi
at="mirror-list"
# Any other active source in sources.list.d would fetch around the list, on the host and on every lane (security
# bm2-L1): refused by name, never rewritten, before any file here changes. apt reads only *.list and *.sources there.
# Active: a .list with a deb or deb-src line (indented too), or a .sources stanza that is not `Enabled: no`.
active_source() {
  case $1 in
    *.list) awk '$1 == "deb" || $1 == "deb-src" { found = 1 } END { exit !found }' "$1" ;;
    *.sources) awk '
      function flush() { if (fields && enabled != "no") found = 1; fields = 0; enabled = "" }
      /^[ \t]*$/ { flush(); next }
      /^[ \t]*#/ { next }
      { fields++ }
      tolower($1) == "enabled:" { enabled = tolower($2) }
      END { flush(); exit !found }
    ' "$1" ;;
    *) return 1 ;;
  esac
}
for other in /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources; do
  [ -e "$other" ] || continue
  [ "${other##*/}" != ubuntu.sources ] || continue
  if active_source "$other"; then
    say "$other is an active apt source outside the mirror list: remove it or turn it off, then build again"
    exit 1
  fi
done
if [ ! -d "$ORIG" ]; then
  mkdir -p "$ORIG.new"
  if [ -e /etc/apt/sources.list.d/ubuntu.sources ]; then cp -p /etc/apt/sources.list.d/ubuntu.sources "$ORIG.new/ubuntu.sources"; fi
  if [ -e /etc/apt/sources.list ]; then cp -p /etc/apt/sources.list "$ORIG.new/sources.list"; fi
  mv "$ORIG.new" "$ORIG"
fi
mirror=$(host_mirror "$ORIG/ubuntu.sources" "$ORIG/sources.list")
mirror_list "$mirror" >"$MIRRORS"
printf '%s\n' "$ACQUIRE_LINES" >"$ACQUIRE"
host_sources >/etc/apt/sources.list.d/ubuntu.sources
# Active lines of the legacy list would fetch past the mirror list (lead L2), so they are turned into comments, and
# the log says how many. Noble's own file holds none.
if [ -e /etc/apt/sources.list ]; then
  legacy=$(awk '$1 == "deb" || $1 == "deb-src" { n++ } END { print n + 0 }' /etc/apt/sources.list)
  if [ "$legacy" != 0 ]; then
    awk '{ if ($1 == "deb" || $1 == "deb-src") print "# tftvps, off: the mirror list is in ubuntu.sources: " $0; else print }' \
      /etc/apt/sources.list >/etc/apt/sources.list.tftvps-new
    cat /etc/apt/sources.list.tftvps-new >/etc/apt/sources.list
    rm -f /etc/apt/sources.list.tftvps-new
    say "sources.list: $legacy active line(s) turned off; the mirror list is in ubuntu.sources"
  fi
fi
chmod 644 "$MIRRORS" "$ACQUIRE" /etc/apt/sources.list.d/ubuntu.sources
# A lane boots from the snapshot with cloud-init cleaned (the seal's `cloud-init clean --seed`), and boot.py's patch
# step then runs apt-get update and full-upgrade. cloud-init's apt module would write ubuntu.sources back to the bare
# regional mirror on that first boot; this keeps the list there too. The retries file survives either way.
mkdir -p /etc/cloud/cloud.cfg.d
readonly CLOUD_APT=/etc/cloud/cloud.cfg.d/90-tftvps-apt.cfg
printf '# tftvps: keep the mirror list of vps/setup.sh; boot.py runs apt on every lane.\napt:\n  preserve_sources_list: true\n' >"$CLOUD_APT"
chmod 644 "$CLOUD_APT"
at=""
say "mirrors: $(cut -f1 "$MIRRORS" | tr '\n' ' ')"
# --- end of the mirror files

say "packages"
step apt-update timeout --kill-after=2m 30m apt-get update
step apt-full-upgrade timeout --kill-after=2m 30m \
  apt-get -y -o Dpkg::Options::=--force-confold -o APT::Get::Always-Include-Phased-Updates=true full-upgrade
step apt-install timeout --kill-after=2m 30m apt-get -y install --no-install-recommends podman uidmap crun catatonit nftables git python3 mmdebstrap sudo \
  openssh-client openssh-server curl xz-utils iproute2 ca-certificates systemd-timesyncd libnss-myhostname
# What other users could reach locally, and what has a history of local privilege bugs. One at a time, because
# apt drops a whole list over one unknown name, and then checked, so a package that stayed stops the build.
strip=(snapd packagekit polkitd policykit-1 unattended-upgrades needrestart ec2-instance-connect
  systemd-resolved apport motd-news-config landscape-common multipath-tools)
for package in "${strip[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    step "purge-$package" timeout --kill-after=2m 10m apt-get -y purge "$package"
  fi
done
step apt-autoremove timeout --kill-after=2m 15m apt-get -y autoremove --purge
for package in "${strip[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    say "$package is still installed"
    exit 1
  fi
done
# --- the host tools: the vps tests run this block on its own
# CIS L2's client and debug tools on the host (security R12-L3), after the autoremove above and with none of its own
# (lead, 11-13): a tool goes only when apt's own simulation shows that its purge takes nothing else. Otherwise it stays,
# and the manifest waives it in writing: the tool, why, and what its purge would take. The simulation's Remv and Purg
# lines go to the log. fwupd must go (lead, 11-13: a tool we never use goes, not waived): if its purge would take
# anything else the build stops and says what, and the seal checks it is gone. ubuntu-pro-client is always waived
# (lead, 11-13): its units are masked below, and its purge would take ubuntu-minimal. The run image's compilers are not
# host tools.
readonly -a HOST_TOOLS=(telnet inetutils-telnet ftp tnftp rsync tcpdump strace bpftrace bpfcc-tools trace-cmd open-vm-tools
  lxd-installer udisks2 open-iscsi pollinate sosreport byobu screen tmux)
readonly -a HOST_GONE=(fwupd)
# The one package a tool's purge may take with it (security PRB-L3): ubuntu-standard, a metapackage that installs
# nothing of its own, and which depends on tnftp, rsync and strace. Nothing of ours uses those three (vps/, scripts/ and
# the workflows, grepped 11-13). With no autoremove, its other dependencies stay.
readonly -a HOST_MAY_TAKE=(ubuntu-standard)
readonly -a HOST_WAIVED=(ubuntu-pro-client)
at="host-tools"
# What purging $1 would take besides $1 itself, one space before each name; the simulation's lines go to the log.
purge_takes() {
  local simulated
  simulated=$(apt-get -s purge "$1")
  printf '%s\n' "$simulated" | awk -v p="$1" '$1 == "Remv" || $1 == "Purg" { print "simulated purge of " p ": " $0 }'
  printf '%s\n' "$simulated" | awk -v p="$1" '($1 == "Remv" || $1 == "Purg") && $2 != p { printf " %s", $2 }' >"$takes_file"
}
# What it would take beyond HOST_MAY_TAKE, one space before each name.
beyond_allowed() {
  local name allowed out=""
  for name in $1; do
    for allowed in "${HOST_MAY_TAKE[@]}"; do [ "$name" != "$allowed" ] || continue 2; done
    out="$out $name"
  done
  printf '%s' "$out"
}
takes_file=$(mktemp)
host_purged=() host_kept=()
for package in "${HOST_TOOLS[@]}"; do
  dpkg -s "$package" >/dev/null 2>&1 || continue
  purge_takes "$package"
  takes=$(cat "$takes_file")
  beyond=$(beyond_allowed "$takes")
  if [ -n "$beyond" ]; then
    host_kept+=("$package: kept, its purge would also remove$takes")
    continue
  fi
  step "purge-$package" timeout --kill-after=2m 10m apt-get -y purge "$package"
  at="host-tools"
  if dpkg -s "$package" >/dev/null 2>&1; then
    say "$package is still installed after its purge"
    exit 1
  fi
  host_purged+=("$package${takes:+ (with$takes)}")
done
for package in "${HOST_GONE[@]}"; do
  dpkg -s "$package" >/dev/null 2>&1 || continue
  purge_takes "$package"
  takes=$(cat "$takes_file")
  if [ -n "$takes" ]; then
    say "$package must go, but its purge would also remove$takes: tell the lead"
    exit 1
  fi
  step "purge-$package" timeout --kill-after=2m 10m apt-get -y purge "$package"
  at="host-tools"
  if dpkg -s "$package" >/dev/null 2>&1; then
    say "$package is still installed after its purge"
    exit 1
  fi
  host_purged+=("$package")
done
for package in "${HOST_WAIVED[@]}"; do
  dpkg -s "$package" >/dev/null 2>&1 || continue
  purge_takes "$package"
  takes=$(cat "$takes_file")
  host_kept+=("$package: kept, masked by the lead's ruling (11-13); its purge would also remove${takes:- nothing else}")
done
rm -f "$takes_file"
at=""
say "host tools purged: ${host_purged[*]:-none}"
# --- end of the host tools
rm -f /etc/resolv.conf
printf 'nameserver 1.1.1.1\nnameserver 9.9.9.9\n' >/etc/resolv.conf
# With systemd-resolved gone nothing answers this machine's own name, so sudo asked DNS for it, as the user who
# typed sudo, and the wall dropped it. myhostname answers whatever name a clone is given, at every boot, from the
# kernel, with no network and no file to write. DNS stays open to no more users.
sed -i 's/^hosts:.*/hosts: files myhostname dns/' /etc/nsswitch.conf
grep -qx 'hosts: files myhostname dns' /etc/nsswitch.conf
getent -s myhostname hosts "$(cat /proc/sys/kernel/hostname)" >/dev/null

say "users"
for user in poller fetcher runner; do
  id "$user" >/dev/null 2>&1 || useradd --create-home --home-dir "/home/$user" --shell /usr/sbin/nologin "$user"
  chmod 700 "/home/$user"
done
grep -q '^runner:' /etc/subuid || usermod --add-subuids 200000-265535 --add-subgids 200000-265535 runner
loginctl enable-linger runner
mkdir -p /etc/systemd/system/user@.service.d
printf '[Service]\nDelegate=cpu cpuset io memory pids\n' >/etc/systemd/system/user@.service.d/delegate.conf
# Ubuntu 24.04 limits user namespaces by profile, and the limit stays on for everything else. A profile of Ubuntu's
# own for this path is enough; a second one for the same path could conflict. Without one, ours must load.
if [ ! -e /etc/apparmor.d/podman ]; then
  install -m 644 "$HOME_DIR/apparmor-podman" /etc/apparmor.d/tftvps-podman
  apparmor_parser -r /etc/apparmor.d/tftvps-podman
fi

say "data folders"
mkdir -p "$DATA/crates"
git init -q --bare "$DATA/store"
chown -R poller:poller "$DATA/store"
chmod -R u=rwX,g=rX,o=rX "$DATA/store"
chown fetcher:fetcher "$DATA/crates"
chmod 755 "$DATA/crates"
# One fixed-size volume for the one run at a time, sparse here and formatted now. A second slot is NOT BUILT.
slot=0
truncate -s 60G "$DATA/slot$slot.img"
mkfs.ext4 -q -F -m 0 "$DATA/slot$slot.img"
mkdir -p "$DATA/slot$slot"
grep -q "slot$slot.img" /etc/fstab || echo "$DATA/slot$slot.img $DATA/slot$slot ext4 loop,nosuid,nodev 0 0" >>/etc/fstab
mount "$DATA/slot$slot"
chown runner:runner "$DATA/slot$slot"
umount "$DATA/slot$slot"

say "pinned downloads"
work=$(mktemp -d)
rust_file=rust-$RUST_VERSION-$rust_triple.tar.xz
step download-rust timeout --kill-after=2m 20m \
  curl -fsSL --retry 3 -o "$work/$rust_file" "https://static.rust-lang.org/dist/$rust_file"
echo "$rust_sha  $work/$rust_file" | sha256sum --strict --check --quiet
leaks_file=gitleaks_${GITLEAKS_VERSION}_linux_$leaks_arch.tar.gz
step download-gitleaks timeout --kill-after=2m 20m \
  curl -fsSL --retry 3 -o "$work/$leaks_file" "https://github.com/gitleaks/gitleaks/releases/download/v$GITLEAKS_VERSION/$leaks_file"
echo "$leaks_sha  $work/$leaks_file" | sha256sum --strict --check --quiet

say "run image, from Ubuntu's archive"
root=$work/rootfs
# gnupg and sudo: tests/setup_staging.rs needs gpg and visudo, and fails without them when GITHUB_ACTIONS is set.
# No-new-privileges keeps sudo's setuid bit from doing anything in a run. jq: tests/deploy.rs's fake gh runs the
# script's own --jq filter through it, as hosted CI's runner image has it.
# From the mirror list above, through apt, so each file gets apt's retries and then the next mirror. Any mirror is
# safe: apt checks the Release file's signature against Ubuntu's keyring and each package against that file's hashes,
# and nothing here turns that check off. The same variant and packages debootstrap took, no Recommends (as
# debootstrap), root mode named. --verbose keeps apt's own lines (Ign, Get, Err) in this step's log. The setup hook
# puts the list at the same path in the rootfs, so the source resolves whichever root apt reads it from.
# --- the run image: the vps tests run this block on its own
step mmdebstrap timeout --kill-after=2m 30m mmdebstrap --mode=root --variant=minbase --verbose --keyring="$KEYRING" \
  --aptopt="$ACQUIRE" --aptopt='APT::Install-Recommends "false";' --setup-hook="install -D -m 644 $MIRRORS \"\$1$MIRRORS\"" \
  --include=bash,coreutils,util-linux,git,python3,build-essential,pkg-config,postgresql-client,ca-certificates,openssl,tar,gzip,procps,iproute2,curl,gnupg,sudo,hostname,jq \
  noble "$root" "${IMAGE_SOURCES[@]}"
say "mmdebstrap done, from $(cut -f1 "$MIRRORS" | tr '\n' ' ')"
# --- end of the run image
# The run's plain user, uid and gid as profile.json's "user": tests refuse root, as hosted CI's runner is not root.
# Its home is the slot's volume, which runctl hands to it for the run.
chroot "$root" useradd --uid 1000 --user-group --no-create-home --home-dir /work --shell /bin/bash tester
mkdir -p "$root/opt/rust" "$root/opt/gitleaks" "$root/opt/tftvps" "$root/work" "$root/crates" "$root/scan"
tar -xJf "$work/$rust_file" -C "$work"
"$work/${rust_file%.tar.xz}/install.sh" --prefix="$root/opt/rust" --destdir="" --disable-ldconfig --without=rust-docs >/dev/null
tar -xzf "$work/$leaks_file" -C "$root/opt/gitleaks" gitleaks
install -m 644 "$HOME_DIR/gitleaks.toml" "$root/opt/gitleaks/config.toml"
install -m 644 "$HOME_DIR/gitleaks-result.toml" "$root/opt/gitleaks/result.toml"
install -m 755 "$HOME_DIR/in-container.sh" "$root/opt/tftvps/in-container.sh"
# --- the image's setuid files: the vps tests run this block on its own
# No-new-privileges already makes a setuid bit do nothing in a run; the bits go too, as defence in depth (security
# R12-L6). sudo stays for visudo, which needs no bit. The lists before and after go into the manifest; after is empty.
setuid_files() { find "$1" -xdev -type f \( -perm -4000 -o -perm -2000 \) -print | sed "s|^$1||" | sort; }
at="image-setuid"
image_setuid_before=$(setuid_files "$root")
find "$root" -xdev -type f \( -perm -4000 -o -perm -2000 \) -exec chmod ug-s {} +
image_setuid_after=$(setuid_files "$root")
if [ -n "$image_setuid_after" ]; then
  say "setuid or setgid bits are left in the run image: $(tr '\n' ' ' <<<"$image_setuid_after")"
  exit 1
fi
at=""
# --- end of the image's setuid files
# shellcheck disable=SC2016 # dpkg-query's own format fields, not shell expansions
image_packages=$(chroot "$root" dpkg-query -W -f='${Package} ${Version}\n')
# --- the image floor: the vps tests run this block on its own
# The image's fixed versions (security R12-M1): sudo and git at or above the notices' fixes, libc6 and OpenSSL at or
# above the host's own, and the apt floor for any apt in the image (none today: the host's floored apt fetched it all).
readonly -a IMAGE_FLOORS=("sudo 1.9.15p5-3ubuntu5.24.04.1 USN-7604-1" "git 1:2.43.0-1ubuntu7.3 USN-7626-1")
readonly -a IMAGE_WITH_HOST=(libc6 openssl libssl3t64)
at="image-floor"
image_version() { printf '%s\n' "$image_packages" | awk -v p="$1" '$1 == p { print $2 }'; }
image_floor=()
for floor in "${IMAGE_FLOORS[@]}"; do
  read -r package minimum notice <<<"$floor"
  version=$(image_version "$package")
  if [ -z "$version" ] || ! dpkg --compare-versions "$version" ge "$minimum"; then
    say "the run image's $package ${version:-(missing)} is below $minimum ($notice)"
    exit 1
  fi
  image_floor+=("$package $version >= $minimum ($notice)")
done
for package in "${IMAGE_WITH_HOST[@]}"; do
  version=$(image_version "$package")
  host=$(dpkg-query -W -f='${Version}' "$package")
  if [ -z "$version" ] || ! dpkg --compare-versions "$version" ge "$host"; then
    say "the run image's $package ${version:-(missing)} is below the host's $host"
    exit 1
  fi
  image_floor+=("$package $version, host $host")
done
version=$(image_version apt)
if [ -n "$version" ] && ! dpkg --compare-versions "$version" ge "$APT_MIN_VERSION"; then
  say "the run image's apt $version is below the floor $APT_MIN_VERSION (USN-8996-1)"
  exit 1
fi
image_floor+=("apt ${version:-none in the image}")
at=""
# --- end of the image floor
tar -C "$root" -c . >"$work/rootfs.tar"
chown runner "$work" "$work/rootfs.tar"
chmod 755 "$work"
as_runner() { sudo -n -H -u runner env XDG_RUNTIME_DIR="/run/user/$(id -u runner)" "$@"; }
systemctl start "user@$(id -u runner).service"
# The time limit runs as runner, inside sudo, so it stops runner's own podman; its exit code passes back through.
step podman-import as_runner timeout --kill-after=2m 20m podman import -q "$work/rootfs.tar" localhost/tftvps-run:sealed
step pull-timescale as_runner timeout --kill-after=2m 20m podman pull -q "docker.io/$IMAGE_TIMESCALE"
step pull-plain as_runner timeout --kill-after=2m 20m podman pull -q "docker.io/$IMAGE_PLAIN"
rm -rf "$work"
# mmdebstrap built the image and has no use left: it goes, so no lane holds it (security bm2-L3). No autoremove (lead,
# 11-13): its own dependencies stay, and the manifest's package list shows them.
step purge-mmdebstrap timeout --kill-after=2m 10m apt-get -y purge mmdebstrap
at="purge-mmdebstrap"
if dpkg -s mmdebstrap >/dev/null 2>&1; then
  say "mmdebstrap is still installed after its purge"
  exit 1
fi
at=""

say "system files"
install -m 644 "$HOME_DIR/nftables.conf" /etc/nftables.conf
install -m 644 "$HOME_DIR"/units/* /etc/systemd/system/
install -m 440 "$HOME_DIR/sudoers" /etc/sudoers.d/tftvps
visudo -cqf /etc/sudoers.d/tftvps
install -m 644 "$HOME_DIR/sshd-before-arming.conf" /etc/ssh/sshd_config.d/00-tftvps.conf
install -m 755 "$HOME_DIR/login-message.sh" /etc/profile.d/tftvps.sh
chown -R root:root "$HOME_DIR"
chmod -R go-w "$HOME_DIR"
# A program boot needs and cannot find stops the build here, not a clone later.
/usr/bin/python3 -I "$HOME_DIR/vps.py" check-programs
# Every container's seccomp profile, from podman's own default as this package ships it, with namespaces taken out.
# A default of a shape the code does not know stops the build. Its hash and source go into the manifest below.
/usr/bin/python3 -I "$HOME_DIR/vps.py" seccomp
seccomp_from=$(dpkg-query -S /usr/share/containers/seccomp.json | cut -d: -f1)
systemctl enable nftables.service tftvps-boot.service tftvps-idle.timer tftvps-limit.timer
systemctl disable apt-daily.timer apt-daily-upgrade.timer 2>/dev/null || true
# --- the quiet host: the vps tests run this block on its own
# Units that fetch or write on their own (11-12 and round 12 host rows: fwupd's client certificate, /run/ubuntu-advantage,
# motd-news, update-notifier): masked. fwupd itself is purged above, so its units are absent, and a mask of an absent
# unit still holds if the package ever comes back: fwupd.service, the D-Bus activated daemon, too (security PRB-L10,
# 11-15), since D-Bus asks systemd to start it. The others stay installed: Ubuntu's metapackages pull them in. A mask
# outlasts an upgrade; a disabled unit can come back with one. boot.py's QUIET_UNITS is the same list (a test holds it).
readonly -a QUIET_UNITS=(fwupd-refresh.timer fwupd-refresh.service fwupd.service ua-timer.timer ua-timer.service apt-news.service
  esm-cache.service ubuntu-advantage.service motd-news.timer motd-news.service update-notifier-download.timer
  update-notifier-download.service update-notifier-motd.timer update-notifier-motd.service)
systemctl mask "${QUIET_UNITS[@]}"
if command -v pro >/dev/null 2>&1; then
  pro config set apt_news=false || say "pro config set apt_news=false failed; apt-news.service is masked and the hook diverted"
fi
# The Pro client's apt hook runs on every apt-get update, boot.py's own included, masked units or not (security
# sec-L3, option ii): diverted, so an upgrade of the package writes its copy beside it, where apt never reads it.
readonly ESM_HOOK=/etc/apt/apt.conf.d/20apt-esm-hook.conf
dpkg-divert --local --rename --divert "$ESM_HOOK.tftvps-off" --add "$ESM_HOOK"
# Time from Amazon Time Sync alone (security R12-L4): a link-local address, so no DNS, and nftables lets only
# systemd-timesync reach it, on udp/123, before the private-address drop. timesyncd, not chrony: it is already here
# and named in the wall, it listens on nothing (chrony opens a command port), and one SNTP source is all a lane needs.
readonly TIME_CONF=/etc/systemd/timesyncd.conf.d/90-tftvps.conf
mkdir -p "${TIME_CONF%/*}"
printf '# tftvps: Amazon Time Sync only; nftables lets nothing else through.\n[Time]\nNTP=169.254.169.123\nFallbackNTP=\n' >"$TIME_CONF"
chmod 644 "$TIME_CONF"
# A server DHCP hands out would come before NTP= in timesyncd's order, and the wall drops it (security PRB-L2). So
# networkd never takes one: a drop-in for every .network file in use, netplan's own in /run included, as drop-ins in
# /etc apply to a file of that name in any network folder. A lane from this snapshot regenerates the same names on
# its first boot (the same instance type, so the same interface); the host rows' timedatectl row shows LinkNTPServers.
at="quiet-host"
network_files=()
for file in /run/systemd/network/*.network /etc/systemd/network/*.network; do
  if [ -e "$file" ]; then network_files+=("${file##*/}"); fi
done
if [ "${#network_files[@]}" = 0 ]; then
  say "no systemd-networkd .network file is in use: the DHCP NTP drop-in has nowhere to go"
  exit 1
fi
for name in "${network_files[@]}"; do
  mkdir -p "/etc/systemd/network/$name.d"
  printf '# tftvps: no time server from DHCP; timesyncd uses Amazon Time Sync alone.\n[DHCPv4]\nUseNTP=no\n\n[DHCPv6]\nUseNTP=no\n' \
    >"/etc/systemd/network/$name.d/90-tftvps-ntp.conf"
  chmod 644 "/etc/systemd/network/$name.d/90-tftvps-ntp.conf"
done
at=""
# --- end of the quiet host
# A boot unit in an ordering cycle is dropped with no word in its own log, and a clone then never arms. Refuse to
# seal unless cloud-init.target pulls it in and systemd's own check of a boot finds no cycle. Only that check's
# words count: its exit code also covers Ubuntu's units, which are not ours to fix here.
systemctl daemon-reload
systemctl show -p Wants --value cloud-init.target | tr ' ' '\n' | grep -qx tftvps-boot.service
systemctl show -p WantedBy --value cloud-init.target | tr ' ' '\n' | grep -qx multi-user.target
verify_log=$(mktemp)
systemd-analyze --man=no --generators=yes verify default.target tftvps-boot.service >"$verify_log" 2>&1 ||
  say "systemd-analyze verify exited non-zero; only a cycle in its words stops the build"
if grep -iE 'ordering cycle|to break ordering' "$verify_log"; then
  say "an ordering cycle at boot: the boot unit would not start"
  exit 1
fi
rm -f "$verify_log"

say "seal checks"
# --- the seal checks: the vps tests run this block on its own
# Computed once: the manifest's lines and these refusals read the same values. The build makes no key, and a lane's
# deploy key is made only at its boot, on /run, so at the seal every count below is 0 or the build stops here.
# A key file by name: id_* or *.pem outside /usr, /etc/ssl and runner's .local, the find boot.py's host rows run too.
# One that a package ships unchanged (fwupd's LVFS CA certificates) is a package file, checked by dpkg's own hashes;
# any other, or a package's file that dpkg finds changed, is loose and refuses the seal (security sec-L2, lead 11-13).
key_files() {
  local file owner changed code
  while IFS= read -r file; do
    owner=$(dpkg-query -S "$file" 2>/dev/null | awk -F': ' '!/^diversion/ { print $1; exit }') || owner=""
    owner=${owner%%,*}
    owner=${owner%%:*}
    changed=""
    # dpkg --verify exits non-zero when it finds a changed file: that is its answer, read below, not a failure.
    code=0
    if [ -n "$owner" ]; then changed=$(dpkg --verify "$owner" 2>/dev/null) || code=$?; fi
    if [ "$code" -gt 1 ]; then
      say "dpkg --verify $owner failed ($code): the key-file check cannot be made"
      exit 1
    fi
    if [ -n "$owner" ] && ! awk -v f="$file" '$NF == f { found = 1 } END { exit !found }' <<<"$changed"; then
      echo "package $file"
    else
      echo "loose $file"
    fi
  done < <(find / -xdev \( -name 'id_*' -o -name '*.pem' \) -not -path '/usr/*' -not -path '/etc/ssl/*' -not -path '/home/runner/.local/*' 2>/dev/null)
}
# A key by content, under any name and whoever owns it (lead, 11-13): a PEM private-key line in any text file under
# 1 MiB on this disk, the image layers in runner's storage included. Paths only, never a file's contents. The one path
# left out is this server's own sshd host keys, which the cleanup below deletes; the line before the seal checks
# that none is left. Give it the root folder: / here, a test's folder in the tests.
readonly PRIVATE_KEY_LINE='^-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----$'
private_key_files() {
  # grep's 1 (no match in a batch) is a pass; its 2 (a file it could not read) is a hole in the scan, so it fails.
  # shellcheck disable=SC2016 # the inner scripts' $0, $1, $2 and $@ are their own arguments, expanded there
  timeout --kill-after=2m 15m bash -c 'set -o pipefail
root=${1%/}
find "${root:-/}" -xdev -path "$root/etc/ssh/ssh_host_*" -prune -o -type f -size -1024k -print0 |
  xargs -0 sh -c '\''grep -lIE -- "$0" "$@"; [ "$?" -le 1 ]'\'' "$2"' _ "$1" "$PRIVATE_KEY_LINE"
}
at="seal-keys"
key_list=$(key_files)
loose_keys=$(awk '$1 == "loose" { n++ } END { print n + 0 }' <<<"$key_list")
package_keys=$(awk '$1 == "package" { n++ } END { print n + 0 }' <<<"$key_list")
if [ "$loose_keys" != 0 ]; then
  say "key files no package ships unchanged: $(sed -n 's/^loose //p' <<<"$key_list" | tr '\n' ' ')"
  exit 1
fi
private_keys=$(private_key_files /)
# One exact allow (security PRB-L1, C2): the pinned postgres:16 may carry Debian's snakeoil key, public by design.
# Allowed only at etc/ssl/private/ssl-cert-snakeoil.key inside that image's own layers, as podman's inspect of the
# pinned digest names them (never a guessed storage path), and only when the file holds one key. The same file in
# any other layer, or on the host, still refuses the seal. The manifest names the layer and the file's sha256.
# Only when the scan found something is podman asked (security PRB-L4): a build with no key never depends on the
# inspect line, and one with a key still fails closed if podman names no layer.
readonly SNAKEOIL=etc/ssl/private/ssl-cert-snakeoil.key
snakeoil="none found"
if [ -n "$private_keys" ]; then
  plain_layers=$(as_runner podman image inspect --format '{{.GraphDriver.Data.UpperDir}}:{{.GraphDriver.Data.LowerDir}}' "docker.io/$IMAGE_PLAIN")
  if [[ ! $plain_layers =~ [^:] ]]; then
    say "podman named no layers for the pinned postgres:16"
    exit 1
  fi
  IFS=: read -r -a postgres_layers <<<"$plain_layers"
  snakeoil=absent
  others=""
  while IFS= read -r file; do
    [ -n "$file" ] || continue
    allowed=""
    for layer in "${postgres_layers[@]}"; do
      if [ -n "$layer" ] && [ "$file" = "${layer%/}/$SNAKEOIL" ] && [ "$(grep -cE "$PRIVATE_KEY_LINE" "$file")" = 1 ]; then
        allowed=$layer
      fi
    done
    if [ -n "$allowed" ]; then
      layer_id=${allowed%/}
      layer_id=${layer_id%/diff}
      snakeoil="present, layer ${layer_id##*/}, sha256 $(sha256sum "$file" | cut -d' ' -f1)"
    else
      others="$others$file"$'\n'
    fi
  done <<<"$private_keys"
  private_keys=${others%$'\n'}
fi
if [ -n "$private_keys" ]; then
  say "a private key is saved on this disk: $(tr '\n' ' ' <<<"$private_keys")"
  exit 1
fi
at="seal-quiet"
for name in "${network_files[@]}"; do
  if ! grep -qx 'UseNTP=no' "/etc/systemd/network/$name.d/90-tftvps-ntp.conf"; then
    say "$name has no drop-in that turns off DHCP's time server"
    exit 1
  fi
done
for package in "${HOST_GONE[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    say "$package is installed: it must be gone before the seal"
    exit 1
  fi
done
for unit in "${QUIET_UNITS[@]}"; do
  # is-enabled exits non-zero for a masked unit: the word it prints is the answer.
  state=$(systemctl is-enabled "$unit" 2>/dev/null) || state=${state:-}
  if [ "$state" != masked ]; then
    say "$unit is ${state:-unknown}, not masked"
    exit 1
  fi
done
if [ -e "$ESM_HOOK" ]; then
  say "$ESM_HOOK is still in place: apt would run the Pro hook"
  exit 1
fi
diverted=$(dpkg-divert --list "$ESM_HOOK")
if [[ $diverted != *"to $ESM_HOOK.tftvps-off"* ]]; then
  say "$ESM_HOOK has no diversion of ours: an upgrade could put it back"
  exit 1
fi
at=""
# --- end of the seal checks

say "seal"
manifest=$HOME_DIR/manifest
{
  echo "sealed $(date -u +%FT%TZ) arch $arch"
  as_runner podman images --digests --format '{{.Repository}} {{.Digest}}' | sort
  echo "key files: $loose_keys ($package_keys package files, dpkg-verified; 0 private-key blocks)"
  echo "allowed: snakeoil key of the pinned postgres:16 (public): $snakeoil"
  echo "timers: $(systemctl list-unit-files --state=enabled --type=timer --no-legend | awk '{print $1}' | tr '\n' ' ')"
  echo "masked: ${QUIET_UNITS[*]}"
  echo "esm hook: $diverted"
  echo "time: $(grep -E '^(NTP|FallbackNTP)=' "$TIME_CONF" | tr '\n' ' ')"
  echo "dhcp ntp: off for ${network_files[*]}"
  echo "host tools purged: ${host_purged[*]:-none}"
  for kept in ${host_kept[@]+"${host_kept[@]}"}; do echo "host tool waived (CIS L2): $kept"; done
  echo "image floor: $(printf '%s; ' "${image_floor[@]}")"
  echo "image setuid before: $(tr '\n' ' ' <<<"$image_setuid_before")"
  echo "image setuid after: ${image_setuid_after:-none}"
  echo "listening: $(ss -lntuH | wc -l)"
  echo "seccomp: $(sha256sum "$HOME_DIR/seccomp.json" | cut -d' ' -f1) from $(dpkg-query -W -f='${Package} ${Version}' "$seccomp_from")"
  echo "image mirrors: $(cut -f1 "$MIRRORS" | tr '\n' ' ')"
  # Two lists, each labelled with its count (security R12-L5): the run image's, then the host's. Diff each on its own.
  echo "image packages: $(wc -l <<<"$image_packages" | tr -d ' ') in the run image (not the host):"
  printf '%s\n' "$image_packages"
  host_packages=$(dpkg-query -W -f='${Package} ${Version}\n')
  echo "host packages that stayed: $(wc -l <<<"$host_packages" | tr -d ' ') on the host (not the run image):"
  printf '%s\n' "$host_packages"
} >"$manifest"
cat "$manifest" >/dev/console || true
passwd -l root
rm -f /root/.ssh/authorized_keys /home/ubuntu/.ssh/authorized_keys /etc/ssh/ssh_host_*
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id /root/.bash_history /home/ubuntu/.bash_history
cloud-init clean --logs --seed
apt-get clean
# The private-key scan left these out, because this line's rm above deletes them.
if compgen -G '/etc/ssh/ssh_host_*' >/dev/null; then
  say "an sshd host key is still in /etc/ssh: no seal"
  exit 1
fi
# The seal only once everything above is done (security L1): a cleanup line that fails leaves no `sealed` on disk, and
# boot refuses a disk with none.
# Plain lines only (security L5): each one that fails stops the build, and `sealed` appears whole or not at all.
# --- the seal: the vps tests run this block on its own
sealed_at=$(date +%s)
manifest_sum=$(sha256sum "$HOME_DIR/manifest" | cut -d' ' -f1)
if [[ ! $manifest_sum =~ ^[0-9a-f]{64}$ ]]; then
  say "the manifest's hash could not be read: no seal"
  exit 1
fi
printf '%s %s ' "$sealed_at" "$manifest_sum" >"$HOME_DIR/sealed.line"
mv "$HOME_DIR/sealed.line" "$HOME_DIR/sealed"
# --- end of the seal
# Sealed: from here no line is a build failure, and the stop at power-off must not read as one.
trap - ERR EXIT
say "SEALED. It powers off in 2 minutes. Take the snapshot only from this build- server."
sleep 120
systemctl poweroff
