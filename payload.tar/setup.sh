#!/bin/bash
# Builds the sealed image on a stock Ubuntu 24.04 server, then powers off. Takes no branch input: its only
# inputs are this folder, Ubuntu's archive and the pinned downloads. No key exists here and none is made.
set -Eeuo pipefail
export LC_ALL=C DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=l
readonly HOME_DIR=/opt/tftvps DATA=/var/lib/tftvps
say() { echo "tftvps setup: $*" | tee /dev/console; }

# One log and one way to fail. The launch script already sends this script's output to the log; appending here
# names the path in this file and keeps every writer at the log's end. A step's own output lands in the same log.
readonly LOG=/var/log/tftvps-setup.log RUN_DIR=/run/tftvps
exec >>"$LOG" 2>&1
# Each long step runs under `timeout`, so a hung step fails the build instead of hanging it. No step times are
# written down for round 5, whose whole build took about 30 minutes, so these are generous fixed limits: apt and
# mmdebstrap 30 min, a download, an import or a pull 20 min, one purge 10 min, autoremove 15 min. A step that
# ignores the stop signal is killed 2 minutes later. A time limit exits 124 (137 once killed).
at="" done_step="" failed_status=0 failed_line=0 step_began=0 step_limit=0
# Gives back the step's own code, in an `if` too. Notes when it began and its limit, the word after --kill-after=,
# so a failure can tell its time limit from any other end.
step() {
  local name=$1 word after="" code
  shift
  at=$name
  step_began=$(date +%s)
  step_limit=999999
  for word in "$@"; do
    if [ -n "$after" ]; then
      if [[ $word =~ ^([0-9]+)m$ ]]; then step_limit=$((BASH_REMATCH[1] * 60)); fi
      if [[ $word =~ ^([0-9]+)s$ ]]; then step_limit=${BASH_REMATCH[1]}; fi
      break
    fi
    case $word in --kill-after=*) after=1 ;; esac
  done
  echo "start $name $(date -u +%FT%TZ)"
  "$@" || {
    code=$?
    echo "failed $name $code after $(($(date +%s) - step_began))"
    return "$code"
  }
  echo "end $name $(($(date +%s) - step_began))"
  at="" done_step=$name
}
# Any failure, a time limit included, ends here: no seal and no power-off. The server stays up for the log to be
# read, so the message says to delete it, since a server that is up costs money.
on_exit() {
  local status=$? why text
  if [ "$status" -eq 0 ]; then
    return 0
  fi
  set +e
  why="exit $status"
  if [ "$failed_line" -ne 0 ]; then
    why="exit $failed_status at line $failed_line"
  fi
  # Only a step that ran its whole limit ended by it (security L2): 137 can also be the kernel's out-of-memory kill, and
  # a line outside a step has no limit at all.
  if [ -n "$at" ] && { [ "$failed_status" -eq 124 ] || [ "$failed_status" -eq 137 ]; } &&
    [ $(($(date +%s) - step_began)) -ge "$step_limit" ]; then
    why="its time limit ran out"
  fi
  text="BUILD FAILED at ${at:-a line after ${done_step:-the start}}: read $LOG, then delete this server; do not snapshot
($why)
--- the last 40 lines of $LOG ---
$(tail -n 40 "$LOG")"
  mkdir -p "$RUN_DIR"
  printf '%s\n' "$text" >"$RUN_DIR/message.txt"
  # A build that stopped early has not yet installed the login message that prints it.
  [ -e /etc/profile.d/tftvps.sh ] || install -m 755 "$HOME_DIR/login-message.sh" /etc/profile.d/tftvps.sh
  printf '%s\n' "$text" >/dev/console
  printf '%s\n' "$text"
  exit "$status"
}
trap 'failed_status=$? failed_line=$LINENO' ERR
trap on_exit EXIT

# shellcheck source=/dev/null
source "$HOME_DIR/pins.txt"
arch=$(dpkg --print-architecture)
case $arch in
  amd64) rust_triple=x86_64-unknown-linux-gnu; leaks_arch=x64; rust_sha=$RUST_SHA256_amd64; leaks_sha=$GITLEAKS_SHA256_amd64 ;;
  arm64) rust_triple=aarch64-unknown-linux-gnu; leaks_arch=arm64; rust_sha=$RUST_SHA256_arm64; leaks_sha=$GITLEAKS_SHA256_arm64 ;;
  *) say "no pins for $arch"; exit 1 ;;
esac

# The run image and the mirror list are amd64 only: archive.ubuntu.com and the EC2 mirrors carry no arm64, which is
# on ports.ubuntu.com. Refused by name before any mirror work (lead, 11-12); the arm64 pins stay for a later port.
at=arch
if [ "$arch" != amd64 ]; then
  say "arm64 needs ports.ubuntu.com; amd64 only"
  exit 1
fi
at=""

say "apt floor"
# --- the apt floor: the vps tests run this block on its own
# USN-8996-1 (CVE-2026-109518, 2026-11-04): apt below 2.8.4ubuntu0.1 can be made to install an unverified package when
# it follows a redirect and retries a download, as our mirrors' drops make it do. So the stock apt fetches nothing:
# the fixed .debs come over https from pins.txt, each is checked by sha256 before dpkg installs it, and the floor is
# checked after. No apt call and no other fetch of this script comes before this block, and any failure here stops
# the build here: it never falls back to an apt fetch. The stock image's own apt timers are stopped first, and a
# server whose apt already ran this boot is refused. apt-utils needs apt at its exact version, so it comes too when
# installed; every library the three need is older than noble's own release versions.
at=apt-floor
for unit in apt-daily.timer apt-daily-upgrade.timer apt-daily.service apt-daily-upgrade.service; do
  if systemctl cat "$unit" >/dev/null 2>&1; then systemctl stop "$unit"; fi
done
for unit in apt-daily.service apt-daily-upgrade.service; do
  started=$(systemctl show -p ExecMainStartTimestampMonotonic --value "$unit")
  if [ -n "$started" ] && [ "$started" != 0 ]; then
    say "$unit ran this boot with the stock apt, before the floor: delete this server"
    exit 1
  fi
done
floor_ok() {
  local package version
  for package in apt libapt-pkg6.0t64; do
    version=$(dpkg-query -W -f='${Version}' "$package" 2>/dev/null) || return 1
    dpkg --compare-versions "$version" ge "$APT_MIN_VERSION" || return 1
  done
}
if floor_ok; then
  say "apt floor: apt $(dpkg-query -W -f='${Version}' apt) is at or above $APT_MIN_VERSION, nothing to install"
else
  floor_dir=$(mktemp -d)
  floor_debs=()
  for pin in APT LIBAPT APT_UTILS; do
    if [ "$pin" = APT_UTILS ] && ! dpkg -s apt-utils >/dev/null 2>&1; then continue; fi
    url_name=${pin}_DEB_URL sha_name=${pin}_DEB_SHA256
    floor_file=$floor_dir/${!url_name##*/}
    step apt-floor-download timeout --kill-after=2m 10m curl -fsS --proto =https --tlsv1.2 --retry 3 -o "$floor_file" "${!url_name}"
    at=apt-floor
    echo "${!sha_name}  $floor_file" | sha256sum --strict --check --quiet
    floor_debs+=("$floor_file")
  done
  step apt-floor-install timeout --kill-after=2m 10m dpkg -i "${floor_debs[@]}"
  rm -rf "$floor_dir"
  at=apt-floor
  if ! floor_ok; then
    say "apt is still below $APT_MIN_VERSION after the pinned install"
    exit 1
  fi
  say "apt floor: apt $(dpkg-query -W -f='${Version}' apt), from the pinned .debs"
fi
at=""
# --- end of the apt floor

say "mirrors"
# --- the mirror: the vps tests run this block on its own
# 11-12, proven by the owner in Frankfurt as in Ireland: an EC2 Ubuntu mirror drops about one connection per ~80 MB.
# With apt's retries off one file in ~76 failed every run; with retries the same run was clean. So apt retries each
# file, set here rather than left to apt's default, for the host's apt and for mmdebstrap alike (one file, both
# paths). 5 tries: a build fetches ~300 MB, so ~3-4 drops each on its own file, and one retry fixed every drop seen;
# apt's own back-off waits at most ~31 s per file. The timeouts count seconds with no data, not a whole download, so
# a slow mirror that still sends is never cut, and one that stalls costs at most ~3.5 min per file.
readonly ACQUIRE=/etc/apt/apt.conf.d/80tftvps-acquire
readonly ACQUIRE_LINES='Acquire::Retries "5";
Acquire::http::Timeout "30";
Acquire::https::Timeout "30";'
# The second layer, outage failover only: apt's mirror method takes a file that still fails from the next mirror,
# lowest priority first (with no priority apt picks the order at random). Every entry is checked the same way:
# the Release file's signature against Ubuntu's keyring, and each package against that file's hashes.
readonly ARCHIVE=http://archive.ubuntu.com/ubuntu/ MIRRORS=/etc/apt/tftvps-mirrors.list
readonly SECOND=http://eu-central-1.ec2.archive.ubuntu.com/ubuntu/ SECOND_ELSE=http://eu-west-1.ec2.archive.ubuntu.com/ubuntu/
# Named, not left to apt's default (security L1): the build stops on a missing or empty keyring before any fetch.
readonly KEYRING=/usr/share/keyrings/ubuntu-archive-keyring.gpg
# The host's sources as the image shipped them, kept once (lead L1): a second run on the same host reads its mirror
# from these, not from the files the first run rewrote.
readonly ORIG=/etc/apt/tftvps-orig
# The mirror the host's own apt uses for noble main: the first URIs of a deb822 stanza whose Suites hold noble and
# whose Components hold main, else the first `deb <uri> noble ... main` line. Only http(s)://<host>/ubuntu[/] counts,
# the host letters, digits, dots and hyphens; anything else is no mirror. It comes from this host's own config, so it
# holds on any provider. Prints the URI, or nothing.
host_mirror() {
  local found=""
  if [ -r "$1" ]; then
    found=$(awk '
      function flush() {
        if (!done && uri != "" && enabled != "no" && types ~ /(^| )deb( |$)/ && suites ~ /(^| )noble( |$)/ && parts ~ /(^| )main( |$)/) { print uri; done = 1 }
        types = ""; suites = ""; parts = ""; uri = ""; enabled = ""
      }
      /^[ \t]*$/ { flush(); next }
      /^#/ { next }
      tolower($1) == "types:" { $1 = ""; types = $0 }
      tolower($1) == "uris:" { uri = $2 }
      tolower($1) == "suites:" { $1 = ""; suites = $0 }
      tolower($1) == "components:" { $1 = ""; parts = $0 }
      tolower($1) == "enabled:" { enabled = tolower($2) }
      END { flush() }
    ' "$1")
  fi
  if [ -z "$found" ] && [ -r "$2" ]; then
    found=$(awk '
      $1 == "deb" {
        at = 2
        if ($at ~ /^\[/) { while (at <= NF && $at !~ /\]$/) at++; at++ }
        if ($(at + 1) == "noble") { for (part = at + 2; part <= NF; part++) if ($part == "main") { print $at; exit } }
      }
    ' "$2")
  fi
  if [[ $found =~ ^https?://[A-Za-z0-9.-]+/ubuntu/?$ ]]; then printf '%s\n' "$found"; fi
}
# The list, one mirror a line, a tab, then its priority: the host's own mirror if it has one, Ubuntu's archive, then
# a second region (eu-west-1 when the host's own is eu-central-1). Each URI once, with one trailing slash.
mirror_list() {
  local second=$SECOND seen=" " uri n=1
  if [ "${1%/}/" = "$SECOND" ]; then second=$SECOND_ELSE; fi
  for uri in ${1:+"${1%/}/"} "$ARCHIVE" "$second"; do
    case $seen in *" $uri "*) continue ;; esac
    seen="$seen$uri "
    printf '%s\tpriority:%d\n' "$uri" "$n"
    n=$((n + 1))
  done
}
# The host's own sources: the list for noble and its updates, security's own host as before, both signature-checked.
host_sources() {
  printf 'Types: deb\nURIs: mirror+file:%s\nSuites: noble noble-updates noble-backports\nComponents: main restricted universe multiverse\nSigned-By: %s\n\n' "$MIRRORS" "$KEYRING"
  printf 'Types: deb\nURIs: http://security.ubuntu.com/ubuntu/\nSuites: noble-security\nComponents: main restricted universe multiverse\nSigned-By: %s\n' "$KEYRING"
}
# The run image's one source: a whole deb line, never a bare URI, from which mmdebstrap would add -updates and
# -security of its own (another package set than debootstrap's, and security past the list). noble main only, as before.
readonly IMAGE_SOURCE="deb [signed-by=$KEYRING] mirror+file:$MIRRORS noble main"
# --- end of the mirror
# --- the mirror files: the vps tests run this block on its own
at=keyring
if [ ! -s "$KEYRING" ]; then
  say "no Ubuntu archive keyring at $KEYRING: apt could not check the Release signature"
  exit 1
fi
at=mirror-list
if [ ! -d "$ORIG" ]; then
  mkdir -p "$ORIG.new"
  if [ -e /etc/apt/sources.list.d/ubuntu.sources ]; then cp -p /etc/apt/sources.list.d/ubuntu.sources "$ORIG.new/ubuntu.sources"; fi
  if [ -e /etc/apt/sources.list ]; then cp -p /etc/apt/sources.list "$ORIG.new/sources.list"; fi
  mv "$ORIG.new" "$ORIG"
fi
mirror=$(host_mirror "$ORIG/ubuntu.sources" "$ORIG/sources.list")
mirror_list "$mirror" >"$MIRRORS"
printf '%s\n' "$ACQUIRE_LINES" >"$ACQUIRE"
host_sources >/etc/apt/sources.list.d/ubuntu.sources
# Active lines of the legacy list would fetch past the mirror list (lead L2), so they are turned into comments, and
# the log says how many. Noble's own file holds none.
if [ -e /etc/apt/sources.list ]; then
  legacy=$(awk '$1 == "deb" || $1 == "deb-src" { n++ } END { print n + 0 }' /etc/apt/sources.list)
  if [ "$legacy" != 0 ]; then
    awk '{ if ($1 == "deb" || $1 == "deb-src") print "# tftvps, off: the mirror list is in ubuntu.sources: " $0; else print }' \
      /etc/apt/sources.list >/etc/apt/sources.list.tftvps-new
    cat /etc/apt/sources.list.tftvps-new >/etc/apt/sources.list
    rm -f /etc/apt/sources.list.tftvps-new
    say "sources.list: $legacy active line(s) turned off; the mirror list is in ubuntu.sources"
  fi
fi
chmod 644 "$MIRRORS" "$ACQUIRE" /etc/apt/sources.list.d/ubuntu.sources
# A lane boots from the snapshot with cloud-init cleaned (the seal's `cloud-init clean --seed`), and boot.py's patch
# step then runs apt-get update and full-upgrade. cloud-init's apt module would write ubuntu.sources back to the bare
# regional mirror on that first boot; this keeps the list there too. The retries file survives either way.
mkdir -p /etc/cloud/cloud.cfg.d
readonly CLOUD_APT=/etc/cloud/cloud.cfg.d/90-tftvps-apt.cfg
printf '# tftvps: keep the mirror list of vps/setup.sh; boot.py runs apt on every lane.\napt:\n  preserve_sources_list: true\n' >"$CLOUD_APT"
chmod 644 "$CLOUD_APT"
at=""
say "mirrors: $(cut -f1 "$MIRRORS" | tr '\n' ' ')"
# --- end of the mirror files

say "packages"
step apt-update timeout --kill-after=2m 30m apt-get update
step apt-full-upgrade timeout --kill-after=2m 30m \
  apt-get -y -o Dpkg::Options::=--force-confold -o APT::Get::Always-Include-Phased-Updates=true full-upgrade
step apt-install timeout --kill-after=2m 30m apt-get -y install --no-install-recommends podman uidmap crun catatonit nftables git python3 mmdebstrap sudo \
  openssh-client openssh-server curl xz-utils iproute2 ca-certificates systemd-timesyncd libnss-myhostname
# What other users could reach locally, and what has a history of local privilege bugs. One at a time, because
# apt drops a whole list over one unknown name, and then checked, so a package that stayed stops the build.
strip=(snapd packagekit polkitd policykit-1 unattended-upgrades needrestart ec2-instance-connect
  systemd-resolved apport motd-news-config landscape-common multipath-tools)
for package in "${strip[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    step "purge-$package" timeout --kill-after=2m 10m apt-get -y purge "$package"
  fi
done
step apt-autoremove timeout --kill-after=2m 15m apt-get -y autoremove --purge
for package in "${strip[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    say "$package is still installed"
    exit 1
  fi
done
rm -f /etc/resolv.conf
printf 'nameserver 1.1.1.1\nnameserver 9.9.9.9\n' >/etc/resolv.conf
# With systemd-resolved gone nothing answers this machine's own name, so sudo asked DNS for it, as the user who
# typed sudo, and the wall dropped it. myhostname answers whatever name a clone is given, at every boot, from the
# kernel, with no network and no file to write. DNS stays open to no more users.
sed -i 's/^hosts:.*/hosts: files myhostname dns/' /etc/nsswitch.conf
grep -qx 'hosts: files myhostname dns' /etc/nsswitch.conf
getent -s myhostname hosts "$(cat /proc/sys/kernel/hostname)" >/dev/null

say "users"
for user in poller fetcher runner; do
  id "$user" >/dev/null 2>&1 || useradd --create-home --home-dir "/home/$user" --shell /usr/sbin/nologin "$user"
  chmod 700 "/home/$user"
done
grep -q '^runner:' /etc/subuid || usermod --add-subuids 200000-265535 --add-subgids 200000-265535 runner
loginctl enable-linger runner
mkdir -p /etc/systemd/system/user@.service.d
printf '[Service]\nDelegate=cpu cpuset io memory pids\n' >/etc/systemd/system/user@.service.d/delegate.conf
# Ubuntu 24.04 limits user namespaces by profile, and the limit stays on for everything else. A profile of Ubuntu's
# own for this path is enough; a second one for the same path could conflict. Without one, ours must load.
if [ ! -e /etc/apparmor.d/podman ]; then
  install -m 644 "$HOME_DIR/apparmor-podman" /etc/apparmor.d/tftvps-podman
  apparmor_parser -r /etc/apparmor.d/tftvps-podman
fi

say "data folders"
mkdir -p "$DATA/crates"
git init -q --bare "$DATA/store"
chown -R poller:poller "$DATA/store"
chmod -R u=rwX,g=rX,o=rX "$DATA/store"
chown fetcher:fetcher "$DATA/crates"
chmod 755 "$DATA/crates"
# One fixed-size volume for the one run at a time, sparse here and formatted now. A second slot is NOT BUILT.
for slot in 0; do
  truncate -s 60G "$DATA/slot$slot.img"
  mkfs.ext4 -q -F -m 0 "$DATA/slot$slot.img"
  mkdir -p "$DATA/slot$slot"
  grep -q "slot$slot.img" /etc/fstab || echo "$DATA/slot$slot.img $DATA/slot$slot ext4 loop,nosuid,nodev 0 0" >>/etc/fstab
  mount "$DATA/slot$slot"
  chown runner:runner "$DATA/slot$slot"
  umount "$DATA/slot$slot"
done

say "pinned downloads"
work=$(mktemp -d)
rust_file=rust-$RUST_VERSION-$rust_triple.tar.xz
step download-rust timeout --kill-after=2m 20m \
  curl -fsSL --retry 3 -o "$work/$rust_file" "https://static.rust-lang.org/dist/$rust_file"
echo "$rust_sha  $work/$rust_file" | sha256sum --strict --check --quiet
leaks_file=gitleaks_${GITLEAKS_VERSION}_linux_$leaks_arch.tar.gz
step download-gitleaks timeout --kill-after=2m 20m \
  curl -fsSL --retry 3 -o "$work/$leaks_file" "https://github.com/gitleaks/gitleaks/releases/download/v$GITLEAKS_VERSION/$leaks_file"
echo "$leaks_sha  $work/$leaks_file" | sha256sum --strict --check --quiet

say "run image, from Ubuntu's archive"
root=$work/rootfs
# gnupg and sudo: tests/setup_staging.rs needs gpg and visudo, and fails without them when GITHUB_ACTIONS is set.
# No-new-privileges keeps sudo's setuid bit from doing anything in a run. jq: tests/deploy.rs's fake gh runs the
# script's own --jq filter through it, as hosted CI's runner image has it.
# From the mirror list above, through apt, so each file gets apt's retries and then the next mirror. Any mirror is
# safe: apt checks the Release file's signature against Ubuntu's keyring and each package against that file's hashes,
# and nothing here turns that check off. The same variant and packages debootstrap took, no Recommends (as
# debootstrap), root mode named. --verbose keeps apt's own lines (Ign, Get, Err) in this step's log. The setup hook
# puts the list at the same path in the rootfs, so the source resolves whichever root apt reads it from.
# --- the run image: the vps tests run this block on its own
step mmdebstrap timeout --kill-after=2m 30m mmdebstrap --mode=root --variant=minbase --verbose --keyring="$KEYRING" \
  --aptopt="$ACQUIRE" --aptopt='APT::Install-Recommends "false";' --setup-hook="install -D -m 644 $MIRRORS \"\$1$MIRRORS\"" \
  --include=bash,coreutils,util-linux,git,python3,build-essential,pkg-config,postgresql-client,ca-certificates,openssl,tar,gzip,procps,iproute2,curl,gnupg,sudo,hostname,jq \
  noble "$root" "$IMAGE_SOURCE"
say "mmdebstrap done, from $(cut -f1 "$MIRRORS" | tr '\n' ' ')"
# --- end of the run image
# The run's plain user, uid and gid as profile.json's "user": tests refuse root, as hosted CI's runner is not root.
# Its home is the slot's volume, which runctl hands to it for the run.
chroot "$root" useradd --uid 1000 --user-group --no-create-home --home-dir /work --shell /bin/bash tester
mkdir -p "$root/opt/rust" "$root/opt/gitleaks" "$root/opt/tftvps" "$root/work" "$root/crates" "$root/scan"
tar -xJf "$work/$rust_file" -C "$work"
"$work/${rust_file%.tar.xz}/install.sh" --prefix="$root/opt/rust" --destdir="" --disable-ldconfig --without=rust-docs >/dev/null
tar -xzf "$work/$leaks_file" -C "$root/opt/gitleaks" gitleaks
install -m 644 "$HOME_DIR/gitleaks.toml" "$root/opt/gitleaks/config.toml"
install -m 644 "$HOME_DIR/gitleaks-result.toml" "$root/opt/gitleaks/result.toml"
install -m 755 "$HOME_DIR/in-container.sh" "$root/opt/tftvps/in-container.sh"
image_packages=$(chroot "$root" dpkg-query -W -f='${Package} ${Version}\n')
tar -C "$root" -c . >"$work/rootfs.tar"
chown runner "$work" "$work/rootfs.tar"
chmod 755 "$work"
as_runner() { sudo -n -H -u runner env XDG_RUNTIME_DIR="/run/user/$(id -u runner)" "$@"; }
systemctl start "user@$(id -u runner).service"
# The time limit runs as runner, inside sudo, so it stops runner's own podman; its exit code passes back through.
step podman-import as_runner timeout --kill-after=2m 20m podman import -q "$work/rootfs.tar" localhost/tftvps-run:sealed
step pull-timescale as_runner timeout --kill-after=2m 20m podman pull -q "docker.io/$IMAGE_TIMESCALE"
step pull-plain as_runner timeout --kill-after=2m 20m podman pull -q "docker.io/$IMAGE_PLAIN"
rm -rf "$work"

say "system files"
install -m 644 "$HOME_DIR/nftables.conf" /etc/nftables.conf
install -m 644 "$HOME_DIR"/units/* /etc/systemd/system/
install -m 440 "$HOME_DIR/sudoers" /etc/sudoers.d/tftvps
visudo -cqf /etc/sudoers.d/tftvps
install -m 644 "$HOME_DIR/sshd-before-arming.conf" /etc/ssh/sshd_config.d/00-tftvps.conf
install -m 755 "$HOME_DIR/login-message.sh" /etc/profile.d/tftvps.sh
chown -R root:root "$HOME_DIR"
chmod -R go-w "$HOME_DIR"
# A program boot needs and cannot find stops the build here, not a clone later.
/usr/bin/python3 -I "$HOME_DIR/vps.py" check-programs
# Every container's seccomp profile, from podman's own default as this package ships it, with namespaces taken out.
# A default of a shape the code does not know stops the build. Its hash and source go into the manifest below.
/usr/bin/python3 -I "$HOME_DIR/vps.py" seccomp
seccomp_from=$(dpkg-query -S /usr/share/containers/seccomp.json | cut -d: -f1)
systemctl enable nftables.service tftvps-boot.service tftvps-idle.timer tftvps-limit.timer
systemctl disable apt-daily.timer apt-daily-upgrade.timer 2>/dev/null || true
# A boot unit in an ordering cycle is dropped with no word in its own log, and a clone then never arms. Refuse to
# seal unless cloud-init.target pulls it in and systemd's own check of a boot finds no cycle. Only that check's
# words count: its exit code also covers Ubuntu's units, which are not ours to fix here.
systemctl daemon-reload
systemctl show -p Wants --value cloud-init.target | tr ' ' '\n' | grep -qx tftvps-boot.service
systemctl show -p WantedBy --value cloud-init.target | tr ' ' '\n' | grep -qx multi-user.target
verify_log=$(mktemp)
systemd-analyze --man=no --generators=yes verify default.target tftvps-boot.service >"$verify_log" 2>&1 ||
  say "systemd-analyze verify exited non-zero; only a cycle in its words stops the build"
if grep -iE 'ordering cycle|to break ordering' "$verify_log"; then
  say "an ordering cycle at boot: the boot unit would not start"
  exit 1
fi
rm -f "$verify_log"

say "seal"
manifest=$HOME_DIR/manifest
{
  echo "sealed $(date -u +%FT%TZ) arch $arch"
  as_runner podman images --digests --format '{{.Repository}} {{.Digest}}' | sort
  echo "key files: $(find / -xdev \( -name 'id_*' -o -name '*.pem' \) -not -path '/usr/*' -not -path '/etc/ssl/*' -not -path '/home/runner/.local/*' 2>/dev/null | wc -l)"
  echo "timers: $(systemctl list-unit-files --state=enabled --type=timer --no-legend | awk '{print $1}' | tr '\n' ' ')"
  echo "listening: $(ss -lntuH | wc -l)"
  echo "seccomp: $(sha256sum "$HOME_DIR/seccomp.json" | cut -d' ' -f1) from $(dpkg-query -W -f='${Package} ${Version}' "$seccomp_from")"
  echo "image mirrors: $(cut -f1 "$MIRRORS" | tr '\n' ' ')"
  echo "image packages:"
  printf '%s\n' "$image_packages"
  echo "packages that stayed:"
  dpkg-query -W -f='${Package} ${Version}\n'
} >"$manifest"
cat "$manifest" >/dev/console || true
passwd -l root
rm -f /root/.ssh/authorized_keys /home/ubuntu/.ssh/authorized_keys /etc/ssh/ssh_host_*
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id /root/.bash_history /home/ubuntu/.bash_history
cloud-init clean --logs --seed
apt-get clean
# The seal only once everything above is done (security L1): a cleanup line that fails leaves no `sealed` on disk, and
# boot refuses a disk with none.
# Plain lines only (security L5): each one that fails stops the build, and `sealed` appears whole or not at all.
# --- the seal: the vps tests run this block on its own
sealed_at=$(date +%s)
manifest_sum=$(sha256sum "$HOME_DIR/manifest" | cut -d' ' -f1)
if [[ ! $manifest_sum =~ ^[0-9a-f]{64}$ ]]; then
  say "the manifest's hash could not be read: no seal"
  exit 1
fi
printf '%s %s ' "$sealed_at" "$manifest_sum" >"$HOME_DIR/sealed.line"
mv "$HOME_DIR/sealed.line" "$HOME_DIR/sealed"
# --- end of the seal
# Sealed: from here no line is a build failure, and the stop at power-off must not read as one.
trap - ERR EXIT
say "SEALED. It powers off in 2 minutes. Take the snapshot only from this build- server."
sleep 120
systemctl poweroff
