#!/bin/bash
# Builds the sealed image on a stock Ubuntu 24.04 server, then powers off. Takes no branch input: its only
# inputs are this folder, Ubuntu's archive and the pinned downloads. No key exists here and none is made.
set -Eeuo pipefail
export LC_ALL=C DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=l
readonly HOME_DIR=/opt/tftvps DATA=/var/lib/tftvps
say() { echo "tftvps setup: $*" | tee /dev/console; }

# One log and one way to fail. The launch script already sends this script's output to the log; appending here
# names the path in this file and keeps every writer at the log's end. A step's own output lands in the same log.
readonly LOG=/var/log/tftvps-setup.log RUN_DIR=/run/tftvps
exec >>"$LOG" 2>&1
# Each long step runs under `timeout`, so a hung step fails the build instead of hanging it. No step times are
# written down for round 5, whose whole build took about 30 minutes, so these are generous fixed limits: apt and
# debootstrap 30 min, a download, an import or a pull 20 min, one purge 10 min, autoremove 15 min. A step that
# ignores the stop signal is killed 2 minutes later. A time limit exits 124 (137 once killed).
at="" done_step="" failed_status=0 failed_line=0 step_began=0 step_limit=0
# Gives back the step's own code, in an `if` too. Notes when it began and its limit, the word after --kill-after=,
# so a failure can tell its time limit from any other end.
step() {
  local name=$1 word after="" code
  shift
  at=$name
  step_began=$(date +%s)
  step_limit=999999
  for word in "$@"; do
    if [ -n "$after" ]; then
      if [[ $word =~ ^([0-9]+)m$ ]]; then step_limit=$((BASH_REMATCH[1] * 60)); fi
      if [[ $word =~ ^([0-9]+)s$ ]]; then step_limit=${BASH_REMATCH[1]}; fi
      break
    fi
    case $word in --kill-after=*) after=1 ;; esac
  done
  echo "start $name $(date -u +%FT%TZ)"
  "$@" || {
    code=$?
    echo "failed $name $code after $(($(date +%s) - step_began))"
    return "$code"
  }
  echo "end $name $(($(date +%s) - step_began))"
  at="" done_step=$name
}
# Any failure, a time limit included, ends here: no seal and no power-off. The server stays up for the log to be
# read, so the message says to delete it, since a server that is up costs money.
on_exit() {
  local status=$? why text
  if [ "$status" -eq 0 ]; then
    return 0
  fi
  set +e
  why="exit $status"
  if [ "$failed_line" -ne 0 ]; then
    why="exit $failed_status at line $failed_line"
  fi
  # Only a step that ran its whole limit ended by it (security L2): 137 can also be the kernel's out-of-memory kill, and
  # a line outside a step has no limit at all.
  if [ -n "$at" ] && { [ "$failed_status" -eq 124 ] || [ "$failed_status" -eq 137 ]; } &&
    [ $(($(date +%s) - step_began)) -ge "$step_limit" ]; then
    why="its time limit ran out"
  fi
  text="BUILD FAILED at ${at:-a line after ${done_step:-the start}}: read $LOG, then delete this server; do not snapshot
($why)
--- the last 40 lines of $LOG ---
$(tail -n 40 "$LOG")"
  mkdir -p "$RUN_DIR"
  printf '%s\n' "$text" >"$RUN_DIR/message.txt"
  # A build that stopped early has not yet installed the login message that prints it.
  [ -e /etc/profile.d/tftvps.sh ] || install -m 755 "$HOME_DIR/login-message.sh" /etc/profile.d/tftvps.sh
  printf '%s\n' "$text" >/dev/console
  printf '%s\n' "$text"
  exit "$status"
}
trap 'failed_status=$? failed_line=$LINENO' ERR
trap on_exit EXIT

# shellcheck source=/dev/null
source "$HOME_DIR/pins.txt"
arch=$(dpkg --print-architecture)
case $arch in
  amd64) rust_triple=x86_64-unknown-linux-gnu; leaks_arch=x64; rust_sha=$RUST_SHA256_amd64; leaks_sha=$GITLEAKS_SHA256_amd64 ;;
  arm64) rust_triple=aarch64-unknown-linux-gnu; leaks_arch=arm64; rust_sha=$RUST_SHA256_arm64; leaks_sha=$GITLEAKS_SHA256_arm64 ;;
  *) say "no pins for $arch"; exit 1 ;;
esac

say "packages"
step apt-update timeout --kill-after=2m 30m apt-get update
step apt-full-upgrade timeout --kill-after=2m 30m \
  apt-get -y -o Dpkg::Options::=--force-confold -o APT::Get::Always-Include-Phased-Updates=true full-upgrade
step apt-install timeout --kill-after=2m 30m apt-get -y install --no-install-recommends podman uidmap crun catatonit nftables git python3 debootstrap sudo \
  openssh-client openssh-server curl xz-utils iproute2 ca-certificates systemd-timesyncd libnss-myhostname
# What other users could reach locally, and what has a history of local privilege bugs. One at a time, because
# apt drops a whole list over one unknown name, and then checked, so a package that stayed stops the build.
strip=(snapd packagekit polkitd policykit-1 unattended-upgrades needrestart ec2-instance-connect
  systemd-resolved apport motd-news-config landscape-common multipath-tools)
for package in "${strip[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    step "purge-$package" timeout --kill-after=2m 10m apt-get -y purge "$package"
  fi
done
step apt-autoremove timeout --kill-after=2m 15m apt-get -y autoremove --purge
for package in "${strip[@]}"; do
  if dpkg -s "$package" >/dev/null 2>&1; then
    say "$package is still installed"
    exit 1
  fi
done
rm -f /etc/resolv.conf
printf 'nameserver 1.1.1.1\nnameserver 9.9.9.9\n' >/etc/resolv.conf
# With systemd-resolved gone nothing answers this machine's own name, so sudo asked DNS for it, as the user who
# typed sudo, and the wall dropped it. myhostname answers whatever name a clone is given, at every boot, from the
# kernel, with no network and no file to write. DNS stays open to no more users.
sed -i 's/^hosts:.*/hosts: files myhostname dns/' /etc/nsswitch.conf
grep -qx 'hosts: files myhostname dns' /etc/nsswitch.conf
getent -s myhostname hosts "$(cat /proc/sys/kernel/hostname)" >/dev/null

say "users"
for user in poller fetcher runner; do
  id "$user" >/dev/null 2>&1 || useradd --create-home --home-dir "/home/$user" --shell /usr/sbin/nologin "$user"
  chmod 700 "/home/$user"
done
grep -q '^runner:' /etc/subuid || usermod --add-subuids 200000-265535 --add-subgids 200000-265535 runner
loginctl enable-linger runner
mkdir -p /etc/systemd/system/user@.service.d
printf '[Service]\nDelegate=cpu cpuset io memory pids\n' >/etc/systemd/system/user@.service.d/delegate.conf
# Ubuntu 24.04 limits user namespaces by profile, and the limit stays on for everything else. A profile of Ubuntu's
# own for this path is enough; a second one for the same path could conflict. Without one, ours must load.
if [ ! -e /etc/apparmor.d/podman ]; then
  install -m 644 "$HOME_DIR/apparmor-podman" /etc/apparmor.d/tftvps-podman
  apparmor_parser -r /etc/apparmor.d/tftvps-podman
fi

say "data folders"
mkdir -p "$DATA/crates"
git init -q --bare "$DATA/store"
chown -R poller:poller "$DATA/store"
chmod -R u=rwX,g=rX,o=rX "$DATA/store"
chown fetcher:fetcher "$DATA/crates"
chmod 755 "$DATA/crates"
# One fixed-size volume for the one run at a time, sparse here and formatted now. A second slot is NOT BUILT.
for slot in 0; do
  truncate -s 60G "$DATA/slot$slot.img"
  mkfs.ext4 -q -F -m 0 "$DATA/slot$slot.img"
  mkdir -p "$DATA/slot$slot"
  grep -q "slot$slot.img" /etc/fstab || echo "$DATA/slot$slot.img $DATA/slot$slot ext4 loop,nosuid,nodev 0 0" >>/etc/fstab
  mount "$DATA/slot$slot"
  chown runner:runner "$DATA/slot$slot"
  umount "$DATA/slot$slot"
done

say "pinned downloads"
work=$(mktemp -d)
rust_file=rust-$RUST_VERSION-$rust_triple.tar.xz
step download-rust timeout --kill-after=2m 20m \
  curl -fsSL --retry 3 -o "$work/$rust_file" "https://static.rust-lang.org/dist/$rust_file"
echo "$rust_sha  $work/$rust_file" | sha256sum --strict --check --quiet
leaks_file=gitleaks_${GITLEAKS_VERSION}_linux_$leaks_arch.tar.gz
step download-gitleaks timeout --kill-after=2m 20m \
  curl -fsSL --retry 3 -o "$work/$leaks_file" "https://github.com/gitleaks/gitleaks/releases/download/v$GITLEAKS_VERSION/$leaks_file"
echo "$leaks_sha  $work/$leaks_file" | sha256sum --strict --check --quiet

say "run image, from Ubuntu's archive"
root=$work/rootfs
# --- the mirror: the vps tests run this block on its own
readonly ARCHIVE=http://archive.ubuntu.com/ubuntu DEBOOTSTRAP_SECONDS=1800
# The mirror the host's own apt uses for noble main: the first URIs of a deb822 stanza whose Suites hold noble and
# whose Components hold main, else the first `deb <uri> noble ... main` line. Only http(s)://<host>/ubuntu[/] counts,
# the host letters, digits, dots and hyphens; anything else is no mirror. It comes from this host's own config, so it
# holds on any provider. Prints the URI, or nothing.
host_mirror() {
  local found=""
  if [ -r "$1" ]; then
    found=$(awk '
      function flush() {
        if (!done && uri != "" && enabled != "no" && types ~ /(^| )deb( |$)/ && suites ~ /(^| )noble( |$)/ && parts ~ /(^| )main( |$)/) { print uri; done = 1 }
        types = ""; suites = ""; parts = ""; uri = ""; enabled = ""
      }
      /^[ \t]*$/ { flush(); next }
      /^#/ { next }
      tolower($1) == "types:" { $1 = ""; types = $0 }
      tolower($1) == "uris:" { uri = $2 }
      tolower($1) == "suites:" { $1 = ""; suites = $0 }
      tolower($1) == "components:" { $1 = ""; parts = $0 }
      tolower($1) == "enabled:" { enabled = tolower($2) }
      END { flush() }
    ' "$1")
  fi
  if [ -z "$found" ] && [ -r "$2" ]; then
    found=$(awk '
      $1 == "deb" {
        at = 2
        if ($at ~ /^\[/) { while (at <= NF && $at !~ /\]$/) at++; at++ }
        if ($(at + 1) == "noble") { for (part = at + 2; part <= NF; part++) if ($part == "main") { print $at; exit } }
      }
    ' "$2")
  fi
  if [[ $found =~ ^https?://[A-Za-z0-9.-]+/ubuntu/?$ ]]; then printf '%s\n' "$found"; fi
}
# --- end of the mirror
# What a killed debootstrap leaves: its chroot's mounts first, then the folder, never across into another filesystem.
clear_rootfs() {
  findmnt -rn -o TARGET | awk -v under="$root/" 'index($0, under) == 1' | sort -r | while read -r target; do
    umount -l "$target"
  done
  rm -rf --one-file-system "$root"
}
# gnupg and sudo: tests/setup_staging.rs needs gpg and visudo, and fails without them when GITHUB_ACTIONS is set.
# No-new-privileges keeps sudo's setuid bit from doing anything in a run. jq: tests/deploy.rs's fake gh runs the
# script's own --jq filter through it, as hosted CI's runner image has it.
# From the host's own mirror (archive.ubuntu.com crawled on 11-07 until the limit), with one try from the archive in
# what is left of the same 30 min. Any mirror is safe: debootstrap checks the Release file's signature against
# Ubuntu's keyring and each package against that file's hashes, and this never turns that check off.
mirror=$(host_mirror /etc/apt/sources.list.d/ubuntu.sources /etc/apt/sources.list)
debootstrap_from=${mirror:-$ARCHIVE}
say "debootstrap from $debootstrap_from"
debootstrap_began=$(date +%s)
status=0
step debootstrap timeout --kill-after=2m 30m debootstrap --variant=minbase --include=bash,coreutils,util-linux,git,python3,build-essential,pkg-config,postgresql-client,ca-certificates,openssl,tar,gzip,procps,iproute2,curl,gnupg,sudo,hostname,jq \
  noble "$root" "$debootstrap_from" || status=$?
if [ "$status" != 0 ]; then
  left=$((DEBOOTSTRAP_SECONDS - ($(date +%s) - debootstrap_began)))
  if [ "$debootstrap_from" = "$ARCHIVE" ] || [ "$left" -le 0 ]; then
    failed_status=$status failed_line=$LINENO
    exit "$status"
  fi
  say "debootstrap from $debootstrap_from failed ($status); once more from $ARCHIVE, in the ${left}s left of its 30 min"
  clear_rootfs
  debootstrap_from=$ARCHIVE
  step debootstrap-fallback timeout --kill-after=2m "${left}s" debootstrap --variant=minbase --include=bash,coreutils,util-linux,git,python3,build-essential,pkg-config,postgresql-client,ca-certificates,openssl,tar,gzip,procps,iproute2,curl,gnupg,sudo,hostname,jq \
    noble "$root" "$ARCHIVE"
fi
say "debootstrap done, from $debootstrap_from"
# The run's plain user, uid and gid as profile.json's "user": tests refuse root, as hosted CI's runner is not root.
# Its home is the slot's volume, which runctl hands to it for the run.
chroot "$root" useradd --uid 1000 --user-group --no-create-home --home-dir /work --shell /bin/bash tester
mkdir -p "$root/opt/rust" "$root/opt/gitleaks" "$root/opt/tftvps" "$root/work" "$root/crates" "$root/scan"
tar -xJf "$work/$rust_file" -C "$work"
"$work/${rust_file%.tar.xz}/install.sh" --prefix="$root/opt/rust" --destdir="" --disable-ldconfig --without=rust-docs >/dev/null
tar -xzf "$work/$leaks_file" -C "$root/opt/gitleaks" gitleaks
install -m 644 "$HOME_DIR/gitleaks.toml" "$root/opt/gitleaks/config.toml"
install -m 755 "$HOME_DIR/in-container.sh" "$root/opt/tftvps/in-container.sh"
tar -C "$root" -c . >"$work/rootfs.tar"
chown runner "$work" "$work/rootfs.tar"
chmod 755 "$work"
as_runner() { sudo -n -H -u runner env XDG_RUNTIME_DIR="/run/user/$(id -u runner)" "$@"; }
systemctl start "user@$(id -u runner).service"
# The time limit runs as runner, inside sudo, so it stops runner's own podman; its exit code passes back through.
step podman-import as_runner timeout --kill-after=2m 20m podman import -q "$work/rootfs.tar" localhost/tftvps-run:sealed
step pull-timescale as_runner timeout --kill-after=2m 20m podman pull -q "docker.io/$IMAGE_TIMESCALE"
step pull-plain as_runner timeout --kill-after=2m 20m podman pull -q "docker.io/$IMAGE_PLAIN"
rm -rf "$work"

say "system files"
install -m 644 "$HOME_DIR/nftables.conf" /etc/nftables.conf
install -m 644 "$HOME_DIR"/units/* /etc/systemd/system/
install -m 440 "$HOME_DIR/sudoers" /etc/sudoers.d/tftvps
visudo -cqf /etc/sudoers.d/tftvps
install -m 644 "$HOME_DIR/sshd-before-arming.conf" /etc/ssh/sshd_config.d/00-tftvps.conf
install -m 755 "$HOME_DIR/login-message.sh" /etc/profile.d/tftvps.sh
chown -R root:root "$HOME_DIR"
chmod -R go-w "$HOME_DIR"
# A program boot needs and cannot find stops the build here, not a clone later.
/usr/bin/python3 -I "$HOME_DIR/vps.py" check-programs
# Every container's seccomp profile, from podman's own default as this package ships it, with namespaces taken out.
# A default of a shape the code does not know stops the build. Its hash and source go into the manifest below.
/usr/bin/python3 -I "$HOME_DIR/vps.py" seccomp
seccomp_from=$(dpkg-query -S /usr/share/containers/seccomp.json | cut -d: -f1)
systemctl enable nftables.service tftvps-boot.service tftvps-idle.timer tftvps-limit.timer
systemctl disable apt-daily.timer apt-daily-upgrade.timer 2>/dev/null || true
# A boot unit in an ordering cycle is dropped with no word in its own log, and a clone then never arms. Refuse to
# seal unless cloud-init.target pulls it in and systemd's own check of a boot finds no cycle. Only that check's
# words count: its exit code also covers Ubuntu's units, which are not ours to fix here.
systemctl daemon-reload
systemctl show -p Wants --value cloud-init.target | tr ' ' '\n' | grep -qx tftvps-boot.service
systemctl show -p WantedBy --value cloud-init.target | tr ' ' '\n' | grep -qx multi-user.target
verify_log=$(mktemp)
systemd-analyze --man=no --generators=yes verify default.target tftvps-boot.service >"$verify_log" 2>&1 ||
  say "systemd-analyze verify exited non-zero; only a cycle in its words stops the build"
if grep -iE 'ordering cycle|to break ordering' "$verify_log"; then
  say "an ordering cycle at boot: the boot unit would not start"
  exit 1
fi
rm -f "$verify_log"

say "seal"
manifest=$HOME_DIR/manifest
{
  echo "sealed $(date -u +%FT%TZ) arch $arch"
  as_runner podman images --digests --format '{{.Repository}} {{.Digest}}' | sort
  echo "key files: $(find / -xdev \( -name 'id_*' -o -name '*.pem' \) -not -path '/usr/*' -not -path '/etc/ssl/*' -not -path '/home/runner/.local/*' 2>/dev/null | wc -l)"
  echo "timers: $(systemctl list-unit-files --state=enabled --type=timer --no-legend | awk '{print $1}' | tr '\n' ' ')"
  echo "listening: $(ss -lntuH | wc -l)"
  echo "seccomp: $(sha256sum "$HOME_DIR/seccomp.json" | cut -d' ' -f1) from $(dpkg-query -W -f='${Package} ${Version}' "$seccomp_from")"
  echo "debootstrap mirror: $debootstrap_from"
  echo "packages that stayed:"
  dpkg-query -W -f='${Package} ${Version}\n'
} >"$manifest"
cat "$manifest" >/dev/console || true
passwd -l root
rm -f /root/.ssh/authorized_keys /home/ubuntu/.ssh/authorized_keys /etc/ssh/ssh_host_*
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id /root/.bash_history /home/ubuntu/.bash_history
cloud-init clean --logs --seed
apt-get clean
# The seal only once everything above is done (security L1): a cleanup line that fails leaves no `sealed` on disk, and
# boot refuses a disk with none.
date +%s >"$HOME_DIR/sealed"
sha256sum "$HOME_DIR/manifest" | cut -d' ' -f1 >>"$HOME_DIR/sealed"
tr '\n' ' ' <"$HOME_DIR/sealed" >"$HOME_DIR/sealed.line" && mv "$HOME_DIR/sealed.line" "$HOME_DIR/sealed"
# Sealed: from here no line is a build failure, and the stop at power-off must not read as one.
trap - ERR EXIT
say "SEALED. It powers off in 2 minutes. Take the snapshot only from this build- server."
sleep 120
systemctl poweroff
